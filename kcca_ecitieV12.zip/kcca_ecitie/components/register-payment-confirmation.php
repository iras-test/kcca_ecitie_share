<?php
/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin
	// is no session, go to page/tab 1
	if(!KSecurity::isSession('PAYMENT-REGISTRATION')){
		// response with the redirector rule
		$this->stopRedirector("{$this->urlPath(1,0,0,0)}#choose-coin");
	}
	
	//Reload session data
	$arrSessionData = KSecurity::getSession('PAYMENT-REGISTRATION');
	
	$strCurrency 	= KetrouteApplication::reg()->get('CURRENCY', 'UGX');
	$dblTotal 		= KFormat::getMoney($arrSessionData['revenue-source']['total']);
	
	// component realname
	$strComponentRealname = $this->getComponentRealname();
	
	$arrErrors 		= array();
	$form_prefix 	= 'confirmation_';
	$arrFormFields  = array();
	
	if(KRequest::isPosted())
	{
		// user identifier
		$intUserID = KSecurity::getUserID();
		
		// coin not selected
		if(!(!empty($arrSessionData['choose-coin']) && $arrSessionData['choose-coin']['validated'])){
			$arrErrors[$form_prefix.'details'] = KLanguage::getWord('payment-no-coin-selected');
		}
		
		// revenue-source not selected
		if(!(!empty($arrSessionData['revenue-source']) && $arrSessionData['revenue-source']['validated'])){
			$arrErrors[$form_prefix.'details'] = KLanguage::getWord('payment-no-revenue-source-selected');
		}
		
		// collecting-agent not selected
		if(!(!empty($arrSessionData['collecting-agent']) && $arrSessionData['collecting-agent']['validated'])){
			$arrErrors[$form_prefix.'collecting-agent'] = KLanguage::getWord('payment-no-collecting-agent-selected');
		}

		
		// we have an error
		if(empty($arrErrors))
		{			
			// get customer by coin
			$objCustomer = $this->database()->load('customer', array('id' => $arrSessionData['choose-coin']['cid']));

			// KResponse::trace($objCustomer);
			// exit();
								
			// register payment details and get the object back
			$strRevenueListFormName	= 'payment-items-'.md5(session_id().'payment-choosen-item');


			
			$arrSessionData['collecting-agent']['collecting_agent_']['customer_bank_name'] 				= $arrSessionData['collecting-agent']['eft_details_collecting_agent_']['customer_bank_name'];
			$arrSessionData['collecting-agent']['collecting_agent_']['customer_bank_account_name']		= $arrSessionData['collecting-agent']['eft_details_collecting_agent_']['customer_bank_account_name'];
			$arrSessionData['collecting-agent']['collecting_agent_']['customer_bank_account_number']	= $arrSessionData['collecting-agent']['eft_details_collecting_agent_']['customer_bank_account_number'];	
												
			
			$arrPayment = PaymentManager::registerPaymentFromForm($objCustomer, $arrSessionData['revenue-source'], $arrSessionData['collecting-agent']['collecting_agent_'], $strRevenueListFormName);
				
			// capture audit log
			//$this->logAuditTrail("Registered Payment with PRN", 'payment', $arrPayment['id']);
			

                       // KResponse::trace($arrPayment);
                        
			$payment = $arrPayment;			
			//foreach ($arrPayment as $payment){					
						if((in_array(KRequest::getPost($arrPayment['payment_mode_id']), array(PaymentManager::PAYMENT_MODE_CASH, PaymentManager::PAYMENT_MODE_CHEQUE)))){
	
					// hide the confirmation 
				$this->ui()->setCallback("\$(\"#process-confirmation-info\").hide(); setTimeout(function(){location.href = '{$this->urlPath(0,0,0,0)}print-paf-eft/id/{$payment['prn']}/';}, 3000); ");
				$this->ui()->setCallbackTimeout(60);
			}
			else{
				// hide the confirmation 
				$this->ui()->setCallback("\$(\"#process-confirmation-info\").hide(); setTimeout(function(){location.href = '{$this->urlPath(0,0,0,0)}print-paf/id/{$payment['prn']}/';}, 3000); ");
				$this->ui()->setCallbackTimeout(60);				
			}	
			// broadcast success message	
			KSecurity::setActionSuccess(KLanguage::getWord('payment-payment-registration-submitted', array('total' => "{$strCurrency} {$payment['amount']}", 'reference' => $payment['prn'])));

			// handle payment plan period
			try {

				if (isset($arrSessionData['payment_plan'])) {
					$payment_period = $arrSessionData['payment_plan']['payment_period'];
					// update plan period
					$this->database()->updateRecord("payment_plan_period", array('payment_prn' => $arrPayment['prn']), array('id' => $payment_period));
				}
			} catch (Exception $th) {
			}
					
			// clear session
			KSecurity::killSession('PAYMENT-REGISTRATION');
			
			//Send Sms
			if(!empty($arrSessionData['collecting-agent']) && $arrSessionData['collecting-agent']['collecting_agent_']['sms_send']== KStatus::ACTIVE && !empty($arrSessionData['collecting-agent']['collecting_agent_']['sms_number'])){
													
				$sms_number   =	$arrSessionData['collecting-agent']['collecting_agent_']['sms_number'];	
				
				// get Payment by id
				$objPayment = $this->database()->load('payment', array('prn' => $arrPayment['prn']));						
					
				// send customer notificaion
				PaymentManager::sendPaymentRegistrationNotification($objPayment, $objCustomer,$sms_number);	
			}	
					
			//Send Sms
			if(!empty($arrSessionData['collecting-agent']) && $arrSessionData['collecting-agent']['collecting_agent_']['print_option'] == KStatus::ACTIVE)
			{
				
					// user can print paf: go to print paf
					if($this->hasPermission('print-small-paf'))
					{
						$this->stopRedirector("{$this->urlPath(0,0,0,0)}print-small-paf/id/{$arrPayment['ids']}/");
					}
				
			  }
			else{
					// response with the redirector rule
					if(!KRequest::isAjax())
					{
						// user can print paf: go to print paf
						if($this->hasPermission('print-paf')){
							$this->stopRedirector("{$this->urlPath(0,0,0,0)}print-paf/id/{$arrPayment['ids']}/");
						}
						else if($this->hasPermission('print-paf-eft')){
							$this->stopRedirector("{$this->urlPath(0,0,0,0)}print-paf-eft/id/{$arrPayment['ids']}/");
						}else{
							// user with no permission to print PAF
							$this->stopRedirector();
						}			
					}					
			     }					
			//}	
		}
	}	
	else{
		// setup the back page
		$this->startRedirector();
	}
			
	// confirmation item template
	$strConfirmationTemplate = KFile::getContent("{$this->getComponentTemplatesPath()}{$this->getModule()}-{$this->getOption()}-item.tpl");
	$results_html = '';	
			
	// choose-coin
	if(!empty($arrSessionData['choose-coin']) && $arrSessionData['choose-coin']['validated'] ){
		$tags = array();
		$tags['title'] 			 = KLanguage::getWord("{$this->getComponent()}-{$this->getModule()}-choose-coin");
		$tags['status-image'] 	 = 'msg_confirm.png';
		$tags['details'] 		 = KLanguage::getWord('all-details-checked-and-verified');
		$tags['link'] 			 = "{$this->urlPath(1,0,0,0)}#choose-coin";
		$results_html 			.= KString::replaceTags($strConfirmationTemplate, $tags);
	}
	else{
		$tags = array();
		$tags['title'] 			 = KLanguage::getWord("{$this->getComponent()}-{$this->getModule()}-choose-coin");
		$tags['status-image'] 	 = 'msg_warning.png';
		$tags['details'] 		 = KLanguage::getWord('not-all-details-checked-and-verified');
		$tags['link'] 			 = "{$this->urlPath(1,0,0,0)}#choose-coin";
		$results_html 			.= KString::replaceTags($strConfirmationTemplate, $tags);
	}
	

	// revenue-source
	if(!empty($arrSessionData['revenue-source']) && $arrSessionData['revenue-source']['validated'] ){
		$tags = array();
		$tags['title'] 			 = KLanguage::getWord("{$this->getComponent()}-{$this->getModule()}-revenue-source")." - {$strCurrency} {$dblTotal}";
		$tags['status-image'] 	 = 'msg_confirm.png';
		$tags['details'] 		 = KLanguage::getWord('all-details-checked-and-verified');
		$tags['link'] 			 = "{$this->urlPath(1,0,0,0)}#revenue-source";
		$results_html 			.= KString::replaceTags($strConfirmationTemplate, $tags);
	}
	else{
		$tags = array();
		$tags['title'] 			 = KLanguage::getWord("{$this->getComponent()}-{$this->getModule()}-revenue-source")." = {$strCurrency} {$dblTotal}";
		$tags['status-image'] 	 = 'msg_warning.png';
		$tags['details'] 		 = KLanguage::getWord('not-all-details-checked-and-verified');
		$tags['link'] 			 = "{$this->urlPath(1,0,0,0)}#revenue-source";
		$results_html 			.= KString::replaceTags($strConfirmationTemplate, $tags);
	}

	// collecting-agent
	if(!empty($arrSessionData['collecting-agent']) && $arrSessionData['collecting-agent']['validated'] ){
		$tags = array();
		$tags['title'] 			 = KLanguage::getWord("{$this->getComponent()}-{$this->getModule()}-collecting-agent");
		$tags['status-image'] 	 = 'msg_confirm.png';
		$tags['details'] 		 = KLanguage::getWord('all-details-checked-and-verified');
		$tags['link'] 			 = "{$this->urlPath(1,0,0,0)}#collecting-agent";
		$results_html 			.= KString::replaceTags($strConfirmationTemplate, $tags);
	}
	else{
		$tags = array();
		$tags['title'] 			 = KLanguage::getWord("{$this->getComponent()}-{$this->getModule()}-collecting-agent");
		$tags['status-image'] 	 = 'msg_warning.png';
		$tags['details'] 		 = KLanguage::getWord('not-all-details-checked-and-verified');
		$tags['link'] 			 = "{$this->urlPath(1,0,0,0)}#collecting-agent";
		$results_html 			.= KString::replaceTags($strConfirmationTemplate, $tags);
	}
		
	$replace_tags = array(		'form_action' 			=> KRequest::getUri(),
								'back_url' 				=> KSecurity::getSession('BACK_URL'),
								'details'				=> $results_html,		
								'fields'				=> $this->runtime()->createFormFields($this, $arrFormFields, $form_prefix, $arrErrors),		
								'form_identifier'		=> "mykfwform-{$this->getComponent()}-{$this->getModule()}-{$this->getOption()}",
								'confirm_question'		=> KLanguage::getWord("{$this->getComponent()}-{$this->getModule()}-{$this->getOption()}-confirmation"),
								'back_link'				=> "{$this->urlPath(1,0,0,0)}#contacts-reference-agent",
						);
	
	// this list page is ajax capable						
	$this->gui()->appendTitle(KLanguage::getWord("{$this->getComponent()}-{$this->getModule()}-{$this->getOption()}-confirmation"));
	$this->render($replace_tags,$this->getComponentTemplatesPath()."{$this->getModule()}-{$this->getOption()}.tpl");
	
	
	
	
	
	
	
	
	
	
	
