<?php
$case_id = $this->getParam('case', 1);
$redirect = $this->getParam('redirect', 1);
$queryParams = KRequest::getQueryStrings();
$role = $queryParams["role"];


if (KRequest::isPosted()) {
    $case = $this->database()->load('arrear_case', array('id' => $case_id));
    $assignee = KRequest::getPost("assignee", null);
    $normalize_case = $this->getParam('normalize_case', 0);
    $assignee = $assignee ? $assignee : $case->created_by;
    $update_status = $normalize_case ? ArrearStatus::SENT_BACK : ArrearStatus::DEFFERED;

    ArrearCase::updateStatus($case_id,  $update_status, KRequest::getPost('comment'), $assignee);

    if ($normalize_case) {
        ArrearsManager::updateBusinessArrearStatus($case->ref_name, $case->ref_id, KStatus::ACTIVE);
    }

    // Send back
    $this->database()->createRecord(
        'arrear_case_send_back',
        array(
            "arrear_case_id"    =>  $case_id,
            "comment"           =>  KRequest::getPost('comment'),
            "created_by"        =>  KSecurity::getUserID()
        ),
        array('created_date' => KetrouteApplication::db()->getNowExpression())
    );

    // // // set success message
    KSecurity::setActionSuccess(KLanguage::getWord('You have successfully sent back the case', array('arrears_case' => $case_id)));
}

KResponse::redirect("{$this->urlPath(0)}$redirect");
