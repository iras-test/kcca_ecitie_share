<?php

/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

$business_seal_context = [];

$business_seal_id_Provided = KRequest::getQueryString("id", null);
$format = KRequest::getQueryString("format", "html");
$util = new Util();

if ($format == "json") {
    header("Content-type: application/json");
    AuthWrapper::getAuthenticatedUser();
}

$current_user = KSecurity::getUserID();
$current_user_profile = UserManager::getProfile($current_user);

$business_seal_obj = null;

if ($business_seal_id_Provided) {

    $business_seal_obj = BusinessSealManager::getBusinessSealActionByID($business_seal_id_Provided);
    
} else {

    KSecurity::setActionWarning("Business Seal must be provided");
}


if ($business_seal_obj) {

    $case_id = $business_seal_obj->arrears_case_id;
    $info  = (object) ArrearCase::getItem($case_id);
    $case_status = ($info->status == null) ? ArrearStatus::OPEN : $info->status;
    $active_assignment = ArrearCase::getCaseAssignments($info->id);
    $bal = abs($info->arrear_amount);
    $business_details = ArrearsManager::getBusinessDetails($info->ref_name, $info->ref_id);

    $extra_details = "";

    if ($info->ref_name == "vehicle") {
        $extra_details .= "<div class=\"pt10\">
                            <strong><span class=\"bs-bold\">Park</span></strong>: {$business_details->park_name}
                        </div>
                        <div class=\"pt10\">
                            <strong><span class=\"bs-bold\">Stage</span></strong>: {$business_details->stage_name}
                        </div>
                        ";
    }

    $info_display = "
        <div class=\"clear customer-blocks pb10\">
            <h1 class=\"kfw-active-title\"><strong>[lang-arrears-case-details]<strong></h1>
            <div class=\"clear pt10\">
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Customer</span></strong>: {$info->customer}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">COIN</span></strong>: {$info->coin}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Revenue name</span></strong>: {$info->revenue_name}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Branch Code</span></strong>: {$business_details->branch_code}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Location</span></strong>: {$business_details->location}
                </div>
                {$extra_details}
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Outstanding balance</span></strong>: {$bal}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Case Status</span></strong>: <span class=\"{$util::StatusClass($case_status)}\">{$case_status}</span>
                </div>
            </div>
        </div>
    ";

    $business_seal_context["case_id"] = $case_id;
    $business_seal_context["info_display"] = $info_display;
    $business_seal_context["pp_id"] = $business_seal_obj->id;
    $business_seal_context["reason"] = $business_seal_obj->seal_reason;
    $business_seal_context["seal_date"] = $business_seal_obj->created_date;
    $business_seal_context["seal_number"] = $business_seal_obj->seal_number;
    $business_seal_context["status"] = $business_seal_obj->seal_status == 1 ? "Active"
        : "Revoked";

    $created_by = UserManager::getProfile($business_seal_obj->created_by);

    $business_seal_context["created_by"] = "{$created_by->firstname} {$created_by->surname}";


    if ($format == "json") {
        echo json_encode([
            "seal_details" => $business_seal_context,
            "status" => 200,
        ]);
        exit;
    }

    $approval_form_identifier = "mykfwform-{$this->getComponent()}-{$this->getModule()}";
    $business_seal_context['records'] = $records;
    $business_seal_context['form_action'] = "{$this->urlPath(0)}business-seal-approval-action";
    $business_seal_context['preview_action'] = "{$this->urlPath(0)}business-seal-preview?id=[pp_id]";
    $business_seal_context['preview_and_notify_action'] = "{$this->urlPath(0)}business-seal-preview?id=[pp_id]&notify=1";
    $business_seal_context['form_identifier'] = $approval_form_identifier;
    $business_seal_context['back_url'] = KSecurity::getSession('BACK_URL');

    $approval_action = "<a href=\"[preview_action]\">
                        <input type=\"button\" class=\"success\" title=\"Preview\" value=\"Preview\" />
                        </a>
                        <a href=\"[preview_and_notify_action]\">
                        <input type=\"button\" class=\"success\" title=\"Print and Notify\" value=\"Print and Notify\" />
                        </a>";

    if ($business_seal_obj->seal_status == 1
        &&
        (
            (($active_assignment != null) && ($active_assignment->user_id == $current_user)) // case has been escalated to user
            ||
            ($current_user_profile->user_role_id == ArrearStatus::ARREARS_MANAGER_ROLE) // user is SAM
        )
    ) {
            $approval_action .= "<input type=\"submit\" name=\"approval_action\" class=\"cancel\" value=\"Revoke\" onclick=\"revoke_seal()\" />";
    }

    $approval_js = "<script type=\"text/javascript\">
                        function approve(){
                            document.getElementById(\"{$approval_form_identifier}-yes\").submit()
                        }
                        function revoke_seal(){
                            document.getElementById(\"{$approval_form_identifier}-no\").submit()
                        }

                    </script>";

    $business_seal_context["approval_js"] = $approval_js;
    $business_seal_context["approval_action"] = $approval_action;

    return $this->render($business_seal_context);
}
$this->stopRedirector(KSecurity::getSession('BACK_URL'));
