
<?php

(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
set_time_limit(0);

// run daily

$instance = KetrouteApplication::instance();

print("checking for paid periods: \n");

$payment_plan_periods = $instance->db()->getList(
    "payment_plan_period",
    $where = array('ignore' => array('payment_prn' => null), 'payment_id' => null),
    $fields = '*',
    $pager_info = null,
    $where_in = null,
    $likeforlike_binding = null,
    $startwith_binding = null,
    $endwith_binding = null,
    $hasatleast_binding = null,
    $greaterthanequal_binding = null,
    $lessthanequal_binding = null,
    $between_binding = null,
    $year_binding = null,
    $order_ascending = 'created_date'
);

$biz_count = 0;

foreach ($payment_plan_periods as $index => $payment_period) {

    print("$biz_count : checking prn payment status... ");

    try {

        $objPayment = $instance->database()->load('payment', array('prn' => $payment_period->payment_prn));
        if ($objPayment->transaction_status == "C") {

            $instance->database()->updateRecord(
                "payment_plan_period",
                array('payment_id' => $objPayment->id),
                array('id' => $payment_period->id)
            );
            print("updated payment period\n");
        }
    } catch (\Throwable $th) {
    }


    $biz_count++;
}
