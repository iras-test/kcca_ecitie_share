<?php

$ref_name    = KRequest::getQueryString("ref_name", null);
$ref_id    = KRequest::getQueryString("ref_id", null);
AuthWrapper::getAuthenticatedUser();

if ($ref_name && $ref_id) {

    // KResponse::location(StatementOFAccountHelper::getStatementOfAccount($ref_name, $ref_id));
    // echo StatementOFAccountHelper::getStatementOfAccount($ref_name, $ref_id);
    // exit;
    $request_headers = apache_request_headers();
    $cookie = $request_headers['Cookie'];

    $redirect_url  = StatementOFAccountHelper::getStatementOfAccount($ref_name, $ref_id);
    header("Access-Control-Allow-Origin: *");
    header("Cookie: $cookie");
    header("Location: $redirect_url");
    exit;
}
