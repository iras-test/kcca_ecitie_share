<?php
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

header("Content-type: application/json");
$instance = KetrouteApplication::instance();
$village = KRequest::getQueryString("village", null);
$where_clause = null;

if ($village != null) {
    $where_clause = array("village_id" => $village);
}

try {
    $grade = $instance->db()->load($table = 'grade', $where = $where_clause);
} catch (\Exception $th) {
    $grade = (object)[];
}

echo json_encode(["grade" => $grade,"status" => 200]);

exit;
