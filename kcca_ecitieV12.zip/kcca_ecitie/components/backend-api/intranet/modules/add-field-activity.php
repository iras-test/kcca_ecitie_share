<?php

header("Content-type: application/json");
AuthWrapper::getAuthenticatedUser();

if (KRequest::isPosted()) {

    $coin = KRequest::getQueryString('coin', null);
    $ref_name = KRequest::getQueryString('ref_name', null);
    $ref_id = KRequest::getQueryString('ref_id', null);

    if ($coin && $ref_name && $ref_id) {

        $trail = $this->database()->createRecord(
            'recovery_trail',
            array(
                'ref_name'             => $ref_name,
                'ref_id'             => $ref_id,
                'coin'                 => $coin,
                'comment'             =>  KRequest::getpost("comment"),
                'recovery_type_id'     => KRequest::getpost("recovery_type_id"),
                'y_coordinates'     => KRequest::getpost("y_coordinates"),
                'x_coordinates'     => KRequest::getpost("x_coordinates"),
                'status_id'         => KStatus::ACTIVE,
                'created_by'        => KSecurity::getUserID()
            ),
            array('created_date' => KetrouteApplication::db()->getNowExpression())
        );

        echo json_encode([
            "message" => "Activity Sucessfully Recorded",
            "status" => 200,
        ]);
    } else {
        echo json_encode([
            "message" => "Missing Parameters",
            "status" => 400,
        ]);
    }
} else {
    echo json_encode([
        "message" => "Unknown method",
        "status" => 400,
    ]);
}

exit;
