<?php

header("Content-type: application/json");
AuthWrapper::getAuthenticatedUser();

$status = 400;
        
if(KRequest::isPosted()){
    // user identifier
    $intUserID = KSecurity::getUserID();

    $arrSessionData = KRequest::getPost("data");
    $arrSessionData = json_decode($arrSessionData, true);

    
    // we have an error
    if(empty($arrErrors)){

        $intTotalRevenueSourceItems = 0;
        $arrRevenueData				= array();				
                
            // customer ID
        $intCustomer 		= $arrSessionData['coin-reason']['cid'];
        $objCustomer		= $this->database()->load($table = 'customer', array('id' => $arrSessionData['coin-reason']['cid']));
            
        if(is_int($arrSessionData['coin-reason']['ref'])){
            $objCall = $this->database()->load($table = 'support_call', array('id' => $arrSessionData['coin-reason']['ref']));
        }
            
        $form_int = $objCustomer->customer_type_id;
        $form_code = AcknowledgementManager::COIN_REGISTRATION_FORM_AMENDMENT_FOR_INDIVIDUAL_CODE;				
            
        if($form_int==2){
            $form_code = AcknowledgementManager::COIN_REGISTRATION_FORM_AMENDMENT_FOR_NON_INDIVIDUAL_CODE;		
        }
        
            // save business branches
        if(!empty($arrSessionData['business-branches'])){
            $arrAmend = array();
            $arrAmend['customer_id']			= $intCustomer;
            $arrAmend['service_desk_reference'] = $arrSessionData['coin-reason']['ref'];
            $arrAmend['financial_year']			= KGenerator::getFinancialYearEnd();
            $arrAmend['status_id']				= KStatus::NOT_VERIFIED;
            $arrAmend['created_by']				= $intUserID;					
            $intTotalRecords 					= $this->database()->getCount($table = 'amendment', $where = array('financial_year' => $arrAmend['financial_year']	), $where_in = null, $likeforlike_binding = null, $startwith_binding = null, $endwith_binding = null, $hasatleast_binding = null, $greaterthanequal_binding = null, $lessthanequal_binding = null);
            $intTotalRecords					=$intTotalRecords+1;
            $strSequenceNumber					= str_pad($intTotalRecords, 7, '0', STR_PAD_LEFT);
            $strFinancialYearCode 				= substr($arrAmend['financial_year']	, -2);
            $arrAmend['amendment_reference']	="A{$strFinancialYearCode}{$strSequenceNumber}";
            $arrAmend['amendment_reason']			= $arrSessionData['coin-reason']['ref'];
            
            $intAmend				= $this->database()->createRecord('amendment', $arrAmend, array('created_date' => KetrouteApplication::db()->getNowExpression()));
                    //application instance	
            $strReferenceNumber					= $arrAmend['amendment_reference'];
                            
            foreach($arrSessionData['business-branches'] as $revenue_source_system_code => $branch_items){
                // manage createing of branches based on revenue source
                                
                switch($revenue_source_system_code){
                    // transport module
                    case RevenueManager::REVENUE_SOURCE_SYSTEM_CODE_TRANSPORT:
                        // set empty revenue data holder
                        $arrRevenueData['vehicle'] = array();
                        
                        foreach($branch_items as $vehicle_key => $details){
                            $arrVehicle = array();
                            //get the number plate
                            $number_plate 								=  KetrouteApplication::instance()->database()->getStaticTableValue('vehicle', $id_field = 'id', $return_field = 'number_plate', $id_value = $details['vehicle_']['av_number_plate']);
                            $arrVehicle['customer_id']					= $intCustomer;
                            $arrVehicle['vehicle_operation_type_id']	= $details['vehicle_']['av_operation_type_id'];
                            $arrVehicle['log_book_date']				= $details['vehicle_']['av_log_book_date'];
                            $arrVehicle['number_plate']					= $number_plate;
                            $arrVehicle['color']						= $details['vehicle_']['av_color'];
                            $arrVehicle['vehicle_year']					= $details['vehicle_']['av_year'];
                            $arrVehicle['vehicle_model']				= $details['vehicle_']['av_model'];
                            $arrVehicle['vehicle_category_id']			= $details['vehicle_']['av_category_id'];
                            $arrVehicle['vehicle_make']					= $details['vehicle_']['av_make'];
                            $arrVehicle['engine_number']				= $details['vehicle_']['av_engine_number'];
                            $arrVehicle['chassis_number']				= $details['vehicle_']['av_chassis_number'];
                            $arrVehicle['city_id']						= $details['vehicle_']['city_id'];
                            $arrVehicle['division_id']					= $details['vehicle_']['division_id'];
                            $arrVehicle['park_id']						= $details['vehicle_']['park_id'];
                            $arrVehicle['stage_id']						= $details['vehicle_']['stage_id'];
                            $arrVehicle['date_joined_stage']			= $details['vehicle_']['av_date_joined_stage'];
                            $arrVehicle['owner_name']					= $details['vehicle_']['av_owner_name'];
                            $arrVehicle['owner_tin']					= $details['vehicle_']['av_owner_tin'];
                            
                            $arrVehicle['driver_firstname']				= $details['vehicle_']['av_driver_firstname'];
                            $arrVehicle['driver_middle_name']			= $details['vehicle_']['av_driver_second_name'];
                            $arrVehicle['driver_surname']				= $details['vehicle_']['av_driver_surname'];
                            $arrVehicle['driver_permit_number']			= $details['vehicle_']['av_permit_number'];
                            $arrVehicle['driver_mobile']				= $details['vehicle_']['av_driver_mobile'];
                            
                            $arrVehicle['status_id']					= KStatus::PENDING;
                            $arrVehicle['created_by']					= $intUserID;
                            $oldRefID 									= $details['vehicle_']['av_number_plate'];

                            $newRefID = $this->database()->createRecord('vehicle', $arrVehicle, array('created_date' => KetrouteApplication::db()->getNowExpression()));
                            $arrRevenueData['vehicle'][$newRefID] = $newRefID;
                            //$arrRevenueData['old_reference_id'][$oldRefID] = $oldRefID;
                            //save to amendment_link     created_by created_date
                            $arrAmendLink = array();
                            $arrAmendLink['amendment_id']				=$intAmend;
                            $arrAmendLink['reference_name']				='vehicle';
                            $arrAmendLink['old_reference_id']			=$oldRefID;
                            $arrAmendLink['new_reference_id']			=$newRefID;
                            $arrAmendLink['status_id']					=KStatus::PENDING;
                            $arrAmendLink['created_by']					= $intUserID;
                            $this->database()->createRecord('amendment_link', $arrAmendLink, array('created_date' => KetrouteApplication::db()->getNowExpression()));
                        }
                        break;
                    case MarketsManager::REVENUE_SOURCE_SYSTEM_CODE_MARKETS:																
                        // set empty revenue data holder
                        $arrRevenueData['market_facility_item'] = array();																					
                        foreach($branch_items as $vehicle_key => $details){
                                                                                                    
                            $arrMarkets 						= array();
                            $arrMarkets['customer_id']			= $intCustomer;
                            $arrMarkets['ownership_id']			= $details['owner_']['ownership_id'];								
                            
                            if($details['owner_']['ownership_id']==2 &&empty($details['owner_']['facility_number'])){
                                $objMarket = $this->database()->load('markets', array('id' => $details['owner_']['market_id']));										
                                $details['owner_']['facility_number']=$objMarket->market_code;
                            }																
                            
                            $arrMarkets['facility_number']		= $details['owner_']['facility_number'];
                            $arrMarkets['code']		   			= MarketFacilityManager::getFacilityNumber($details['owner_']['market_id'],$details['owner_']['facility_id'],$details['owner_']['facility_number']);  //$details['owner_']['facility_number'];
                                                                
                            $arrMarkets['facility_id']			= $details['owner_']['facility_id'];									
                            $arrMarkets['market_id']			= $details['owner_']['market_id'];
                            // $arrMarkets['facility_type_id']	= $details['owner_']['market_facility_grade_id'];
                            $arrMarkets['grade_id']	   			= $details['owner_']['market_facility_grade_id'];
                            
                            $arrMarkets['business_category_id']	= $details['location_']['business_category_id'];									
                            $arrMarkets['market_join_date']		= $details['location_']['market_join_date'];
                            $arrMarkets['occupancy_status_id']	= $details['location_']['occupancy_status_id'];
                            
                                // forced registration																	
                            $arrMarkets['status_id']				= KStatus::PENDING;
                            $arrMarkets['created_by']				= $intUserID;
                            
                            $intMarkets = $this->database()->createRecord('market_facility_item', $arrMarkets, array('created_date' => KetrouteApplication::db()->getNowExpression()));
                            $arrRevenueData['market_facility_item'][$intMarkets] = $intMarkets;														
                        }

                        break;
                    case 'tradinglicense':	
                                                        
                        // set empty revenue data holder
                        $arrRevenueData['vehicle'] = array();																					
                        foreach($branch_items as $key => $details){
                            //KResponse::trace($details['vehicle_']);exit;																		
                            $arrTradingLicense = array();
                            $code =  KetrouteApplication::instance()->database()->getStaticTableValue('trading_license', $id_field = 'id', $return_field = 'code', $id_value = $details['vehicle_']['at_code']);
                            $arrTradingLicense['customer_id']				                = $intCustomer;
                            $arrTradingLicense['code']										=$code;
                            $arrTradingLicense['business_name']				                = $details['vehicle_']['at_business_name'];
                            $arrTradingLicense['liability_type']			                = $details['vehicle_']['at_liability_type'];
                            
                            $arrTradingLicense['business_reg_number']						= $details['vehicle_']['at_business_reg_number'];
                            $arrTradingLicense['identification_cert_of_incorporation']		= $details['vehicle_']['at_identification_cert_of_incorporation'];
                            
                            $arrTradingLicense['owner_tin']				                    = $details['vehicle_']['at_owner_tin'];
                            $arrTradingLicense['business_category_id']	 	                = $details['vehicle_']['at_business_category_id'];
                            $arrTradingLicense['business_type_id']		                    = $details['vehicle_']['at_business_type_id'];
                            $arrTradingLicense['division']		                            = $details['vehicle_']['at_division_id'];
                            $arrTradingLicense['grade']				                        = $details['vehicle_']['at_grade_id'];
                            $arrTradingLicense['grade_id']				                        = $details['vehicle_']['at_grade_id'];
                            $arrTradingLicense['building_name']			                    = $details['vehicle_']['at_building_name'];
                            //$arrTradingLicense['street_name']				                = $details['trading_license_other_']['tl_street_id'];									
                            //$arrTradingLicense['number_of_employees']			            = $details['trading_license_other_']['number_of_employees'];
                            //$arrTradingLicense['have_suitability_cert']			            = $details['trading_license_other_']['have_suitability_cert'];
                            $arrTradingLicense['business_records_kept']		                = $details['vehicle_']['at_business_records_kept'];
                            $arrTradingLicense['amount']		                            = $details['vehicle_']['at_grade_Amount'];
                            $arrTradingLicense['parish']		                            = $details['vehicle_']['at_parish_id'];
                            $arrTradingLicense['village']		                            = $details['vehicle_']['at_village_id'];
                            $arrTradingLicense['street']				                	= $details['vehicle_']['at_street_id'];	
                            //$arrTradingLicense['descr']		                                = $details['vehicle_']['descr'];
                            
                            if(!empty($arrSessionData['coin-reason']['question_']['is_forced_action']))
                            {
                                $arrTradingLicense['is_forced_action'] 	= $arrSessionData['coin-reason']['question_']['is_forced_action'];
                                $arrVehicle['is_forced_action']  =  0;
                                $arrMarkets['is_forced_action']  = 0;				
                            }
                            else{
                                $arrTradingLicense['is_forced_action'] 	=  0;
                                $arrVehicle['is_forced_action']         =  0;
                                $arrMarkets['is_forced_action']         =  0;
                            }
                            $arrTradingLicense['status_id']				                    = KStatus::PENDING;
                            $arrTradingLicense['created_by']				                = $intUserID;
                            $oldRefID 									= $details['vehicle_']['at_code'];
                            $newRefID = $this->database()->createRecord('trading_license', $arrTradingLicense, array('created_date' => KetrouteApplication::db()->getNowExpression()));
                            $arrRevenueData['trading_license'][$newRefID] = $newRefID;														
                            $arrAmendLink = array();
                            $arrAmendLink['amendment_id']				=$intAmend;
                            $arrAmendLink['reference_name']				='Tradinglicense';
                            $arrAmendLink['old_reference_id']			=$oldRefID;
                            $arrAmendLink['new_reference_id']			=$newRefID;
                            $arrAmendLink['status_id']					=KStatus::PENDING;
                            $arrAmendLink['created_by']					= $intUserID;
                            $this->database()->createRecord('amendment_link', $arrAmendLink, array('created_date' => KetrouteApplication::db()->getNowExpression()));	
                        }
                     break;		
                    

                    //case LocalHotelTaxManager::REVENUE_SOURCE_SYSTEM_CODE_LHT:
                    case 'localhoteltax':
                    
                        // set empty revenue data holder
                        $arrRevenueData['vehicle'] = array();

                        //holds the customer id in the session 
                        $customerId = $arrSessionData['coin-reason']['cid'];

                        foreach($branch_items as $key => $details){

                            //kresponse::trace($details);
                            //exit();

                            $arrLocalHotelTax = array();
                            $arrLocalHotelTax['customer_id']				            				= $intCustomer;
                            $arrLocalHotelTax['code']													=  KetrouteApplication::instance()->database()->getStaticTableValue('lht_application', $id_field = 'id', $return_field = 'code', $id_value = $details['gen_']['alht_code']);
                            //$arrLocalHotelTax['business_name']				                			= $details['vehicle_']['business_name'];
                            $arrLocalHotelTax['hotel_name']				                				= $details['gen_']['alhtl_name'];
                            $arrLocalHotelTax['division_id']				                			= $details['gen_']['lht_division'];
                            $arrLocalHotelTax['parish_id']				            					= $details['gen_']['lht_tl_parish_id'];
                            //$arrLocalHotelTax['village_zone_id']				            			= $details['owner_']['lht_tl_village_id_a'];
                            //$arrLocalHotelTax['street_road_name']				            			= $details['owner_']['lht_tl_street_a'];
                            $arrLocalHotelTax['plot_number']				                			= $details['gen_']['plot_number'];
                            $arrLocalHotelTax['house_number']				                			= $details['gen_']['house_number'];
                            $arrLocalHotelTax['x_coordinate']				                			= $details['gen_']['gprs_cordinate_x'];
                            $arrLocalHotelTax['y_coordinate']				                			= $details['gen_']['gprs_cordinate_y'];
                            $arrLocalHotelTax['postal_address']				                			= $details['gen_']['postal_address'];
                            
                            $arrLocalHotelTax['contact_office_person_id']				                = $details['gen_']['contact_office_person'];
                            $arrLocalHotelTax['contact_tel_number_1']				                	= $details['gen_']['contact_tel_number_1'];
                            $arrLocalHotelTax['contact_tel_number_2']				                	= $details['gen_']['contact_tel_number_2'];
                            $arrLocalHotelTax['reception_tel_number_1']				                	= $details['gen_']['reception_tel_number_1'];
                            $arrLocalHotelTax['reception_tel_number_2']				                	= $details['gen_']['reception_tel_number_2'];
                            $arrLocalHotelTax['email']				                					= $details['gen_']['email'];
                            
                            $arrLocalHotelTax['chain_group']				                			= $details['gen_']['chain_group'];
                            $arrLocalHotelTax['chain_name']				                				= $details['gen_']['chain_name'];
                            $arrLocalHotelTax['classification_id']				                		= $details['gen_']['lht_classification'];
                            $arrLocalHotelTax['total_number_of_rooms_at_facility']						= $details['gen_']['total_number_of_rooms_at_the_facility'];
                            $arrLocalHotelTax['hotel_facility_rating_id']								= $details['gen_']['hotel_facility_rating'];
                            $arrLocalHotelTax['rooms_charged_above_50000_executive']					= $details['gen_']['hotel_rooms_charged_above_50000'];
                            $arrLocalHotelTax['rooms_charged_10000_50000_ordinary']						= $details['gen_']['hotel_rooms_charged_btn_10000_50000'];
                            $arrLocalHotelTax['rooms_charged_below_10000_extra']						= $details['gen_']['hotel_rooms_charged_below_10000'];
                            $arrLocalHotelTax['total']													= $details['gen_']['total'];
                            $arrLocalHotelTax['hotel_size_id']											= $details['gen_']['hotel_size'];
                            $arrLocalHotelTax['swimming_pool']											= $details['gen_']['other_facilities_swimming_pool'];
                            $arrLocalHotelTax['restaurant']												= $details['gen_']['other_facilities_restaurant'];
                            $arrLocalHotelTax['games']													= $details['gen_']['other_facilities_games'];
                            $arrLocalHotelTax['gymnasium']												= $details['gen_']['other_facilities_gymnasium'];
                            $arrLocalHotelTax['social_function_services']								= $details['gen_']['other_facilities_social_function_services'];
                            $arrLocalHotelTax['conference_facilities']									= $details['gen_']['other_facilities_conference_facilities'];
                            $arrLocalHotelTax['trading_license_id']										= $details['gen_']['trading_license_id'];

                        /*if(!empty($arrSessionData['coin-reason']['question_']['is_forced_action']))
                                {
                                    $arrLocalHotelTax['is_forced_action'] 	= $arrSessionData['coin-reason']['question_']['is_forced_action'];
                                    $arrVehicle['is_forced_action']  =  0;
                                    $arrMarkets['is_forced_action']  = 0;				
                                }
                                else{
                                    $arrLocalHotelTax['is_forced_action'] 	=  0;
                                    $arrVehicle['is_forced_action']         =  0;
                                    $arrMarkets['is_forced_action']         =  0;
                                }*/
                                $arrLocalHotelTax['verification_status_id']				    = KStatus::PENDING;
                                $arrLocalHotelTax['status_id']				                = KStatus::ACTIVE;
                                $arrLocalHotelTax['created_by']				                = $intUserID;
                                
                                $newRefID = $this->database()->createRecord('lht_application', $arrLocalHotelTax, array('created_date' => KetrouteApplication::db()->getNowExpression()));
                                $arrRevenueData['localHotelTax'][$newRefID] = $newRefID;
                                $oldRefID 									= $details['gen_']['alht_code'];
                                $arrAmendLink = array();
                                $arrAmendLink['amendment_id']				=$intAmend;
                                $arrAmendLink['reference_name']				='LocalHotelTax';
                                $arrAmendLink['old_reference_id']			=$oldRefID;
                                $arrAmendLink['new_reference_id']			=$newRefID;
                                $arrAmendLink['status_id']					=KStatus::PENDING;
                                $arrAmendLink['created_by']					= $intUserID;
                                $this->database()->createRecord('amendment_link', $arrAmendLink, array('created_date' => KetrouteApplication::db()->getNowExpression()));	
                        }

                        break;							
                    case 'localservicetax':	
                        // set empty revenue data holder
                        $arrRevenueData['vehicle'] = array();																					
                        foreach($branch_items as $key => $details){
                                                                                                    
                            $arrLocalServiceTax = array();
                            $arrLocalServiceTax['customer_id']				            = $intCustomer;
                            
                            $arrLocalServiceTax['tin']				            		= $details['vehicle_']['tin'];
                            $arrLocalServiceTax['lst_type_id']			            	= $details['vehicle_']['lst_type_id'];
                            $arrLocalServiceTax['lst_division_id']		            	= $details['vehicle_']['lst_division_id'];
                            $arrLocalServiceTax['lst_parish_id']  						= $details['vehicle_']['lst_parish_id'];
                            $arrLocalServiceTax['lst_village_id']				        = $details['vehicle_']['lst_village_id'];
                            $arrLocalServiceTax['lst_street_id']	 	            	= $details['vehicle_']['lst_street_id'];
                            $arrLocalServiceTax['trading_center']			        	= $details['vehicle_']['trading_center'];
                            $arrLocalServiceTax['building_name']		                = $details['vehicle_']['building_name'];
                            $arrLocalServiceTax['postal_address']				        = $details['vehicle_']['postal_address'];	
                            //employer section
                            $arrLocalServiceTax['gprs_cordinate_x']		                = $details['vehicle_']['gprs_cordinate_x'];
                            $arrLocalServiceTax['gprs_cordinate_y']				        = $details['vehicle_']['gprs_cordinate_y'];
                            $arrLocalServiceTax['house_number']			                = $details['vehicle_']['house_number'];
                            $arrLocalServiceTax['contact_designation']		            = $details['vehicle_']['contact_designation'];
                            $arrLocalServiceTax['contact_title_id']		                = $details['vehicle_']['contact_title_id'];
                            $arrLocalServiceTax['lst_contact_person']		        	= $details['vehicle_']['lst_contact_person'];
                            $arrLocalServiceTax['contact_tel_number_1']		            = $details['vehicle_']['contact_tel_number_1'];
                            $arrLocalServiceTax['contact_tel_number_2']		            = $details['vehicle_']['contact_tel_number_2'];
                            $arrLocalServiceTax['contact_email']		                = $details['vehicle_']['contact_email'];
                            $arrLocalServiceTax['start_date']		                    = $details['vehicle_']['start_date'];
                            $arrLocalServiceTax['lst_org_size_id']		                = $details['vehicle_']['lst_org_size_id'];									
                            $arrLocalServiceTax['lst_business_category_id']		        = $details['vehicle_']['lst_business_category_id'];
                            $arrLocalServiceTax['lst_business_sub_category_id']		    = $details['vehicle_']['lst_business_sub_category_id'];
                            //employee section
                            $arrLocalServiceTax['employer_name']		                = $details['vehicle_']['employer_name'];
                            $arrLocalServiceTax['employer_coin']		                = $details['vehicle_']['employer_coin'];										
                            //general stuff
                            $arrLocalServiceTax['balance']								='0.0';
                            $arrLocalServiceTax['status_id']				            = KStatus::PENDING;
                            $arrLocalServiceTax['created_by']				            = $intUserID;
                                        
                            $intLSTBranch = $this->database()->createRecord('lst_branch', $arrLocalServiceTax, array('created_date' => KetrouteApplication::db()->getNowExpression()));
                            $arrRevenueData['lst'][$intLSTBranch] = $intLSTBranch;
                            //need to create lst code
                            $branchCode=LocalServiceTaxManager::getLSTcode($arrLocalServiceTax['lst_type_id']);													
                            $this->database()->updateRecord('lst_branch', array('branch_code' =>$branchCode), array('id' => $intLSTBranch), $one_record = true);	
                        }
                        break;
                    case 'property':	
                        // set empty revenue data holder
                        $arrRevenueData['vehicle'] = array();																				
                        foreach($branch_items as $key => $details){
                                                                                                    
                            $arrProperty = array();
                            $arrProperty['customer_id']				            = $intCustomer;
                            $propertyno =  KetrouteApplication::instance()->database()->getStaticTableValue('property', $id_field = 'id', $return_field = 'property_no', $id_value = $details['vehicle_']['ap_property_no']);
                            $arrProperty['property_no']				            		= $propertyno;
                            $arrProperty['rating_zone_id']				            		= $details['vehicle_']['ap_rating_zone_id'];
                            $arrProperty['house_no']			            	= $details['vehicle_']['ap_house_no'];
                            $arrProperty['plot_no']		            	= $details['vehicle_']['ap_plot_no'];
                            $arrProperty['address']  						= $details['vehicle_']['ap_address'];
                            $arrProperty['gprs_cordinate_x']				        = $details['vehicle_']['ap_gprs_cordinate_x'];
                            $arrProperty['gprs_cordinate_y']	 	            	= $details['vehicle_']['ap_gprs_cordinate_y'];
                            $arrProperty['property_type_id']			        	= $details['vehicle_']['ap_property_type_id'];
                            $arrProperty['sub_property_type_id']		                = $details['vehicle_']['ap_sub_property_type_id'];
                            $arrProperty['property_rented_status_id']				        = $details['vehicle_']['ap_property_rented_status_id'];	
                            $arrProperty['serial_no']		            	=KetrouteApplication::instance()->database()->getStaticTableValue('property', $id_field = 'id', $return_field = 'serial_no', $id_value = $details['vehicle_']['ap_property_no']);
                            $arrProperty['division_id']		                = $details['vehicle_']['ap_division_id'];
                            $arrProperty['parish_id']				        = $details['vehicle_']['ap_parish_id'];
                            $arrProperty['village_id']			                = $details['vehicle_']['ap_village_id'];
                            $arrProperty['street_id']		            = $details['vehicle_']['ap_street_id'];
                            $arrProperty['block_no']		            = $details['vehicle_']['ap_block_no'];
                            $arrProperty['flat_no']		            = $details['vehicle_']['ap_flat_no'];
                            $arrProperty['particulars_frontages']		    =KetrouteApplication::instance()->database()->getStaticTableValue('property', $id_field = 'id', $return_field = 'particulars_frontages', $id_value = $details['vehicle_']['ap_property_no']);
                            $arrProperty['gross_value']		                = $details['vehicle_']['ap_gross_value'];
                            $arrProperty['rateable_value']		        	= $details['vehicle_']['ap_rateable_value'];
                            $arrProperty['current_rateable_value']		    = $details['vehicle_']['ap_current_rateable_value'];
                            $arrProperty['status_id']				            = KStatus::PENDING;
                            $arrProperty['created_by']				            = $intUserID;
                            $oldRefID 									= $details['vehicle_']['ap_property_no'];			
                            $newRefID = $this->database()->createRecord('property', $arrProperty, array('created_date' => KetrouteApplication::db()->getNowExpression()));
                            $arrRevenueData['property'][$newRefID] 		= $newRefID;														
                            
                            $arrAmendLink 								= 	array();
                            $arrAmendLink['amendment_id']				= 	$intAmend;
                            $arrAmendLink['reference_name']				= 	'property';
                            $arrAmendLink['old_reference_id']			=	$oldRefID;
                            $arrAmendLink['new_reference_id']			=	$newRefID;
                            $arrAmendLink['status_id']					=	KStatus::PENDING;
                            $arrAmendLink['created_by']					= 	$intUserID;
                            $this->database()->createRecord('amendment_link', $arrAmendLink, array('created_date' => KetrouteApplication::db()->getNowExpression()));
                            
                        }
                        break;
                    
                    //Added by Kyazze Moses
                    // 22/02/2020 Amendent of outdoor applications
                    case 'outdoor':								
                        $arrRevenueData['outdoor'] = array();									
                        
                        foreach($branch_items as $vehicle_key => $details){
                                                                
                            // set empty revenue data holder
                            $arrOutdoor = array();
                            $arrOutdoor['outdoor_type_id']			= $details['gen_']['outdoor_type_id'];
                            $arrOutdoor['outdoor_category_id']		= $details['gen_']['outdoor_category_id'];
                            $arrOutdoor['outdoor_subcategory_id']	= $details['gen_']['outdoor_subcategory_id'];
                            //$arrOutdoor['amount']					= $details['gen_']['outdoor_amount'];
                            $arrOutdoor['branch_code']				= $details['gen_']['ap_branch_code'];
                            $arrOutdoor['x_coordinates']			= $details['gen_']['gprs_cordinate_x'];
                            $arrOutdoor['y_coordinates']			= $details['gen_']['gprs_cordinate_y'];
                            $arrOutdoor['status_id']				= KStatus::AMENDMENT;
                            
                            if($details['gen_']['outdoor_type_id'] == 1){
                                                                            
                                $arrOutdoor['agent_name'] 		= $details['agent_']['agent_name'];
                                $arrOutdoor['tin'] 				= $details['agent_']['tin'];
                                $arrOutdoor['district_id'] 		= $details['agent_']['district_id'];
                                $arrOutdoor['county_id'] 		= $details['agent_']['county_id'];
                                $arrOutdoor['subcounty_id'] 		= $details['agent_']['sub_county_id'];
                                $arrOutdoor['plot_no'] 			= $details['agent_']['plot_number'];
                                $arrOutdoor['building_name'] 	= $details['agent_']['building_name'];
                                $arrOutdoor['house_no'] 			= $details['agent_']['house_number'];
                                $arrOutdoor['office_no'] 		= $details['agent_']['office_no'];
                                $arrOutdoor['contact_person_id'] = $details['agent_']['contact_person_id'];
                                $arrOutdoor['contact_telephone'] = $details['agent_']['contact_telephone'];
                                $arrOutdoor['contact_mobile'] 	= $details['agent_']['contact_mobile'];
                                $arrOutdoor['contact_email'] 				= $details['agent_']['email'];     
                                                        
                            }
                            else if($details['gen_']['outdoor_type_id'] == 2){
                                $arrOutdoor['trading_license_no']	= $details['tool_']['trading_license_no']; 
                                $arrOutdoor['tool_height'] 			= $details['tool_']['tool_height'];
                                $arrOutdoor['no_sides_id']			= $details['tool_']['no_sides_id'];  
                                $arrOutdoor['material_id']			= $details['tool_']['material_id']; 
                                $arrOutdoor['total_no_allocation']	= $details['tool_']['total_no_allocation']; 
                                $arrOutdoor['tool_nature_id']		= $details['tool_']['tool_nature_id'];
                                $arrOutdoor['division_id']		= $details['tool_']['lst_division_id'] ;
                                $arrOutdoor['landmark']			= $details['tool_']['landmark']; 
                                $arrOutdoor['remarks']			= $details['tool_']['remarks']; 
                                $arrOutdoor['street_id']		= $details['tool_']['outdoor_street'];
                            }
                            else if($details['gen_']['outdoor_type_id'] == 3){
                                    
                                $arrOutdoor['applicant_type_id']= $details['sign_']['applicant_type_id'];
                                $arrOutdoor['tool_height']		= $details['sign_']['tool_height']; 
                                $arrOutdoor['no_sides_id']		= $details['sign_']['no_sides_id']; 
                                $arrOutdoor['material_id']		= $details['sign_']['material_id']; 
                                $arrOutdoor['division_id']		= $details['sign_']['lst_division_id']; 
                                $arrOutdoor['landmark']			= $details['sign_']['landmark']; 
                                $arrOutdoor['remarks']			= $details['sign_']['remarks'];
                                $arrOutdoor['street_id']		= $details['sign_']['outdoor_street'];                                 
                            }								
                                                                                                    
                            $intOutdoorID 	= $this->database()->createRecord('outdoor', $arrOutdoor, array('created_date' => KetrouteApplication::db()->getNowExpression())); 
                            $arrRevenueData['outdoor'][$intOutdoorID] 		= $intOutdoorID;
                            
                            $arrAmendLink 								= 	array();
                            $arrAmendLink['amendment_id']				= 	$intAmend;
                            $arrAmendLink['reference_name']				= 	'outdoor';
                            $arrAmendLink['old_reference_id']			=	$oldRefID;
                            $arrAmendLink['new_reference_id']			=	$intOutdoorID;
                            $arrAmendLink['status_id']					=	KStatus::PENDING;
                            $arrAmendLink['created_by']					= 	$intUserID;
                            $this->database()->createRecord('amendment_link', $arrAmendLink, array('created_date' => KetrouteApplication::db()->getNowExpression()));
                            
                        }
                        break;
                }
            }					
            // save comment
            if(is_int($arrSessionData['coin-reason']['ref'])){
                $arrCallTracking = array();
                $arrCallTracking['support_call_id'] 		= $objCall->id;
                $arrCallTracking['comments'] 				= 'Amendment request posted under amendment reference number '.$strReferenceNumber;
                $arrCallTracking['support_call_status_id'] 	= CallManager::CALL_STATUS_ACKNOWLEDGED;
                $arrCallTracking['created_by'] 				= $intUserID;
                
                $intCallTrackingID = KetrouteApplication::db()->createRecord('support_call_tracking',$arrCallTracking, array('created_date' => $this->database()->getNowExpression()));
            
                // Capture Audit Trail
                $this->logAuditTrail("Query Acknowledged", 'support_call', $objCall->id);
        
            
                // has assignee
                if($objCall->assigned_to){
                    // send ticket closure using shell script
                    $this->callShellscript($this->getComponentRealname(), 'update-call-notification', $option = null, $params = array( 'ref' => $objCall->reference_number));
                }
                // has reporter
                if($objCall->reported_by){
                    // send ticket closure using shell script
                    $this->callShellscript($this->getComponentRealname(), 'reporter-notification', $option = null, $params = array( 'ref' => $objCall->reference_number));
                }
            }
            
        
            $this->logAuditTrail("Submitted application for branch amendment", 'registration', $intAmend);
            
            // send a notification
            CustomerManager::sendCustomerAmendmentApplicationNotification($objCustomer, $strReferenceNumber);
                            
            $this->ui()->setCallback("\$(\"#process-confirmation-info\").hide();");		
            $message = KLanguage::getWord('registration-amendment-submitted', array('links' => $strRegistrationLink,'reference_number' => $strReferenceNumber));
        
        }

        $status = 200;					
    }		
}else{
    $message = "Method not Allowed";
}

echo json_encode([
    "message" => $message,
    "status" => $status,
]);
exit;

