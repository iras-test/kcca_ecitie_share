use ecitie;


-- Insert rows into table 'TableName'
INSERT INTO ground_of_objection
( -- columns to insert data into
 name, status_id
)
VALUES
( -- first row: values for the columns in the list above
 'Objection On Value',1
),
( -- second row: values for the columns in the list above
 'Owner Occupied', 1
),
( -- second row: values for the columns in the list above
 'Under Construction', 1
),
( -- second row: values for the columns in the list above
 'Demolished', 1
)