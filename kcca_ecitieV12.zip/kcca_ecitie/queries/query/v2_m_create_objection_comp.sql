
use ecitie;

update [dbo].[component]  set permissions = 'list,cases,action,close-case,create-payment-plan,payment-plan-list,view-payment-plan,payment-plan-approval-action,create-agency-notice,view-agency-notice,create-business-seal,agency-notice-preview,agency-notice-approval-action,view-business-seal,case-details,escalate-case,objection-list,file-objection,view-objection', module_permission_map = 'list:list' where title = 'arrears'
update [dbo].[component]  set blocked_dptm = 'action,close-case,create-payment-plan,view-payment-plan,payment-plan-approval-action,create-agency-notice,view-agency-notice,create-business-seal,agency-notice-preview,agency-notice-approval-action,view-business-seal,case-details,escalate-case,file-objection,view-objection' where title = 'arrears'