USE ecitie;

update [dbo].[component]  set permissions = 'list,cases,action,close-case,create-payment-plan,payment-plan-list,view-payment-plan,payment-plan-approval-action,create-agency-notice,view-agency-notice,create-business-seal,agency-notice-preview,agency-notice-approval-action,view-business-seal,case-details,escalate-case', module_permission_map = 'list:list' where title = 'arrears'
update [dbo].[component]  set blocked_dptm = 'action,close-case,create-payment-plan,view-payment-plan,payment-plan-approval-action,create-agency-notice,view-agency-notice,create-business-seal,agency-notice-preview,agency-notice-approval-action,view-business-seal,case-details,escalate-case' where title = 'arrears'
update [dbo].[component]  set blocked_dptm = 'report_modules,data' where title = 'reports-api'
