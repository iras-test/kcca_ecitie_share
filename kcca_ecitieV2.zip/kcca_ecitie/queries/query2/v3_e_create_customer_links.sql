
use ecitie;

UPDATE [dbo].[component] 
SET [module_frontend_restriction] = 'list,view,cases,case-details'
where [title] = 'arrears'