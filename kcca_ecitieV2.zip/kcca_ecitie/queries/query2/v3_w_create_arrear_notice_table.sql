use ecitie;

CREATE TABLE [dbo].[arrear_notice](
	[id] [INT] IDENTITY(1,1) NOT NULL,
    [user_id] INT NULL,
    [subject] [VARCHAR](255) NULL,
    [body] [VARCHAR](255) NULL,
    [delete_on_view] INT NULL,
    [status_id] [SMALLINT] DEFAULT 1,
    [created_by] [INT] NULL,
    [created_date] [DATETIME2](0) NULL,
    [modified_by] [INT] NULL,
    [modified_date] [DATETIME2](0) NULL,
)