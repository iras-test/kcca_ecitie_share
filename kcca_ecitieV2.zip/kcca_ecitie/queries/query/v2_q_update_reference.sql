

use ecitie;

update [dbo].[recovery_trail_reference] set reference_name = 'trading_license' where reference_name = 'trade_license'
update [dbo].[recovery_trail_reference] set reference_name = 'groundrent' where reference_name = 'ground_rent'