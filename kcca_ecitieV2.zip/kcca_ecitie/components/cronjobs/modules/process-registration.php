<?php
file_put_contents('c:/max/sample2.txt', print_r($GLOBALS, true));