<?php
/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');


set_time_limit(0);

echo "\n--begin--: ".__FILE__;
try{
	// check for index 5 = sms queueing file
	if(isset ($GLOBALS['argv'][5])){
		// the file with queue items
		$strQueueFile = $GLOBALS['argv'][5];
		
		// check file exists
		if(KFile::exists($strQueueFile) && KFile::isExtension($strQueueFile, PaymentManager::PAYMENT_REGISTRATION_FILE_EXT) && KFile::size($strQueueFile)){
			
			// get items in file
			$strData = KFile::getContent($strQueueFile);
			
			// valid data found
			if(!empty($strData) && KValidate::isDigit($strData)){
				
				// run cancellation of pending payments
				PaymentManager::cancelPendingPayments($strData);
				
				// delete the file
				KFile::deleteFile($strQueueFile);
			}
			else{
				// delete the file
				KFile::deleteFile($strQueueFile);
				
				// delete file
				throw new Exception('Empty Payment Registration Queue: '.print_r($strQueueFile, true));	
			}
		}
		else{
			// ignore proocess
			throw new Exception('Invalid Payment Registration Queue: '.print_r($strQueueFile, true));
		}
	}
}
catch(Exception $e){
	// do notiing with errors
	$this->captureErrorLog(null,ErrorLogManager::ERROR_TYPE_EXCEPTION,'Failed to run: Payment Registration Queue',print_r($e->getMessage(), true));
}
echo "\n--end--";