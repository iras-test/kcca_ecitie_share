<?php
/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin
 	
		$arrCustomer = array();		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_TABLE_NAME] 			= 'customer';		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXPORT_FIELDS] 		= array('firstname','surname','entity_legal_name','coin','balance','mobile','email','mobile','customer_type_id');		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_LIST_FIELDS] 		= array('customer_type_id','balance','entity_legal_name','mobile','date_of_incorporation','email','telephone','coin','firstname','surname','middle_name','status_id','transactional_status');				
		$arrCustomer[KSystemManager::ITEM_PROPERTY_VIEW_FIELDS] 		= array('customer_type_id','entity_legal_name','balance','mobile','date_of_incorporation','email','telephone','coin','firstname','surname','middle_name','transactional_status');

		$arrCustomer[KSystemManager::ITEM_PROPERTY_ADD_FIELDS] 			= array('box_district_id','county_id','sub_county_id','entity_legal_name','mobile','date_of_incorporation');																								
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EDIT_FIELDS] 		= array('box_district_id','county_id','sub_county_id','entity_legal_name','mobile','date_of_incorporation');																								
		$arrCustomer[KSystemManager::ITEM_PROPERTY_IMPORT_FIELDS] 		= array('entity_legal_name' => true,'mobile' => false);																						
		$arrCustomer[KSystemManager::ITEM_PROPERTY_INVISIBLE_FIELDS] 	= array('status_id','notice_number');	// do not show on list and export																					

		// do not show column width on list page
		$arrCustomer[KSystemManager::ITEM_PROPERTY_HIDE_COL_WIDTHS] 	= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_HIDE_LIST_LABELS] 	= true;
		
		// mobile number is used as unique identifier
		$arrCustomer[KSystemManager::ITEM_PROPERTY_DUPLICATE_CHECK] 	= null;
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS] 	= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['verify']= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['verify'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_ICON] 					= "[site_url]components/{$this->getComponentRealname()}/images/{$this->getComponentRealname()}-verify16x16.png";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['verify'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_COMPONENT] 	= $this->getComponentRealname();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['verify'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_MODULE] 		= 'verify';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['verify'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LABEL] 					= "{$this->getComponentRealname()}-verify";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['verify'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LINK] 					= "[url_in_use]{$this->getComponentRealname()}/verify/id/[id]/";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['verify'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_TAGS] 					= array('id' => 'id');
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['verify'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_CLASS] 					= 'customer-list-verify-button';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['verify'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_VIA_AJAX] 				= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['verify'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_IF_EVAL] 					= array('CustomerManager', 'requireVerification');
		
				
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['debtors-ledger']= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['debtors-ledger'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_COMPONENT] 		= $this->getComponentRealname();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['debtors-ledger'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_MODULE] 			= 'debtors-ledger';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['debtors-ledger'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LABEL] 						= "customer-debtors-ledger";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['debtors-ledger'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LINK] 						= "[url_in_use]customer/debtors-ledger/id/[id]/"; 
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['debtors-ledger'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_TAGS] 						= array('id' => 'id');
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['debtors-ledger'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_CLASS] 						= 'customer-debtors-ledger-button';
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['reset-pin']= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['reset-pin'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_ICON] 						= "[site_url]components/{$this->getComponentRealname()}/images/{$this->getComponentRealname()}-reset-pin16x16.png";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['reset-pin'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_COMPONENT] 		= $this->getComponentRealname();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['reset-pin'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_MODULE] 		= 'reset-pin';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['reset-pin'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LABEL] 					= "{$this->getComponentRealname()}-reset-pin";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['reset-pin'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LINK] 						= "[url_in_use]{$this->getComponentRealname()}/reset-pin/id/[id]/";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['reset-pin'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_TAGS] 						= array('id' => 'id');
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['reset-pin'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_CLASS] 					= 'customer-list-reset-pin-button';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['reset-pin'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_VIA_AJAX] 					= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['reset-pin'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_IF_EVAL] 					= array('CustomerManager', 'isActive');
				
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['additional-branch']= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['additional-branch'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_ICON] 						= "[site_url]components/{$this->getComponentRealname()}/images/{$this->getComponentRealname()}-additional-branch16x16.png";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['additional-branch'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_COMPONENT] 		= $this->getComponentRealname();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['additional-branch'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_MODULE] 		= 'additional-branch';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['additional-branch'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LABEL] 					= "{$this->getComponentRealname()}-additional-branch";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['additional-branch'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LINK] 						= "[url_in_use]{$this->getComponentRealname()}/additional-branch/id/[id]/";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['additional-branch'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_TAGS] 						= array('id' => 'id');
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['additional-branch'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_CLASS] 					= 'customer-list-additional-branch-button';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['additional-branch'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_VIA_AJAX] 					= false;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['additional-branch'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_IF_EVAL] 					= array('CustomerManager', 'isActive');
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['list-email']= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['list-email'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_ICON] 					= "[site_url]components/email/images/email16x16.png";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['list-email'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_COMPONENT] 	= 'email';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['list-email'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_MODULE] 		= 'list';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['list-email'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LABEL] 					= 'email-list';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['list-email'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LINK] 					= "[url_in_use]email/list/fbrn/customer/fbri/[id]/";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['list-email'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_TAGS] 					= array('id' => 'id');
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['list-sms']= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['list-sms'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_ICON] 					= "[site_url]components/sms/images/sms16x16.png";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['list-sms'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_COMPONENT] 	= 'sms';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['list-sms'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_MODULE] 		= 'list';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['list-sms'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LABEL] 					= 'sms-list';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['list-sms'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LINK] 					= "[url_in_use]sms/list/fbrn/customer/fbri/[id]/";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['list-sms'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_TAGS] 					= array('id' => 'id');
				
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['list-payment']= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['list-payment'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_ICON] 					= "[site_url]components/payment/images/payment16x16.png";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['list-payment'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_COMPONENT] 	= 'payment';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['list-payment'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_MODULE] 		= 'list';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['list-payment'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LABEL] 					= 'payment-list';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['list-payment'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LINK] 					= "[url_in_use]payment/list/fbcs/[id]/";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['list-payment'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_TAGS] 					= array('id' => 'id');
				
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['vehicle']= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['vehicle'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_ICON] 					= "[site_url]components/vehicle/images/vehicle16x16.png";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['vehicle'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_COMPONENT] 	= 'vehicle';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['vehicle'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_MODULE] 		= 'list';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['vehicle'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LABEL] 					= "vehicle-items";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['vehicle'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LINK] 					= "[url_in_use]vehicle/list/fbcs/[id]/";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['vehicle'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_TAGS] 					= array('id' => 'id');
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['vehicle'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_CLASS] 					= 'vehicle-list-vehicle-button';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['vehicle'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_VIA_AJAX] 				= false;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['vehicle'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_IF_EVAL] 				= null;
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['property']= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['property'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_ICON] 					= "[site_url]components/property/images/property16x16.png";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['property'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_COMPONENT] 	= 'property';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['property'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_MODULE] 		= 'list';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['property'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LABEL] 					= "properties";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['property'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LINK] 					= "[url_in_use]property/list/fbcs/[id]/";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['property'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_TAGS] 					= array('id' => 'id');
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['property'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_CLASS] 					= 'vehicle-list-vehicle-button';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['property'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_VIA_AJAX] 				= false;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['property'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_IF_EVAL] 				= null;
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['register-payment']= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['register-payment'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_ICON] 					= "[site_url]components/payment/images/payment-register-payment16x16.png";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['register-payment'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_COMPONENT] 	= 'payment';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['register-payment'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_MODULE] 		= 'register-payment';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['register-payment'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LABEL] 					= 'payment-register-payment';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['register-payment'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LINK] 					= "[url_in_use]payment/register-payment/?coin=[coin]&";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['register-payment'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_TAGS] 					= array('coin' => 'coin');
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['register-payment'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_IF_EVAL] 				= array('CustomerManager', 'isActive');
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['register-payment'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_CLASS] 					= 'payment-register-payment-button';
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['reactivate-coin']= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['reactivate-coin'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_ICON] 					= "[site_url]components/registration/images/registration-reactivate-coin16x16.png";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['reactivate-coin'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_COMPONENT] 	= 'registration';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['reactivate-coin'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_MODULE] 		= 'reactivate-coin';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['reactivate-coin'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LABEL] 					= 'registration-reactivate-coin';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['reactivate-coin'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LINK] 					= "[url_in_use]registration/reactivate-coin/?coin=[coin]&";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['reactivate-coin'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_TAGS] 					= array('coin' => 'coin');
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['reactivate-coin'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_IF_EVAL] 				= array('CustomerManager', 'isInActive');
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['reactivate-coin'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_CLASS] 					= 'registration-reactivate-coin-button';
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['deactivate-coin']= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['deactivate-coin'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_ICON] 					= "[site_url]components/registration/images/registration-deactivate-coin16x16.png";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['deactivate-coin'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_COMPONENT] 	= 'registration';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['deactivate-coin'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_MODULE] 		= 'deactivate-coin';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['deactivate-coin'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LABEL] 					= 'registration-deactivate-coin';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['deactivate-coin'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LINK] 					= "[url_in_use]registration/deactivate-coin/?coin=[coin]&";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['deactivate-coin'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_TAGS] 					= array('coin' => 'coin');
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['deactivate-coin'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_IF_EVAL] 				= array('CustomerManager', 'isActive');
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['deactivate-coin'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_CLASS] 					= 'registration-deactivate-coin-button';
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['amendment-of-registration']= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['amendment-of-registration'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_ICON] 						= "[site_url]components/registration/images/registration-amendment-of-registration16x16.png";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['amendment-of-registration'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_COMPONENT] 		= 'registration';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['amendment-of-registration'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_MODULE] 		= 'amendment-of-registration';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['amendment-of-registration'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LABEL] 					= 'registration-amendment-of-registration';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['amendment-of-registration'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LINK] 						= "[url_in_use]registration/amendment-of-registration/?coin=[coin]&";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['amendment-of-registration'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_TAGS] 						= array('coin' => 'coin');
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['amendment-of-registration'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_IF_EVAL] 					= array('CustomerManager', 'isActive');
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['amendment-of-registration'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_CLASS] 					= 'registration-amendment-of-registration-button';
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['post-registration-verification']= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['post-registration-verification'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_ICON] 					= "[site_url]components/registration/images/registration-post-registration-verification16x16.png";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['post-registration-verification'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_COMPONENT] 	= 'registration';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['post-registration-verification'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_MODULE] 		= 'post-registration-verification';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['post-registration-verification'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LABEL] 					= 'registration-post-registration-verification';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['post-registration-verification'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LINK] 					= "[url_in_use]registration/post-registration-verification/?coin=[coin]&";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['post-registration-verification'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_TAGS] 					= array('coin' => 'coin');
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['post-registration-verification'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_IF_EVAL] 					= array('CustomerManager', 'isActive');
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['post-registration-verification'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_CLASS] 					= 'registration-post-registration-verification-button';					
			
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['application-additional-branch']= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['application-additional-branch'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_ICON] 						= "[site_url]components/registration/images/registration-application-additional-branch16x16.png";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['application-additional-branch'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_COMPONENT] 		= 'registration';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['application-additional-branch'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_MODULE] 		= 'application-additional-branch';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['application-additional-branch'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LABEL] 					= 'registration-application-additional-branch';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['application-additional-branch'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LINK] 						= "[url_in_use]registration/application-additional-branch/?coin=[coin]&";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['application-additional-branch'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_TAGS] 						= array('coin' => 'coin');
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['application-additional-branch'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_IF_EVAL] 					= array('CustomerManager', 'isActive');
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['application-additional-branch'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_CLASS] 					= 'registration-application-additional-branch-button';					
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['list-of-registration']= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['list-of-registration'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_ICON] 						= "[site_url]components/registration/images/registration16x16.png";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['list-of-registration'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_COMPONENT] 		= 'registration';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['list-of-registration'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_MODULE] 			= 'list';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['list-of-registration'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LABEL] 						= 'registration-list-of-registration';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['list-of-registration'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LINK] 						= "[url_in_use]registration/list/fbcs/[id]/";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['list-of-registration'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_TAGS] 						= array('id' => 'id');
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['list-of-registration'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_CLASS] 						= 'registration-application-list-button';					
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['allocate-document']= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['allocate-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_ICON] 						= "[site_url]components/{$this->getComponentRealname()}/images/{$this->getComponentRealname()}-allocate-document16x16.png";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['allocate-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_COMPONENT] 		= $this->getComponentRealname();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['allocate-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_MODULE] 		= 'allocate-document';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['allocate-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LABEL] 					= "{$this->getComponentRealname()}-allocate-document";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['allocate-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LINK] 						= "[url_in_use]{$this->getComponentRealname()}/allocate-document/id/[id]/";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['allocate-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_TAGS] 						= array('id' => 'id');
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['allocate-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_CLASS] 					= 'customer-list-allocate-document-button';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['allocate-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_VIA_AJAX] 					= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['allocate-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_IF_EVAL] 					= array('CustomerManager', 'isNotAllocated');
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['locate-document']= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['locate-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_ICON] 						= "[site_url]components/{$this->getComponentRealname()}/images/{$this->getComponentRealname()}-locate-document16x16.png";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['locate-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_COMPONENT] 		= $this->getComponentRealname();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['locate-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_MODULE] 			= 'locate-document';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['locate-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LABEL] 						= "{$this->getComponentRealname()}-locate-document";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['locate-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LINK] 						= "[url_in_use]{$this->getComponentRealname()}/locate-document/id/[id]/";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['locate-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_TAGS] 						= array('id' => 'id');
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['locate-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_CLASS] 						= 'customer-list-locate-document-button';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['locate-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_VIA_AJAX] 					= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['locate-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_IF_EVAL] 					= array('CustomerManager', 'isAllocated');
			
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['checkout-document']= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['checkout-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_ICON] 						= "[site_url]components/{$this->getComponentRealname()}/images/{$this->getComponentRealname()}-checkout-document16x16.png";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['checkout-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_COMPONENT] 		= $this->getComponentRealname();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['checkout-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_MODULE] 		= 'checkout-document';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['checkout-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LABEL] 					= "{$this->getComponentRealname()}-checkout-document";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['checkout-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LINK] 						= "[url_in_use]{$this->getComponentRealname()}/checkout-document/id/[id]/";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['checkout-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_TAGS] 						= array('id' => 'id');
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['checkout-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_CLASS] 					= 'customer-list-checkout-document-button';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['checkout-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_VIA_AJAX] 					= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['checkout-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_IF_EVAL] 					= array('CustomerManager', 'isAllocated');
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['checkin-document']= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['checkin-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_ICON] 						= "[site_url]components/{$this->getComponentRealname()}/images/{$this->getComponentRealname()}-checkin-document16x16.png";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['checkin-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_COMPONENT] 		= $this->getComponentRealname();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['checkin-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_MODULE] 			= 'checkin-document';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['checkin-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LABEL] 						= "{$this->getComponentRealname()}-checkin-document";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['checkin-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LINK] 						= "[url_in_use]{$this->getComponentRealname()}/checkin-document/id/[id]/";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['checkin-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_TAGS] 						= array('id' => 'id');
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['checkin-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_CLASS] 						= 'customer-list-checkin-document-button';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['checkin-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_VIA_AJAX] 					= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['checkin-document'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_IF_EVAL] 					= array('CustomerManager', 'isCheckedout');
			
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['business']= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['business'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_ICON] 						= "[site_url]components/{$this->getComponentRealname()}/images/{$this->getComponentRealname()}-checkin-document16x16.png";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['business'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_COMPONENT] 		= 'business';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['business'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_MODULE] 			= 'list';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['business'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LABEL] 						= "Business-Items";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['business'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LINK] 						= "[url_in_use]business/list/fbcs/[id]/";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['business'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_TAGS] 						= array('id' => 'id');
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['business'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_CLASS] 						= 'customer-list-checkin-document-button';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['business'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_VIA_AJAX] 					= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['business'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_IF_EVAL] 					= null;
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['localservicetax']= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['localservicetax'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_ICON] 						= "[site_url]components/{$this->getComponentRealname()}/images/{$this->getComponentRealname()}-checkin-document16x16.png";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['localservicetax'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_COMPONENT] 		= 'localservicetax';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['localservicetax'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_MODULE] 			= 'list';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['localservicetax'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LABEL] 						= "localservicetax-items";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['localservicetax'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LINK] 						= "[url_in_use]localservicetax/list/fbcs/[id]/";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['localservicetax'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_TAGS] 						= array('id' => 'id');
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['localservicetax'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_CLASS] 						= 'customer-list-checkin-document-button';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['localservicetax'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_VIA_AJAX] 					= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['localservicetax'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_IF_EVAL] 					= null;

		//Added by Eric Lubega for Local Hotel Tax on 31/05/2018

		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['localhoteltax']= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['localhoteltax'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_ICON] 						= "[site_url]components/{$this->getComponentRealname()}/images/{$this->getComponentRealname()}-checkin-document16x16.png";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['localhoteltax'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_COMPONENT] 		= 'local-hotel-tax';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['localhoteltax'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_PERMISSION_MODULE] 		= 'list';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['localhoteltax'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LABEL] 					= "localhoteltax-items";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['localhoteltax'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_LINK] 						= "[url_in_use]local-hotel-tax/list/fbcs/[id]/";
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['localhoteltax'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_TAGS] 						= array('id' => 'id');
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['localhoteltax'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_CLASS] 					= 'customer-list-checkin-document-button';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['localhoteltax'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_VIA_AJAX] 					= false;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS]['localhoteltax'][KSystemManager::ITEM_PROPERTY_EXTRA_LIST_ACTIONS_IF_EVAL] 					= null;
				
		$arrCustomer[KSystemManager::ITEM_PROPERTY_CALLBACK] = array();																									
		$arrCustomer[KSystemManager::ITEM_PROPERTY_SEARCH_FIELDS] 		= array('coin','firstname','surname', 'entity_legal_name');		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_SORT_FIELDS] 		= array('firstname' => KSystemManager::SORT_ASCENDING, 'surname' => KSystemManager::SORT_ASCENDING, 'entity_legal_name' => KSystemManager::SORT_ASCENDING);
		$arrCustomer[KSystemManager::ITEM_PROPERTY_PRIMARY_KEY] 		= 'id';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_TITLE_FIELD] 		=  'entity_legal_name';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS] 				= array();   
				
		// filtering stats here
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER] 		= array();
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbct'] = array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbct'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE] 		= KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_DATABASE;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbct'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_FIELD] 		= 'customer_type_id';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbct'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_LABEL] 		= 'customer-type';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbct'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_DATA] 		= array(KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_DATABASE_TABLE_NAME 				=> 'customer_type',
																																		KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_DATABASE_ID_FIELD 		=> 'id',
																																		KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_DATABASE_VALUE_FIELD 	=> array('name',':','description'),
																																		KSystemManager::WHERE_CLAUSE 											=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																		KSystemManager::ORDER_BY 												=> array('name' => KSystemManager::SORT_ASCENDING),
																																		);
		
		
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbst'] = array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbst'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE] 		= KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_ARRAY;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbst'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_FIELD] 		= 'status_id';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbst'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_LABEL] 		= 'customer-account-status';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbst'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_DATA] 		= array(KStatus::ACTIVE => KLanguage::getWord('active'), KStatus::PENDING => KLanguage::getWord('pending'), KStatus::SUSPENDED => KLanguage::getWord('suspended'), KStatus::REJECTED => KLanguage::getWord('rejected'), KStatus::NOT_VERIFIED => KLanguage::getWord('not-verified'), KStatus::INACTIVE => KLanguage::getWord('in-active') );	
				
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbdt'] = array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbdt'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE] 		= KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_DATABASE;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbdt'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_FIELD] 		= 'residential_address_district_id';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbdt'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_LABEL] 		= 'customer-district';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbdt'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_DATA] 		= array(KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_DATABASE_TABLE_NAME 	=> 'district',
																																		KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_DATABASE_ID_FIELD 		=> 'id',
																																		KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_DATABASE_VALUE_FIELD 	=> 'name',
																																		KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_DATABASE_VALUE_FIELD 	=> 'name',
																																		KSystemManager::WHERE_CLAUSE 											=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																		KSystemManager::ORDER_BY 												=> array('name' => KSystemManager::SORT_ASCENDING),
																																		);
																																					
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbcn'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE] 			= KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_DATABASE;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbcn'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_FIELD] 			= 'residential_address_county_id';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbcn'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_LABEL] 			= 'customer-county';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbcn'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_HIDE_IN_FORM] 	= $this->isParam('fbdt') ? false : true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbcn'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_DATA] 			= array(KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_DATABASE_TABLE_NAME 				=> 'county',
																																			KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_DATABASE_ID_FIELD 		=> 'id',
																																			KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_DATABASE_VALUE_FIELD 	=> 'name',
																																			KSystemManager::WHERE_CLAUSE 											=> array(KSystemManager::WHERE_EXACT_MATCH => $this->isParam('fbdt') ? array('status_id' => KStatus::ACTIVE, 'district_id' => $this->getParam('fbdt')) :  array('status_id' => KStatus::ACTIVE)),
																																			KSystemManager::ORDER_BY 												=> array('name' => KSystemManager::SORT_ASCENDING),
																																			);
																																					
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbsc'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE] 			= KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_DATABASE;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbsc'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_FIELD] 			= 'residential_address_sub_county_id';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbsc'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_LABEL] 			= 'customer-sub-county';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbsc'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_HIDE_IN_FORM] 	= $this->isParam('fbcn') ? false : true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbsc'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_DATA] 			= array(KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_DATABASE_TABLE_NAME 					=> 'sub_county',
																																			KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_DATABASE_ID_FIELD 		=> 'id',
																																			KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_DATABASE_VALUE_FIELD 	=> 'name',
																																			KSystemManager::WHERE_CLAUSE 											=> array(KSystemManager::WHERE_EXACT_MATCH => $this->isParam('fbcn') ? array('status_id' => KStatus::ACTIVE, 'county_id' => $this->getParam('fbcn')) : array('status_id' => KStatus::ACTIVE)),
																																			KSystemManager::ORDER_BY 												=> array('name' => KSystemManager::SORT_ASCENDING),
																																			);
																																					
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbpr'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE] 			= KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_DATABASE;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbpr'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_FIELD] 			= 'residential_address_parish_id';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbpr'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_LABEL] 			= 'customer-parish';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbpr'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_HIDE_IN_FORM] 	= $this->isParam('fbsc') ? false : true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbpr'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_DATA] 			= array(KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_DATABASE_TABLE_NAME 					=> 'parish',
																																			KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_DATABASE_ID_FIELD 		=> 'id',
																																			KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_DATABASE_VALUE_FIELD 	=> 'name',
																																			KSystemManager::WHERE_CLAUSE 											=> array(KSystemManager::WHERE_EXACT_MATCH => $this->isParam('fbsc') ? array('status_id' => KStatus::ACTIVE, 'sub_county_id' => $this->getParam('fbsc')) : array('status_id' => KStatus::ACTIVE)),
																																			KSystemManager::ORDER_BY 												=> array('name' => KSystemManager::SORT_ASCENDING),
																																			);
																																					
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbvg'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE] 			= KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_DATABASE;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbvg'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_FIELD] 			= 'residential_address_village_id';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbvg'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_LABEL] 			= 'customer-village';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbvg'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_HIDE_IN_FORM] 	= $this->isParam('fbpr') ? false : true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbvg'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_DATA] 			= array(KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_DATABASE_TABLE_NAME 					=> 'village',
																																			KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_DATABASE_ID_FIELD 		=> 'id',
																																			KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_DATABASE_VALUE_FIELD 	=> 'name',
																																			KSystemManager::WHERE_CLAUSE 											=> array(KSystemManager::WHERE_EXACT_MATCH => $this->isParam('fbpr') ? array('status_id' => KStatus::ACTIVE, 'parish_id' => $this->getParam('fbpr')) : array('status_id' => KStatus::ACTIVE)),
																																			KSystemManager::ORDER_BY 												=> array('name' => KSystemManager::SORT_ASCENDING),
																																			);
																																					
		
																																					
			
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['iuiuu'] = array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['iuiuu'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE] 		= KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_FIELD;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['iuiuu'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_FIELD] 	= 'coin';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['iuiuu'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_LABEL] 	= 'customer-search-coin';
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbeln'] = array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbeln'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE] 		= KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_FIELD;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbeln'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_FIELD] 	= 'entity_legal_name';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbeln'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_LABEL] 	= 'customer-entity-legal-name';
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbcfn'] = array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbcfn'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE] 		= KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_FIELD;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbcfn'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_FIELD] 	= 'firstname';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbcfn'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_LABEL] 	= 'customer-firstname';
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbcsn'] = array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbcsn'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE] 		= KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_FIELD;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbcsn'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_FIELD] 	= 'surname';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbcsn'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_LABEL] 	= 'customer-surname';
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbcmn'] = array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbcmn'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE] 		= KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_FIELD;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbcmn'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_FIELD] 	= 'middle_name';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['fbcmn'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_LABEL] 	= 'customer-middle-name';		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['title_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['title_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['title_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-title';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['title_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['title_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['title_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['title_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['title_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'title',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> 'name',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
																																							KSystemManager::WHERE_CLAUSE 						=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																							KSystemManager::ORDER_BY  							=> array('name' => KSystemManager::SORT_ASCENDING),
																																							);
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['other_title_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['other_title_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 				= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['other_title_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-other-title';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['other_title_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['other_title_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['other_title_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 			= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['other_title_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['contact_relationship_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['contact_relationship_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['contact_relationship_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-relationship';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['contact_relationship_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['contact_relationship_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['contact_relationship_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['contact_relationship_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['contact_relationship_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'contact_relationship',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> 'name',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 		=> 'customer_contact_person' ,
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
																																							KSystemManager::WHERE_CLAUSE 						=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																							KSystemManager::ORDER_BY  							=> array('name' => KSystemManager::SORT_ASCENDING),
																																							);
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['gender_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['gender_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['gender_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-gender';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['gender_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['gender_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['gender_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['gender_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['gender_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'gender',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> 'name',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
																																							KSystemManager::WHERE_CLAUSE 						=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																							KSystemManager::ORDER_BY  							=> array('name' => KSystemManager::SORT_ASCENDING),
																																							);
																																																																												
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['telephone'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['telephone'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 		= KSystemManager::FIELD_TYPE_TELEPHONE ;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['telephone'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'customer-telephone';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['telephone'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= 12;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['telephone'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['telephone'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 	= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['telephone'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 	= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['telephone'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 		= array();
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['fax'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['fax'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_FAX ;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['fax'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-fax';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['fax'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 20;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['fax'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['fax'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['fax'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['fax'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();

		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['email'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['email'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_EMAIL ;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['email'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-email';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['email'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 255;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['email'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['email'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['email'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['email'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();

		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['mobile'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['mobile'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 				= KSystemManager::FIELD_TYPE_INTERNATIONAL_NUMBER;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['mobile'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-mobile';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['mobile'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 12;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['mobile'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['mobile'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 			= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['mobile'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['mobile'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();

		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['second_mobile'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['second_mobile'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 				= KSystemManager::FIELD_TYPE_INTERNATIONAL_NUMBER;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['second_mobile'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-second-mobile';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['second_mobile'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 12;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['second_mobile'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['second_mobile'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['second_mobile'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['second_mobile'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_applicant_type_id'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_applicant_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_applicant_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'customer-applicant-type';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_applicant_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= 200;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_applicant_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_applicant_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_applicant_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_applicant_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_FEED_TO] 			= array( 'customer_business_type_id' 			=> array('CustomerManager',	'getSelectionByApplicantType'));
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_applicant_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'customer_applicant_type',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> 'name',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
																																							KSystemManager::WHERE_CLAUSE 						=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																							KSystemManager::ORDER_BY  							=> array('name' => KSystemManager::SORT_ASCENDING),
																																							);
		
		
		
		
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_business_type_id'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_business_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 				= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_business_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-business-type';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_business_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 200;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_business_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_business_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_business_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_business_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_FEED_FROM] 		= 'customer_applicant_type_id';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_business_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'customer_business_type',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> 'name',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
																																							KSystemManager::WHERE_CLAUSE 						=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																							KSystemManager::ORDER_BY  							=> array('name' => KSystemManager::SORT_ASCENDING),
																																							);
		
		
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['physical_address'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['physical_address'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 		= KSystemManager::FIELD_TYPE_TEXTAREA;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['physical_address'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'customer-physical-address';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['physical_address'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= KSystemManager::DATA_LENGTH_SMALL_FILE ;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['physical_address'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['physical_address'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 	= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['physical_address'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 	= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['physical_address'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 		= array();
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['postal_address'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['postal_address'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXTAREA;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['postal_address'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'customer-postal-address';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['postal_address'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= KSystemManager::DATA_LENGTH_SMALL_FILE;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['postal_address'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['postal_address'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['postal_address'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['postal_address'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 		= array();
		
		
		
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['photo'] 															= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['photo'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 					= KSystemManager::FIELD_TYPE_FILE_UPLOAD;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['photo'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 					= 'customer-photo';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['photo'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 				= KSystemManager::DATA_LENGTH_MEDIUM_FILE;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['photo'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 				= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['photo'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 				= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['photo'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 				= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['photo'][KSystemManager::ITEM_FIELD_PROPERTY_AJAX_UPLOAD] 			= true;
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['photo'][KSystemManager::ITEM_FIELD_PROPERTY_STORAGE_MEDIA] 					= KSystemManager::STORAGE_MEDIA_FILE_SYSTEM;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['photo'][KSystemManager::ITEM_FIELD_PROPERTY_STORAGE_MEDIA_FILE_SYSTEM_PATH] 	= KFW_STORAGE_PATH . $this->getComponentRealname() . DIRECTORY_SEPARATOR;
		

		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['photo'][KSystemManager::ITEM_FIELD_PROPERTY_FILE_TYPE] 				= KSystemManager::FILE_TYPE_WEB_IMAGE;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['photo'][KSystemManager::ITEM_FIELD_PROPERTY_DOWNLOADABLE] 			= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['photo'][KSystemManager::ITEM_FIELD_PROPERTY_IGNORE_UPLOAD_ERROR ] 	= false;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['photo'][KSystemManager::ITEM_FIELD_PROPERTY_OVERWRITE_IF_EXISTS] 		= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['photo'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 					= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['photo'][KSystemManager::ITEM_FIELD_PROPERTY_THUMB_SIZE] 				= 150;
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_type_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-identification-type';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 50;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'identification_type',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> 'name',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 		=> array('customer_business_associate') ,
																																							KSystemManager::WHERE_CLAUSE 						=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																							KSystemManager::ORDER_BY  							=> array('name' => KSystemManager::SORT_ASCENDING),
		                                                                                                                                                    );
																																							
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['citizenship_country_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['citizenship_country_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 				= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['citizenship_country_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-citizenship-country';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['citizenship_country_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 50;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['citizenship_country_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['citizenship_country_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 			= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['citizenship_country_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '223';
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['citizenship_country_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'country',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> 'name',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 		=> array('customer') ,
																																							KSystemManager::WHERE_CLAUSE 						=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																							KSystemManager::ORDER_BY  							=> array('name' => KSystemManager::SORT_ASCENDING),
		                                                                                                                                                    );
		
		/*Default address 
		 * Begin
		 */
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['county_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['county_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['county_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-county';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['county_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 50;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['county_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['county_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['county_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['county_id'][KSystemManager::ITEM_FIELD_PROPERTY_FEED_FROM] 		= 'box_district_id';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['county_id'][KSystemManager::ITEM_FIELD_PROPERTY_FEED_TO] 		= 
															array( 'sub_county_id' 		=> array('SubCountyManager',	'getSelectionByCounty'),
																   'parish_id' 			=> array('',''),
																   'village_id' 		=> array('',''),
																 );
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['county_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'county',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> 'name',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 		=> 'customer_address' ,
																																							KSystemManager::WHERE_CLAUSE 						=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																							KSystemManager::ORDER_BY  							=> array('name' => KSystemManager::SORT_ASCENDING),
		
		                                                                                                                                                    );
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['sub_county_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['sub_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['sub_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-sub-county';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['sub_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 50;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['sub_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['sub_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['sub_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['sub_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_FEED_FROM] 		= 'county_id';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['sub_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_FEED_TO] 		= 
															array( 'parish_id' 			=> array('ParishManager',	'getSelectionBySubCounty'),
																   'village_id' 		=> array('',''),
																  );
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['sub_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'sub_county',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 				=> 'id' , 
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 			=> 'name',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  			=> false,
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 		=> 'customer_address' ,
																																							KSystemManager::WHERE_CLAUSE 								=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																							KSystemManager::ORDER_BY  									=> array('name' => KSystemManager::SORT_ASCENDING),
		
		                                                                                                                                                    );
		
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['parish_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['parish_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['parish_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-parish';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['parish_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 50;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['parish_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['parish_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['parish_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['parish_id'][KSystemManager::ITEM_FIELD_PROPERTY_FEED_FROM] 		= 'sub_county_id';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['parish_id'][KSystemManager::ITEM_FIELD_PROPERTY_FEED_TO] 		= 
															array('village_id' 		=> array('VillageManager','getSelectionByParish'));
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['parish_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'parish',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> 'name',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 		=> 'customer_address' ,
																																							KSystemManager::WHERE_CLAUSE 						=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																							KSystemManager::ORDER_BY  							=> array('name' => KSystemManager::SORT_ASCENDING),
		
		                                                                                                                                                    );
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['village_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['village_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['village_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-village';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['village_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 50;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['village_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['village_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['village_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['village_id'][KSystemManager::ITEM_FIELD_PROPERTY_FEED_FROM] 		= 'parish_id';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['village_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'village',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> 'name',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 		=> 'customer_address' ,
																																							KSystemManager::WHERE_CLAUSE 						=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																							KSystemManager::ORDER_BY  							=> array('name' => KSystemManager::SORT_ASCENDING),
		
		                                                                                                                                                    );
																																							
		/**Default address
		 *  End
		 */																																							
		
		
		
		/* Residential address residential_address_
		 * Begin
		 */
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_district_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_district_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_district_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-district';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_district_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 50;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_district_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_district_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_district_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_district_id'][KSystemManager::ITEM_FIELD_PROPERTY_FEED_TO] 			= 
															array( 'residential_address_county_id' 			=> array('CountyManager',	'getSelectionByDistrict'),
																   'residential_address_sub_county_id' 		=> array('',''),
																   'residential_address_parish_id' 			=> array('',''),
																   'residential_address_village_id' 		=> array('',''),
																 );
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_district_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'district',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> 'name',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 		=> 'customer' ,
																																							KSystemManager::WHERE_CLAUSE 						=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																							KSystemManager::ORDER_BY  							=> array('name' => KSystemManager::SORT_ASCENDING),
		
		                                                                                                                                                    );
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_county_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-county';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 50;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_FEED_FROM] 		= 'residential_address_district_id';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_FEED_TO] 		= 
															array( 'residential_address_sub_county_id' 		=> array('SubCountyManager',	'getSelectionByCounty'),
																   'residential_address_parish_id' 			=> array('',''),
																   'residential_address_village_id' 		=> array('',''),
																 );
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'county',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> 'name',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 		=> 'customer' ,
																																							KSystemManager::WHERE_CLAUSE 						=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																							KSystemManager::ORDER_BY  							=> array('name' => KSystemManager::SORT_ASCENDING),
		
		                                                                                                                                                    );
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_sub_county_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_sub_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_sub_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-sub-county';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_sub_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 50;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_sub_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_sub_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_sub_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_sub_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_FEED_FROM] 		= 'residential_address_county_id';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_sub_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_FEED_TO] 		= 
															array( 'residential_address_parish_id' 			=> array('ParishManager',	'getSelectionBySubCounty'),
																   'residential_address_village_id' 		=> array('',''),
																  );
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_sub_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'sub_county',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> 'name',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 		=> 'customer' ,
																																							KSystemManager::WHERE_CLAUSE 						=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																							KSystemManager::ORDER_BY  							=> array('name' => KSystemManager::SORT_ASCENDING),
		
		                                                                                                                                                    );
		
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_parish_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_parish_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_parish_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-parish';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_parish_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 50;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_parish_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_parish_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_parish_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_parish_id'][KSystemManager::ITEM_FIELD_PROPERTY_FEED_FROM] 		= 'residential_address_sub_county_id';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_parish_id'][KSystemManager::ITEM_FIELD_PROPERTY_FEED_TO] 		= 
															array('residential_address_village_id' 		=> array('VillageManager','getSelectionByParish'));
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_parish_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'parish',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> 'name',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 		=> 'customer' ,
																																							KSystemManager::WHERE_CLAUSE 						=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																							KSystemManager::ORDER_BY  							=> array('name' => KSystemManager::SORT_ASCENDING),
		
		                                                                                                                                                    );
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_village_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_village_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_village_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-village';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_village_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 50;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_village_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_village_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_village_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_village_id'][KSystemManager::ITEM_FIELD_PROPERTY_FEED_FROM] 		= 'residential_address_parish_id';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['residential_address_village_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'village',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> 'name',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 		=> 'customer' ,
																																							KSystemManager::WHERE_CLAUSE 						=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																							KSystemManager::ORDER_BY  							=> array('name' => KSystemManager::SORT_ASCENDING),
		
		                                                                                                                                                    );
																																							
		/**Residential address
		 *  End
		 */																																							
		
		
		/* Previous Business address
		 * Begin
		 */
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_trading_center'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_trading_center'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_trading_center'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-trading-center';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_trading_center'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 255;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_trading_center'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_trading_center'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_trading_center'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_district_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_district_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_district_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-district';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_district_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 50;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_district_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_district_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_district_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_district_id'][KSystemManager::ITEM_FIELD_PROPERTY_FEED_TO] 			= 
															array( 'previous_business_address_county_id' 			=> array('CountyManager',	'getSelectionByDistrict'),
																   'previous_business_address_sub_county_id' 		=> array('',''),
																   'previous_business_address_parish_id' 			=> array('',''),
																   'previous_business_address_village_id' 		=> array('',''),
																 );
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_district_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'district',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> 'name',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 		=> 'customer' ,
																																							KSystemManager::WHERE_CLAUSE 						=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																							KSystemManager::ORDER_BY  							=> array('name' => KSystemManager::SORT_ASCENDING),
		
		                                                                                                                                                    );
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_county_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-county';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 50;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_FEED_FROM] 		= 'previous_business_address_district_id';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_FEED_TO] 			= 
															array( 'previous_business_address_sub_county_id' 		=> array('SubCountyManager',	'getSelectionByCounty'),
																   'previous_business_address_parish_id' 			=> array('',''),
																   'previous_business_address_village_id' 			=> array('',''),
																 );
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'county',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> 'name',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 		=> 'customer' ,
																																							KSystemManager::WHERE_CLAUSE 						=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																							KSystemManager::ORDER_BY  							=> array('name' => KSystemManager::SORT_ASCENDING),
		
		                                                                                                                                                    );
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_sub_county_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_sub_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_sub_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-sub-county';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_sub_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 50;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_sub_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_sub_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_sub_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_sub_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_FEED_FROM] 		= 'previous_business_address_county_id';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_sub_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_FEED_TO] 		= 
															array( 'previous_business_address_parish_id' 			=> array('ParishManager',	'getSelectionBySubCounty'),
																   'previous_business_address_village_id' 		=> array('',''),
																  );
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_sub_county_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'sub_county',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> 'name',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 		=> 'customer' ,
																																							KSystemManager::WHERE_CLAUSE 						=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																							KSystemManager::ORDER_BY  							=> array('name' => KSystemManager::SORT_ASCENDING),
		
		                                                                                                                                                    );
		
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_parish_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_parish_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_parish_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-parish';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_parish_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 50;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_parish_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_parish_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_parish_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_parish_id'][KSystemManager::ITEM_FIELD_PROPERTY_FEED_FROM] 		= 'previous_business_address_sub_county_id';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_parish_id'][KSystemManager::ITEM_FIELD_PROPERTY_FEED_TO] 		= 
															array('previous_business_address_village_id' 		=> array('VillageManager','getSelectionByParish'));
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_parish_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'parish',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> 'name',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 		=> 'customer' ,
																																							KSystemManager::WHERE_CLAUSE 						=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																							KSystemManager::ORDER_BY  							=> array('name' => KSystemManager::SORT_ASCENDING),
		
		                                                                                                                                                    );
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_village_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_village_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_village_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-village';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_village_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 50;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_village_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_village_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_village_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_village_id'][KSystemManager::ITEM_FIELD_PROPERTY_FEED_FROM] 		= 'previous_business_address_parish_id';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_address_village_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'village',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> 'name',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 		=> 'customer' ,
																																							KSystemManager::WHERE_CLAUSE 						=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																							KSystemManager::ORDER_BY  							=> array('name' => KSystemManager::SORT_ASCENDING),
		
		                                                                                                                                                    );
																																							
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_type_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_RADIO;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-type';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 50;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME 						=> 'customer_type',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 				=> 'id' , 
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 			=> 'name',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  			=> false,
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE  	=> 'customer',
																																							KSystemManager::WHERE_CLAUSE 								=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																							KSystemManager::ORDER_BY  									=> array('name' => KSystemManager::SORT_ASCENDING),
		
		                                                                                                                                                    );
										 
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['non_profit'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['non_profit'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_YESNO;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['non_profit'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'customer-non-profit';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['non_profit'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['non_profit'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['non_profit'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['non_profit'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['same_as_owner'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['same_as_owner'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_YESNO;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['same_as_owner'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'customer-same-as-owner';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['same_as_owner'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['same_as_owner'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['same_as_owner'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['same_as_owner'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		
		
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['is_minor'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['is_minor'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_YESNO;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['is_minor'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-is-minor';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['is_minor'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['is_minor'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['is_minor'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['is_minor'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		
		
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['same_address'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['same_address'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_YESNO;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['same_address'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-same-address';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['same_address'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['same_address'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['same_address'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['same_address'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['have_revenue_agent'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['have_revenue_agent'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_YESNO;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['have_revenue_agent'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-have-revenue-agent';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['have_revenue_agent'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['have_revenue_agent'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['have_revenue_agent'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['have_revenue_agent'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= null;
		
		
		
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['coin_registration_reason'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['coin_registration_reason'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_CHECKBOX;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['coin_registration_reason'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-coin-registration-reason';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['coin_registration_reason'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 50;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['coin_registration_reason'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['coin_registration_reason'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['coin_registration_reason'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['coin_registration_reason'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD]			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ARRAY => array(RevenueManager::REVENUE_SOURCE_SYSTEM_CODE_TRANSPORT => KLanguage::getWord('customer-revenue-source-'. RevenueManager::REVENUE_SOURCE_SYSTEM_CODE_TRANSPORT)));
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['location'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['location'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['location'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-location';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['location'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 200;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['location'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['location'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['location'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['location'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['partner'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['partner'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['partner'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-partner';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['partner'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 200;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['partner'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['partner'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['partner'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['partner'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['organisation_full_name'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['organisation_full_name'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['organisation_full_name'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'customer-organisation-full-name';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['organisation_full_name'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= 200;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['organisation_full_name'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['organisation_full_name'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['organisation_full_name'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['organisation_full_name'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 		= array();
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['building_name'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['building_name'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['building_name'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-building-name';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['building_name'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 200;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['building_name'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['building_name'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['building_name'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['building_name'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_number'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_number'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_number'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-identification-number';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_number'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 20;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_number'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_number'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_number'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_number'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_diplomatic_id'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_diplomatic_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_diplomatic_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-identification-diplomatic-id';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_diplomatic_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 20;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_diplomatic_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_diplomatic_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_diplomatic_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_diplomatic_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_driving_permit'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_driving_permit'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_driving_permit'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-identification-driving-permit';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_driving_permit'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 20;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_driving_permit'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_driving_permit'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_driving_permit'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_driving_permit'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_employee_id'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_employee_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 				= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_employee_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-identification-employee-number';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_employee_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 20;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_employee_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_employee_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 			= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_employee_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_employee_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_passport_number'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_passport_number'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 				= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_passport_number'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-identification-passport-number';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_passport_number'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 20;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_passport_number'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_passport_number'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 			= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_passport_number'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_passport_number'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_village_id'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_village_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_village_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-identification-village-id';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_village_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 20;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_village_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_village_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_village_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_village_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_voter_id'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_voter_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_voter_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-identification-voter-id';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_voter_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 20;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_voter_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_voter_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_voter_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_voter_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_work_id'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_work_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_work_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'customer-identification-work-id';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_work_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= 20;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_work_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_work_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_work_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['identification_work_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 		= array();
		
		

		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['trading_center'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['trading_center'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['trading_center'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'customer-trading-center';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['trading_center'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= 200;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['trading_center'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['trading_center'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['trading_center'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['trading_center'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['street_name'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['street_name'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['street_name'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-street-name';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['street_name'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 200;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['street_name'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['street_name'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['street_name'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['street_name'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['plot_number'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['plot_number'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['plot_number'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-plot-number';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['plot_number'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 200;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['plot_number'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['plot_number'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['plot_number'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['plot_number'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['tin'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['tin'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_DIGIT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['tin'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-tin';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['tin'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['tin'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['tin'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['tin'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['tin'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['entity_legal_name'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['entity_legal_name'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['entity_legal_name'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-entity-legal-name';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['entity_legal_name'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 200;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['entity_legal_name'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['entity_legal_name'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['entity_legal_name'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['entity_legal_name'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['agent_legal_name'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['agent_legal_name'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['agent_legal_name'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-agent-legal-name';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['agent_legal_name'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 200;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['agent_legal_name'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['agent_legal_name'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['agent_legal_name'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['agent_legal_name'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['former_business_name'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['former_business_name'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['former_business_name'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-former-business-name';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['former_business_name'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 200;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['former_business_name'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['former_business_name'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['former_business_name'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['former_business_name'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['surname'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['surname'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['surname'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-surname';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['surname'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 200;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['surname'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['surname'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['surname'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['surname'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['firstname'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['firstname'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['firstname'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-firstname';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['firstname'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 200;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['firstname'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['firstname'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['firstname'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['firstname'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['middle_name'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['middle_name'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['middle_name'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-middle-name';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['middle_name'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 200;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['middle_name'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['middle_name'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['middle_name'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['middle_name'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['acquired_name'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['acquired_name'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['acquired_name'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-acquired-name';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['acquired_name'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 200;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['acquired_name'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['acquired_name'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['acquired_name'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['acquired_name'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['business_name'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['business_name'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 				= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['business_name'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-business-name';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['business_name'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 200;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['business_name'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['business_name'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['business_name'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['business_name'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		  
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['coin'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['coin'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 				= KSystemManageR::FIELD_TYPE_DIGIT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['coin'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 				= 'customer-coin';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['coin'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 			= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['coin'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 			= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['coin'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 			= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['coin'][KSystemManager::ITEM_FIELD_PROPERTY_CUSTOM_VALIDATOR] 	= array('CustomerManager','validCOIN', KLanguage::getWord('customer-coin-not-found-in-database'));
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['id_number'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['id_number'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['id_number'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-id-number';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['id_number'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 50;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['id_number'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['id_number'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['id_number'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['id_number'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['certificate_number'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['certificate_number'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['certificate_number'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'customer-certificate-number';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['certificate_number'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= 50;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['certificate_number'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['certificate_number'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['certificate_number'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['certificate_number'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 		= array();
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['box_number'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['box_number'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_ALPHANUMERIC;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['box_number'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'customer-box-number';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['box_number'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= 20;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['box_number'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['box_number'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['box_number'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['box_number'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 		= array();
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['box_district_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['box_district_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['box_district_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-district';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['box_district_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 50;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['box_district_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['box_district_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['box_district_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['box_district_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'district',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> 'name',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
																																							KSystemManager::WHERE_CLAUSE 						=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																							KSystemManager::ORDER_BY  							=> array('name' => KSystemManager::SORT_ASCENDING),
		
		                                                                                                                                                    );
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date_of_incorporation'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date_of_incorporation'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_DATE;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date_of_incorporation'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-date-of-incorporation';

		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date_of_incorporation'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date_of_incorporation'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= -(75 + (date('Y') - 2014) );

		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date_of_incorporation'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date_of_incorporation'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date_of_incorporation'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date_joined_stage'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date_joined_stage'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_DATE;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date_joined_stage'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-date-joined-stage';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date_joined_stage'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date_joined_stage'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= -(10 + (date('Y') - 2014) );
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date_joined_stage'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date_joined_stage'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date_joined_stage'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		
		                                                                                                                                                 
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['expiry_date'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['expiry_date'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_DATE;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['expiry_date'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-expiry-date';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['expiry_date'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= -16;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['expiry_date'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= -100;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['expiry_date'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['expiry_date'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['expiry_date'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		                                                                                                                                                 
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['mother_maiden_name'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['mother_maiden_name'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['mother_maiden_name'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'customer-mother-maiden-name';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['mother_maiden_name'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= 200;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['mother_maiden_name'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['mother_maiden_name'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['mother_maiden_name'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['mother_maiden_name'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 		= array();
		
		
		// more fields that are not part of add/edit form
		$arrCustomer[KSystemManager::ITEM_PROPERTY_AUTOMATED_FIELDS] = KSystemManager::commonAutomatedFields();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_AUTOMATED_FIELDS]['status_id'] = KStatus::NOT_VERIFIED;
		
		// allow only sent, pending and failed sms on list and check for customership
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FORCED_WHERE] 	= array('status_id' => array(KStatus::ACTIVE, KStatus::PENDING, KStatus::REJECTED, KStatus::NOT_VERIFIED, KStatus::INACTIVE));
		
		/*
		 * Vehicle component configurations
		 */
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['city_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['city_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['city_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'vehicle-city';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['city_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['city_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['city_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['city_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['city_id'][KSystemManager::ITEM_FIELD_PROPERTY_FEED_TO] 			= array('division_id' 		=> array('DivisionManager','getDivisions', 'park_id' 		=> array('',''), 'stage_id' 		=> array('','')));
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['city_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'city',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> 'name',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 		=> 'vehicle',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
																																							KSystemManager::WHERE_CLAUSE 						=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																							KSystemManager::ORDER_BY  							=> array('name' => KSystemManager::SORT_ASCENDING),
																																							);
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['division_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['division_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 				= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['division_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'vehicle-division';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['division_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['division_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['division_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 			= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['division_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';	
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['division_id'][KSystemManager::ITEM_FIELD_PROPERTY_FEED_FROM] 		= 'city_id';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['division_id'][KSystemManager::ITEM_FIELD_PROPERTY_FEED_TO] 			= array('park_id' 		=> array('ParkManager','getParkSelection'));				
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['division_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME 	=> 'division',
																																	KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 				=> 'id' , 
																																	KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 			=> 'name',
																																	KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  			=> false,
																																	KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 		=> 'vehicle',
																																	KSystemManager::WHERE_CLAUSE 								=> array(KSystemManager::WHERE_IN => array(KStatus::ACTIVE,KStatus::INACTIVE)),
																																	KSystemManager::ORDER_BY  									=> array('name' => KSystemManager::SORT_ASCENDING),
																																	);
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['park_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['park_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['park_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'vehicle-park';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['park_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['park_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['park_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['park_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['park_id'][KSystemManager::ITEM_FIELD_PROPERTY_FEED_FROM] 	= 'division_id';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['park_id'][KSystemManager::ITEM_FIELD_PROPERTY_FEED_TO] 		= array('stage_id' 		=> array('StageManager','getStages'));		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['park_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 		= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'park',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 				=> 'id' , 
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 			=> array('name'),
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  			=> false,
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 		=> 'vehicle',
																																							KSystemManager::WHERE_CLAUSE 								=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																							KSystemManager::ORDER_BY  									=> array('name' => KSystemManager::SORT_ASCENDING),
																																							);
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['stage_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['stage_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 		= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['stage_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'vehicle-stage';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['stage_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['stage_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['stage_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 	= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['stage_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['stage_id'][KSystemManager::ITEM_FIELD_PROPERTY_FEED_FROM] 	= 'park_id';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['stage_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 		= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'stage',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 				=> 'id' , 
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 			=> array('name'),
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  			=> false,
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 		=> 'vehicle',
																																							KSystemManager::WHERE_CLAUSE 								=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																							KSystemManager::ORDER_BY  									=> array('name' => KSystemManager::SORT_ASCENDING),
																																							);
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_relationship_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_relationship_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_relationship_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'vehicle-relationship';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_relationship_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_relationship_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_relationship_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_relationship_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_relationship_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 	= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'vehicle_relationship',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> array('name'),
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 	=> 'vehicle_objection',
																																							KSystemManager::WHERE_CLAUSE 						=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																							KSystemManager::ORDER_BY  							=> array('name' => KSystemManager::SORT_ASCENDING),
																																							);
																																		
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['log_book_date'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['log_book_date'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_DATE;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['log_book_date'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'vehicle-log-book-date';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['log_book_date'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= -(30 + (date('Y') - 2014) );
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['log_book_date'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['log_book_date'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['log_book_date'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['log_book_date'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['organization'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['organization'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['organization'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-organization';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['organization'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 200;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['organization'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['organization'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['organization'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['organization'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_operation_type_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_operation_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_operation_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'vehicle-operation-type';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_operation_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_operation_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_operation_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_operation_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_operation_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME 	=> 'vehicle_operation_type',
																																			KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 					=> 'id' , 
																																			KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 				=> 'name',
																																			KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  				=> false,
																																			KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 			=> 'vehicle',
																																			KSystemManager::WHERE_CLAUSE 						=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																			KSystemManager::ORDER_BY  							=> array('id' => KSystemManager::SORT_ASCENDING),
																																			);
																																			
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['operational_license_issue_date'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['operational_license_issue_date'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_DATE;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['operational_license_issue_date'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'vehicle-operational-license-issue-date';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['operational_license_issue_date'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['operational_license_issue_date'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= -(75 + (date('Y') - 2014) );
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['operational_license_issue_date'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['operational_license_issue_date'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['engine_number'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['engine_number'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 		= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['engine_number'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'vehicle-engine-number';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['engine_number'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= 50;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['engine_number'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['engine_number'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 	= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['engine_number'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['engine_number'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 		= array();
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['chassis_number'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['chassis_number'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 		= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['chassis_number'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'vehicle-chassis-number';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['chassis_number'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= 50;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['chassis_number'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['chassis_number'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 	= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['chassis_number'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 	= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['chassis_number'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 		= array();
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['license_issue_date'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['license_issue_date'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_DATE;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['license_issue_date'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'vehicle-license-issue-date';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['license_issue_date'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= -(30 + (date('Y') - 2014) );
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['license_issue_date'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['license_issue_date'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['license_issue_date'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['license_issue_date'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 		= array();
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_make'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_make'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 		= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_make'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'vehicle-make';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_make'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= 50;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_make'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_make'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 	= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_make'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_make'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 		= array();
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_category_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_category_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 				= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_category_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 				= 'vehicle-category';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_category_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 			= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_category_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 			= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_category_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 			= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_category_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 				= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_category_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 				= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME 				=> 'vehicle_category',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 				=> 'id' , 
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 			=> 'name',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  			=> false,
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 		=> 'vehicle',
																																							KSystemManager::ORDER_BY  									=> array('id' => KSystemManager::SORT_ASCENDING),
																																						);
																																			
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_model'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_model'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_model'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'vehicle-model';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_model'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_model'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 50;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_model'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_model'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['vehicle_model'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['year'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['year'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 		= KSystemManager::FIELD_TYPE_YEAR;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['year'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'vehicle-year';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['year'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= 1960;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['year'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['year'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 	= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['year'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['year'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 		= array();
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['color'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['color'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['color'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'vehicle-color';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['color'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= 100;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['color'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['color'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['color'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['color'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 		= array();
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['number_plate'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['number_plate'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_ALPHANUMERIC;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['number_plate'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'vehicle-number-plate';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['number_plate'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['number_plate'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['number_plate'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['number_plate'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['number_plate'][KSystemManager::ITEM_FIELD_PROPERTY_CUSTOM_FORMAT] 	= array(array('strtoupper'));
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['current_owner_firstname'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['current_owner_firstname'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 		= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['current_owner_firstname'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'vehicle-current-owner-firstname';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['current_owner_firstname'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= 200;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['current_owner_firstname'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['current_owner_firstname'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 	= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['current_owner_firstname'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['current_owner_firstname'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 		= array();
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['current_owner_second_name'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['current_owner_second_name'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 		= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['current_owner_second_name'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'vehicle-current-owner-second-name';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['current_owner_second_name'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= 200;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['current_owner_second_name'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['current_owner_second_name'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 	= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['current_owner_second_name'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['current_owner_second_name'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 		= array();
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['current_owner_last_name'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['current_owner_last_name'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 		= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['current_owner_last_name'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'vehicle-current-owner-last-name';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['current_owner_last_name'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= 200;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['current_owner_last_name'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['current_owner_last_name'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 	= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['current_owner_last_name'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['current_owner_last_name'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 		= array();
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['current_owner_tin'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['current_owner_tin'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 		= KSystemManager::FIELD_TYPE_DIGIT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['current_owner_tin'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'vehicle-current-tin';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['current_owner_tin'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['current_owner_tin'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['current_owner_tin'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 	= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['current_owner_tin'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 	= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['current_owner_tin'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 		= array();
		
		
		
		/*
		 * Persons Associated with Entity
		 */
				
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['effect_date'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['effect_date'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 		= KSystemManager::FIELD_TYPE_DATE;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['effect_date'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'customer-effect-date';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['effect_date'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['effect_date'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= -(30 + (date('Y') - 2014) );
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['effect_date'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 	= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['effect_date'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['effect_date'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 		= array();
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['official_designation'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['official_designation'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 		= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['official_designation'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'customer-official-designation';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['official_designation'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= 200;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['official_designation'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['official_designation'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 	= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['official_designation'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 	= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['official_designation'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 		= array();
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['relationship_designation'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['relationship_designation'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 		= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['relationship_designation'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'customer-relationship-designation';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['relationship_designation'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= 200;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['relationship_designation'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['relationship_designation'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 	= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['relationship_designation'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 	= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['relationship_designation'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 		= array();
		
		
		
		
		/*
		 * Driver Details
		 */
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['firstname'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['firstname'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['firstname'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-firstname';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['firstname'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 255;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['firstname'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['firstname'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['firstname'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['firstname'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['second_name'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['second_name'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['second_name'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-second-name';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['second_name'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 255;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['second_name'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['second_name'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['second_name'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['second_name'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['surname'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['surname'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['surname'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-surname';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['surname'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 255;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['surname'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['surname'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['surname'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['surname'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['permit_number'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['permit_number'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['permit_number'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-permit-number';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['permit_number'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 20;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['permit_number'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['permit_number'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['permit_number'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['permit_number'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['associate_type_id'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['associate_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_CHECKBOX;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['associate_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-associate-type';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['associate_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 200;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['associate_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['associate_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['associate_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['associate_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['associate_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME 		=> 'associate_type',
																																			KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 				=> 'id' , 
																																			KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 			=> 'name',
																																			KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  			=> false,
																																			KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 		=> 'customer_business_associate',
																																			KSystemManager::WHERE_CLAUSE 								=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																			KSystemManager::ORDER_BY  									=> array('name' => KSystemManager::SORT_ASCENDING),
																																			);
																																			
																																			
/**
 * interview fields - BEGIN
 */
	
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['venue'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['venue'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['venue'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-venue';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['venue'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 200;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['venue'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['venue'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['venue'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_DATE ;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-date';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['time'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['time'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TIME;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['time'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-time';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['time'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 8;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['time'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['time'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['time'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['interview_reason'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['interview_reason'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_HTML;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['interview_reason'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-interview-reason';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['interview_reason'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= KSystemManager::DATA_LENGTH_SMALL_FILE;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['interview_reason'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['interview_reason'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['interview_reason'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['interviewer'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['interviewer'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['interviewer'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-interviewer';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['interviewer'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 255;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['interviewer'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['interviewer'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['interviewer'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['interviewer'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'user',
																																			KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
																																			KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> array('firstname',' ','surname'),
																																			KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
																																			KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 		=> 'customer_interview_inspection',
																																			KSystemManager::WHERE_CLAUSE 						=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																			KSystemManager::ORDER_BY  							=> array('id' => KSystemManager::SORT_ASCENDING),
																																			);
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['notice_type'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['notice_type'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['notice_type'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-notice-type';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['notice_type'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 255;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['notice_type'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['notice_type'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['notice_type'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['notice_type'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ARRAY => array( 
																																																InterviewInspectionManager::INTERVIEW_INSPECTION_NOTICE_TYPE_INSPECTION => KLanguage::getWord('customer-inspection'), 	
																																																InterviewInspectionManager::INTERVIEW_INSPECTION_NOTICE_TYPE_INTERVIEW => KLanguage::getWord('customer-interview')
																																																		));
																	
																																																				
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_name'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_name'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_YESNO;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_name'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'customer-previous-business-name';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_name'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_name'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['previous_business_name'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['terms_and_conditions'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['terms_and_conditions'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 		= KSystemManager::FIELD_TYPE_CHECKBOX;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['terms_and_conditions'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'customer-terms-and-conditions';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['terms_and_conditions'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['terms_and_conditions'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['terms_and_conditions'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 	= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['terms_and_conditions'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['terms_and_conditions'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 		= array( KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ARRAY => array(1 => KLanguage::getWord('terms-and-conditions-details')));
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['terms_and_conditions'][KSystemManager::ITEM_FIELD_PROPERTY_WRAPPER_CLASS]= 'inputbuttons';
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['coin_if_any'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['coin_if_any'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_DIGIT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['coin_if_any'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-coin-if-any';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['coin_if_any'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['coin_if_any'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['coin_if_any'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['coin_if_any'][KSystemManager::ITEM_FIELD_PROPERTY_CUSTOM_VALIDATOR] = array('CustomerManager','validCOIN', KLanguage::getWord('customer-coin-not-found-in-database'));
		
		//interview report fields
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['is_bio_data_same'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['is_bio_data_same'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_YESNO;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['is_bio_data_same'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-is-bio-data-same';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['is_bio_data_same'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['is_bio_data_same'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['is_bio_data_same'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['is_bio_data_same'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
				
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['if_no_reason'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['if_no_reason'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXTAREA;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['if_no_reason'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-if-no-give-reason';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['if_no_reason'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 255;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['if_no_reason'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['if_no_reason'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['if_no_reason'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['category_operation_description'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['category_operation_description'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 				= KSystemManager::FIELD_TYPE_TEXTAREA;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['category_operation_description'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-category-operation-description-of-transport';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['category_operation_description'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 255;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['category_operation_description'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['category_operation_description'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 			= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['category_operation_description'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['opinion_registration'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['opinion_registration'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXTAREA;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['opinion_registration'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-in-your-opinion-what-should-city-operator-be-registered-for-?';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['opinion_registration'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 255;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['opinion_registration'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['opinion_registration'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['opinion_registration'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['additional_information'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['additional_information'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXTAREA;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['additional_information'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'customer-additional-information';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['additional_information'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= 255;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['additional_information'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['additional_information'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['additional_information'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['interviewee_comments'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['interviewee_comments'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXTAREA;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['interviewee_comments'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-interviewee-comments';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['interviewee_comments'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 255;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['interviewee_comments'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['interviewee_comments'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['interviewee_comments'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['inspector_name'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['inspector_name'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 				= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['inspector_name'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-inspector-name';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['inspector_name'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 255;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['inspector_name'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['inspector_name'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 			= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['inspector_name'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['balance'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['balance'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_MONEY;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['balance'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-balance';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['balance'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 200;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['balance'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['balance'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['balance'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['balance'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['document_number'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['document_number'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_TEXT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['document_number'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'customer-document-number';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['document_number'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 12;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['document_number'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['document_number'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['document_number'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['document_number'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array();
		
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['period'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['period'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['period'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'customer-period';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['period'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= 200;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['period'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['period'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['period'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['period'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 		= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ARRAY => array( 1	=> KLanguage::getWord('customer-30-days-and-less'),
																																														  2 => KLanguage::getWord('customer-31-60-days'),
																																														  3	=> KLanguage::getWord('customer-61-90-days'),   
																																														  4 => KLanguage::getWord('customer-91-120-days'),  
																																														  5 => KLanguage::getWord('customer-more-than-120-days')
																																														  ));
																																														  
																																														  
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['revenue_type_id'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['revenue_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 		= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['revenue_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'customer-revenue-source';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['revenue_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['revenue_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= 1;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['revenue_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 	= false;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['revenue_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_FEED_TO] 		=  array( 'revenue_model_id' 	=> array('PaymentManager',  'getRevenueHeadByType'),);
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['revenue_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 		= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'revenue_type',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> 'name',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 		=> 'revenue_type' ,
																																							KSystemManager::WHERE_CLAUSE 						=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																							KSystemManager::ORDER_BY  							=> array('name' => KSystemManager::SORT_ASCENDING),
		
		                                                                                                                         ); // done
		                                                                                                                         
		                                                                                                                         
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['division_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['division_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 				= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['division_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'vehicle-division';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['division_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['division_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['division_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 			= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['division_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= '';	
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['division_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME 	=> 'division',

																																	KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 				=> 'id' , 
																																	KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 			=> 'name',
																																	KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  			=> false,
																																	KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 		=> 'vehicle',
																																	KSystemManager::WHERE_CLAUSE 								=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																	KSystemManager::ORDER_BY  									=> array('name' => KSystemManager::SORT_ASCENDING),
																																	);
		
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date_from'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date_from'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 					= KSystemManager::FIELD_TYPE_DATE;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date_from'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 					= 'payment-date-from';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date_from'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 				= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date_from'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 				= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date_from'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 				= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date_from'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 				= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date_from'][KSystemManager::ITEM_FIELD_PROPERTY_MUST_NOT_EXCEED_FIELD] 	= 'date_to';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date_from'][KSystemManager::ITEM_FIELD_PROPERTY_FUTURE_DATE_NOT_ALLOWED] = true;	
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date_to'] 				= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date_to'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 						= KSystemManager::FIELD_TYPE_DATE;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date_to'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 					= 'payment-date-to';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date_to'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 				= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date_to'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 				= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date_to'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 					= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date_to'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 					= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['date_to'][KSystemManager::ITEM_FIELD_PROPERTY_FUTURE_DATE_NOT_ALLOWED] 	= true;	


       /* Market Rent details */
       	$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['market_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['market_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['market_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'market_name';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['market_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['market_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['market_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['market_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';	
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['market_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME 	=> 'markets',

																																	KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 				=> 'id' , 
																																	KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 			=> 'name',
																																	KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  			=> false,
																																	KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 		=> 'markets',
																																	KSystemManager::WHERE_CLAUSE 								=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																	KSystemManager::ORDER_BY  									=> array('name' => KSystemManager::SORT_ASCENDING),
																																	);
																																	
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['occupancy_status_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['occupancy_status_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['occupancy_status_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'occupancy_status';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['occupancy_status_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['occupancy_status_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['occupancy_status_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['occupancy_status_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		    = '';	
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['occupancy_status_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME 	=> 'market_occupancy_status',

																																	KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 				=> 'id' , 
																																	KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 			=> 'name',
																																	KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  			=> false,
																																	KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 		=> 'market_occupancy_status',
																																	KSystemManager::WHERE_CLAUSE 								=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																	KSystemManager::ORDER_BY  									=> array('name' => KSystemManager::SORT_ASCENDING),
																																	);
																																	
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['business_category_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['business_category_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['business_category_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'business_category';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['business_category_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['business_category_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['business_category_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['business_category_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		    = '';	
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['business_category_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME 	=> 'market_business_category',

																																	KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 				=> 'id' , 
																																	KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 			=> 'name',
																																	KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  			=> false,
																																	KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 		=> 'market_business_category',
																																	KSystemManager::WHERE_CLAUSE 								=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																	KSystemManager::ORDER_BY  									=> array('name' => KSystemManager::SORT_ASCENDING),
																																	);
																																	
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['facility_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['facility_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['facility_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'market_facility_name';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['facility_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['facility_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['facility_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= 0;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['facility_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		    = '';	
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['facility_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 			= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME 	=> 'facility',

																																	KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 				=> 'id' , 
																																	KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 			=> 'name',
																																	KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  			=> false,
																																	KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 		=> 'facility',
																																	KSystemManager::WHERE_CLAUSE 								=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																	KSystemManager::ORDER_BY  									=> array('name' => KSystemManager::SORT_ASCENDING),
																																	);
																																	
																																	//property Details
		//=============================================
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['property_rented_status_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['property_rented_status_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['property_rented_status_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'property_rented_status_id';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['property_rented_status_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['property_rented_status_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['property_rented_status_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['property_rented_status_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 		= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['property_rented_status_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 	= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'property_rented_status',
																																				KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
																																				KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> array('name'),
																																				KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
																																				KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 	=> 'property',
																																				KSystemManager::WHERE_CLAUSE 						=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																				KSystemManager::ORDER_BY  							=> array('name' => KSystemManager::SORT_ASCENDING),
																																			);
		
		
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['sub_property_type_id'] 			= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['sub_property_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 		= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['sub_property_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'sub_property_type_id';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['sub_property_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['sub_property_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['sub_property_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 	= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['sub_property_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 	= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['sub_property_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 		= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'sub_property_type',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> array('name'),
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 	=> 'property',
																																							KSystemManager::WHERE_CLAUSE 						=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																							KSystemManager::ORDER_BY  							=> array('name' => KSystemManager::SORT_ASCENDING),
																																							);	
																																							
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['property_type_id'] 													= array();
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['property_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 		= KSystemManager::FIELD_TYPE_SELECT;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['property_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 		= 'property_type_id';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['property_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 	= 10;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['property_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 	= null;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['property_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 	= true;
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['property_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 	= '';
		$arrCustomer[KSystemManager::ITEM_PROPERTY_FIELDS]['property_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 		= array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'property_type',
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> array('name'),
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
																																							KSystemManager::ITEM_FIELD_PROPERTY_CHILD_PARENT_TABLE 	=> 'property',
																																							KSystemManager::WHERE_CLAUSE 						=> array(KSystemManager::WHERE_EXACT_MATCH => array('status_id' => KStatus::ACTIVE)),
																																							KSystemManager::ORDER_BY  							=> array('name' => KSystemManager::SORT_ASCENDING),
																																							);
																																							
		
		return $arrCustomer;