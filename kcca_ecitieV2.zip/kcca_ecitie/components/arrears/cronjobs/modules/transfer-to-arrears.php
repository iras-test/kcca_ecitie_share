
<?php

(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
set_time_limit(0);

print_r("running here");
exit();

foreach (ArrearsManager::getExpiredYesterday() as $business) {

    $business = (Object)$business;
    print("updating business details");
    # Update status
    ArrearsManager::updateBusinessArrearStatus($business->ref_name, $business->ref_id, ArrearStatus::BUSINESS_MOVED_TO_ARREARS);
    print("updated business details");

    // Transfer to arrears
    print("creating arrear case");
    ArrearCase::create($business->customer_id, $business->ref_id, $business->ref_name, null, ArrearStatus::OPEN);
    print("creating arrear case");
}
