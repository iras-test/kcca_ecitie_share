<?php

$case_id = KRequest::getQueryString("case_id", null);
$case = (object) ArrearCase::getArrearCaseByID($case_id);
$util = new Util();

if ($case && $case->ref_name && $case->ref_id) {

    $currentUser = KSecurity::getUserID();
    $info  = (object) ArrearCase::getItem($case_id);

    if (KRequest::isPosted()) {
        $comment = KRequest::getPost('comment');

        if(KRequest::isUploaded('document') && KRequest::getUploadError('document') == UPLOAD_ERR_OK) {
            $file_name = KRequest::getUploadName('document');
            $file_name = KGenerator::licenseKey($file_name).'.'.KFile::getExtension($file_name);
            
            // try to save the attachment
            if(KFile::uploadTemporaryFile(KRequest::getUploadFile('document'), KFW_STORAGE_PATH . $this->getComponentRealname() . DIRECTORY_SEPARATOR .$file_name, null, KetrouteApplication::reg()->get('CREATE_STORAGE_IF_NOT_EXISTS', false))) {
                $objection = $this->database()->createRecord(
                    'arrears_case_objection', 
                    array(
                        "arrear_case_id" => $case_id,
                        "ref_id" => $case->ref_id,
                        "ref_name" => $case->ref_name,
                        "reason" => KRequest::getPost("reason"),
                        "ground_of_objection" => KRequest::getPost("ground_of_objection"),
                        "comment" => $comment,
                        'document' 			=> 'objection attachment',
                        'document_name' 	=> KRequest::getUploadName('document'),
                        'document_mime' 	=> KRequest::getUploadMime('document'),
                        'document_sysname' 	=> $file_name,
                        "created_by" => KSecurity::getUserID()
                    ),
                    array('created_date' => KetrouteApplication::db()->getNowExpression())
                );
        
                ArrearCase::updateStatus($case_id, KRequest::getPost("reason"));
        
                // // capture audit log
                $this->logAuditTrail("Objection Action Recorded for Arrears Case #$arrears_case_id", 'arrears_case_objection', $objection);
        
                // // // set success message
                KSecurity::setActionSuccess(KLanguage::getWord('arrears-recorded-objection-action', array('arrears_case' => $arrears_case_id)));
        
                $this->stopRedirector("{$this->urlPath(0)}view-objection/id/{$objection}");
            }
        }
        
    }

    $case_status = ($info->status == null) ? ArrearStatus::OPEN : $info->status;
    $bal = ArrearsManager::getOutstandingBal($info->ref_name, $info->ref_id);
    $business_details = ArrearsManager::getBusinessDetails($info->ref_name, $info->ref_id);

    $extra_details = "";

    if ($info->ref_name == "vehicle") {
        $extra_details .= "<div class=\"pt10\">
                            <strong><span class=\"bs-bold\">Park</span></strong>: {$business_details->park_name}
                        </div>
                        <div class=\"pt10\">
                            <strong><span class=\"bs-bold\">Stage</span></strong>: {$business_details->stage_name}
                        </div>
                        ";
    }

    $info_display = "
        <div class=\"clear customer-blocks pb10\">
            <h1 class=\"kfw-active-title\"><strong>[lang-arrears-case-details]<strong></h1>
            <div class=\"clear pt10\">
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Customer</span></strong>: {$info->customer}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">COIN</span></strong>: {$info->coin}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Revenue name</span></strong>: {$info->ref_name}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Branch Code</span></strong>: {$business_details->branch_code}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Location</span></strong>: {$business_details->location}
                </div>
                {$extra_details}
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Outstanding balance</span></strong>: {$bal}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Status</span></strong>: <span class=\"{$util::StatusClass($case_status)}\">{$case_status}</span>
                </div>
            </div>
        </div>
    ";

    $objection_grounds = ArrearCase::getObjectionGrounds();
    $objection_options = "";
    foreach ($objection_grounds as $key => $value) {
        $objection_options .= "<option value=\"$value->id\">{$value->name}</option>";
    }

    return $this->render(array(
        "info_display" => $info_display,
        "objection_options" => $objection_options,
        "under_objection" => ArrearStatus::UNDER_OBJECTION,
        "does_not_qualify" => ArrearStatus::DOES_NOT_QUALIFY,
        "form_action" =>  KRequest::getUri(),
        "form_identifier" => "mykfwform-{$this->getComponent()}-{$this->getModule()}",
        "confirm_question" => KLanguage::getWord('confirm-item-allocate', array('item' => KLanguage::getWord($this->runtime()->getActiveItem()))),
        "back_url" => KSecurity::getSession('BACK_URL'),
    ));

} else {

    KSecurity::setActionWarning(KLanguage::getWord('arrears-no-case-specified'));
}
