<?php

header("Content-type: application/json");
$response = AuthWrapper::authenticateUser();
echo json_encode($response);
exit;