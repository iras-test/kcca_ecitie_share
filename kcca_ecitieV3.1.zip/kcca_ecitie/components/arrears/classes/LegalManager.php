<?php

class LegalManager {
    public static function getTypes() {
        return KetrouteApplication::instance()->database()->getList(
            $table = 'arrears_legal_action_type',
            $where = array(
                'status_id' => KStatus::ACTIVE
            )
        );
    }

    public static function getTypeName($id) {
        return KetrouteApplication::instance()->database()
            ->getStaticTableValue('arrears_legal_action_type', 'id', 'name', $id);
    }

    public static function getList($page, $queryParams)
    {
        list($start, $end) = ArrearsManager::getPagination($page);
        $genericSQL = ArrearCase::getQueryData($queryParams) . " AND " . self::where($queryParams);
        $SQL = "WITH results AS
            (
                $genericSQL
            )
            SELECT * FROM results  WHERE RowNum BETWEEN $start AND $end
        ";

        return KetrouteApplication::db()->execute($SQL);
    }

    public static function count($queryParams)
    {
        $where = self::where($queryParams);
        $SQL = "SELECT COUNT(arr_case.id) AS total  FROM arrear_case arr_case WHERE $where";
        $res = (object) KetrouteApplication::db()->execute($SQL);
        return $res->fields["total"];
    }

    public static function where($queryParams) {

        $where = "assignee IS NOT NULL";
        if (array_key_exists("status", $queryParams)  && $queryParams['status']) {
            $status = $queryParams["status"];
            $where .= " AND status = '$status' ";

        } else {
            $max_due_date = date("Y-m-d 00:00:00", strtotime("-10 days"));
            $b_seal = ArrearStatus::UNDER_BUSINESS_SEAL;
            $a_notice = ArrearStatus::UNDER_AGENCY_NOTICE;
            $where .= " AND (status = '$b_seal' OR status = '$a_notice') AND arr_case.modified_date <= '$max_due_date' ";
        }
        return $where;
    }

    public static function getActionsByCase($case_id) {
        return KetrouteApplication::instance()->database()->getList(
            $table = 'arrears_case_litigation',
            $where = array(
                'arrears_case_id'    => $case_id,
                'status_id'          => KStatus::ACTIVE
            )
        );
    }

    public static function getLegalResponses($legal_action_id) {
        return KetrouteApplication::instance()->database()->getList(
            $table = 'legal_action_response',
            $where = array(
                'legal_action_id'    => $legal_action_id,
                'status_id'          => KStatus::ACTIVE
            )
        );
    }

    public static function createLegalResponse($legal_action_id) {
        $file_name = KRequest::getUploadName('document');
        $file_name = $file_name? KGenerator::licenseKey($file_name).'.'.KFile::getExtension($file_name): null;

        return KetrouteApplication::instance()->database()->createRecord(
            'legal_action_response', 
            array(
                "legal_action_id"        => $legal_action_id,
                "description"           =>  KRequest::getPost('description'),
                'document' 		    	=> 'attachment',
                'document_name'     	=> KRequest::getUploadName('document'),
                'document_mime' 	    => KRequest::getUploadMime('document'),
                'document_sysname'  	=> $file_name,
                "created_by"            => KSecurity::getUserID()
            ),
            array('created_date' => KetrouteApplication::db()->getNowExpression())
        );
    
    }

    public static function getLegalAction($legal_action_id) {
        return KetrouteApplication::instance()->database()->load($table = 'arrears_case_litigation', $where = array('id' => $legal_action_id));
    }
}