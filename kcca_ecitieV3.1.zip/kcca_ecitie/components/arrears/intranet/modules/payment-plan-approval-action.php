<?php

if (KRequest::isPosted()) {

    $selected_approval_action = KRequest::getPost('approval_action');
    $pp_to_act_upon = KRequest::getPost('pp_id');
    if ($selected_approval_action == PaymnentPlanManager::APPROVE_ACTION) {

        PaymnentPlanManager::pp_approval_action($pp_to_act_upon, 1,ArrearStatus::UNDER_PAYMENT_PLAN);

    }
    if($selected_approval_action == PaymnentPlanManager::OBJECT_ACTION) {

        PaymnentPlanManager::pp_approval_action($pp_to_act_upon, 2, ArrearStatus::UNDER_OBJECTION);
    }

    if($selected_approval_action == PaymnentPlanManager::CLOSE) {

        PaymnentPlanManager::pp_approval_action($pp_to_act_upon, 3, ArrearStatus::ASSIGNED);
    }
    
    KSecurity::setActionSuccess("Acted on Payment Plan Successfully");
    $this->stopRedirector("{$this->urlPath(0)}view-payment-plan?id={$pp_to_act_upon}");

}
KSecurity::setActionWarning("Illegal Access Method");
$this->stopRedirector(KSecurity::getSession('BACK_URL'));