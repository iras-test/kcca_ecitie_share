<?php

/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

if (KRequest::isPosted()) {
	$cases_info = KRequest::getpost("ids");

	$assignee = KRequest::getPost("assignee");
	$assigned_action = KRequest::getPost("assigned_action");
	$data = json_decode($cases_info);

	foreach ($data as $key => $case_id) {
		ArrearCase::updateStatus($case_id, null, null, $assignee);
        $this->database()->updateRecord(
            'arrear_case',
            array(
                'assignee' => $assignee,
                'assigned_action' => $assigned_action,
                'status' => ArrearStatus::ASSIGNED,
                'modified_by' => KSecurity::getUserID()
            ),
            array('id' => $case_id),
            $one_record = true,
            array('modified_date' => $this->database()->getNowExpression())
        );
	}
	$resp['success'] = true;
	$resp['ids'] = $data;
	$resp['assignee'] = KRequest::getPosts();

	header("Content-type: application/json");

	echo json_encode($resp);
	exit;
}

/** Handle downloads */
$download = $this->getParam('quickexport', 1);
if ($download == "csv" || $download == 'pdf') {
	$pages = $this->getParam('pages', 1);
	$arrHeaders = array('due_date', 'customer', 'coin', 'division', 'parish', 'street', 'serial_no', 'amount');

	$page = $pages == "current" ? $this->getParam('page', 1) : null;
	$arrResults = ArrearsManager::propertyExport($page, KRequest::getQueryStrings());

	$docType = $this->getParam('quickexport', 1);
	$docName = "arrears property register.$docType";
	$docSavedName = "{$this->getComponent()}-{$this->getModule()}.$docType";
	$docPath = KFW_STORAGE_PATH . $this->getComponentRealname() . DIRECTORY_SEPARATOR . "{$this->getComponent()}-{$this->getModule()}.$docType";

	if ($docType == "csv") {
		KFile::createCSV(
			$docSavedName,
			$arrHeaders,
			$arrResults
		);
	} else {
		KFile::createPDF(
			$docSavedName,
			"Arrears Property",
			$arrHeaders,
			$arrResults,
			$mode = 1,
			$auto_print = true,
			$orientation = 'L',
			$show_numbering = false,
			null
		);
	}

	KFile::downloadFile($docName, $docPath, $delete_file_when_done = true);
	exit;
}

// get max per page
$MAX_PER_PAGE 	= $this->registry()->get(strtoupper($this->getComponentRealname()) . '_MAX_PER_PAGE', $this->registry()->get('MAX_PER_PAGE', 10));
// page number
$_page		 	= $this->getParam('page', KRequest::getQueryString("page", 1));
$queryParams = KRequest::getQueryStrings();
$records = '';
$strComponentRealname	= $this->getComponentRealname();
$user_id		= KSecurity::getUserID();
$intIgnoreID 	= $this->runtime()->getIgnoredID();
$strParentUrl	= $this->urlPath(0);
$strMessage = '';
$records = '';
$list_counter	= 0;

// set active item with its configurations	
$this->runtime()->setActivePage($_page);
$this->runtime()->setActiveMaxPerPage($MAX_PER_PAGE);

$result_list['count'] = ArrearsManager::propertyArrearsCount($queryParams);
$data = ArrearsManager::getPropertyArrears($_page, $queryParams);

$officers = ArrearsManager::getOfficers();
$assignee_options = "";
$officers_filter_data = [];
foreach ($officers as $key => $value) {
	$assignee_options .= "<option value=\"$value->id\">{$value->surname} {$value->firstname}</option>";
	array_push($officers_filter_data, array("id" => $value->id, "name" => "$value->surname $value->firstname"));
}

/** Case action options */
$action_options = "";
foreach (ArrearStatus::$avaliable_action as $item) {
    $item_display = ucwords(str_replace('_', ' ', $item));
    $action_options .= "<option value=\"$item\">{$item_display}</option>";
}

if ($result_list['count'] > 0) {
	// show record	
	foreach ($data as $index => $arrData) {

		$strPrimaryKey = $this->runtime()->getPrimaryKey();

		$class = ($index % 2 == 0) ? ' odd' : ' even';

		if ($_page > 1) {
			$record_number = ($index + 1) + ($MAX_PER_PAGE * ($_page - 1));
		} else {
			$record_number = ($index + 1);
		}

		$list_counter++;
		$objmoduleConfig = (object)$arrData;
		$arrear_case_creation_data = ["ref_id" => $objmoduleConfig->ref_id, "ref_name" => $objmoduleConfig->ref_name, "customer_id" => $objmoduleConfig->customer_id];
		$allow_case = true;
		if ($objmoduleConfig->case_id) {
			$allow_case = false;
		}

		$arrear_case_creation_data = $objmoduleConfig->id;

		$date = $objmoduleConfig->due_date
			? $objmoduleConfig->due_date :
			"N/A";

		$business_details = ArrearsManager::getBusinessDetails($objmoduleConfig->ref_name, $objmoduleConfig->ref_id);

		// $division = ArrearsManager::getDivision($objmoduleConfig->division_id);
		$division = $objmoduleConfig->division ? $objmoduleConfig->division : "N/A";

		$parish = ArrearsManager::getParish($business_details->parish_id);
		$parish = $parish ? $parish : "N/A";

		$street = $business_details->street_id;
		$street = $street
			? $street
			: "N/A";

		$serial_no = $objmoduleConfig->branch_code
			? $objmoduleConfig->branch_code
			: "N/A";

		$customer_name = $this->runtime()->getFieldData('customer_id', $arrData)
			? $this->runtime()->getFieldData('customer_id', $arrData)
			: "N/A";

		$amount = $objmoduleConfig->arrear_amount
			? abs($objmoduleConfig->arrear_amount)
			: "N/A";

		$interval = date_diff(new DateTime(), new DateTime($objmoduleConfig->due_date));
		$age = $interval->format('%y year(s) %M month(s) %d day(s)');

		$status = $objmoduleConfig->case_status
			? $objmoduleConfig->case_status
			: ArrearStatus::OPEN;

		$assignee = ArrearCase::getAssignee($objmoduleConfig->assignee);

		$records .= "<div class=\"clear list-item{$class}\">";
		$records .= "\n\t\t\t<div class=\"fl numbering-col\">{$record_number}</div>";
		$records .= "\n\t\t\t<div class=\"fl col8\">{$date}</div>";
		$records .= "\n\t\t\t<div class=\"fl col8\">{$division}</div>";
		$records .= "\n\t\t\t<div class=\"fl col8\">{$parish}</div>";
		$records .= "\n\t\t\t<div class=\"fl col8\">{$street}</div>";
		$records .= "\n\t\t\t<div class=\"fl col10\">{$customer_name}</div>";
		$records .= "\n\t\t\t<div class=\"fl col8\">{$serial_no}</div>";
		$records .= "\n\t\t\t<div class=\"fl col8\">{$amount}</div>";
		$records .= "\n\t\t\t<div class=\"fl col8\">&nbsp;{$age}</div>";
		if ($objmoduleConfig->status == ArrearStatus::OPEN) {
			$records .= "\n\t\t\t<div class=\"fl col8\">
				<input type=\"checkbox\" onchange=\"handleArrearSelection(this,'{$arrear_case_creation_data}')\" />
			</div>";
		} else {
			$records .= "\n\t\t\t<div class=\"fl col8\">
				<a href=\"[link_in_use]arrears/case-details?id={$objmoduleConfig->id}\">View case</a>
			</div>";
		}
		$records .= "\n\t\t\t<div class=\"fl col8\">{$status}</div>";
		$records .= "\n\t\t\t<div class=\"fl col8\">{$assignee}</div>";
		if ($allow_case) {
			$records .= "\n\t\t\t<div class=\"fl col6\"><a href=\"[link_in_use]arrears/action?ref_name={$objmoduleConfig->ref_name}&ref_id={$objmoduleConfig->ref_id}\">Action</a></div>";
		}
		$records .= "\n\t\t</div>";
	}
} else {
	$records  = "\n\t\t<div class=\"clear list-item text-center\">" . KLanguage::getWord('arrears-no-items') . "</div>";
}

$pager = new KPager();
$pager->setTotalRecords($result_list['count']);
$pager->setRecordsPerPage($MAX_PER_PAGE);
$pager->setCurrentPage($_page);
$url = $this->urlPath(1, 1, 1, 1);
if (count($queryParams)>0) {
	$ex_url = explode("page=",$url);
	$url = $ex_url[0];
	if (count($ex_url)==1) {
		$url .= "&";
	}
}else {

	$url .= "?";

}
$pager->setURL($url."page=");
$pager_html = $pager->getPager();
$pager_info = $pager->getPagerInfo("[lang-{$strComponentRealname}-property-items]");

/** Divisions */
$divisions = ArrearsManager::getDivisions();
$divisions_arr = [];
foreach ($divisions as $key => $value) {
	array_push($divisions_arr, array("id" => $value["id"], "name" => $value["name"]));
}

$customer_filter = Util::filterInput("text", "Customer", "customer", $queryParams["customer"]);
$coin_filter = Util::filterInput("text", "COIN", "coin", $queryParams["coin"]);
$amount_start_filter = Util::filterInput("text", "Amount-Start", "amount_start", $queryParams["amount_start"]);
$amount_end_filter = Util::filterInput("text", "Amount-End", "amount_end", $queryParams["amount_end"]);
$serial_no_filter = Util::filterInput("text", "Serial-No", "branch_code", $queryParams["branch_code"]);
$age_start_filter = Util::filterInput("date", "Age-Start", "age_start", $queryParams["age_start"]);
$age_end_filter = Util::filterInput("date", "Age-End", "age_end", $queryParams["age_end"]);

$division_filter = Util::filterInput(
	"select",
	"Division",
	"prop_division",
	$queryParams["prop_division"],
	$options = array(
		"data" => $divisions_arr,
		"id" => "id",
		"label" => "name",
		"placeholder" => " - Select division"
	)
);

$parish_filter = Util::filterInput(
	"select",
	"Parish",
	"prop_parish",
	$queryParams["prop_parish"],
	$options = array(
		"data" => [],
		"id" => "id",
		"label" => "name",
		"placeholder" => " - Select parish"
	)
);

$officer_filter = Util::filterInput(
	"select",
	"Assigned-Officer",
	"assignee",
	$queryParams["assignee"],
	$options = array(
		"data" => $officers_filter_data,
		"id" => "id",
		"label" => "name",
		"placeholder" => " - Select Officer"
	)
);


$status_filter = Util::filterInput(
	"select",
	"Status",
	"status",
	$queryParams["status"],
	$options = array(
		"data" => ArrearStatus::$status_arr,
		"id" => "id",
		"label" => "name",
		"placeholder" => " - Select Status - "
	)
);

$filters = "
	$division_filter
	$customer_filter
	$coin_filter
	$amount_start_filter
	$amount_end_filter
	$serial_no_filter
	$age_start_filter
	$age_end_filter
	$officer_filter
	$status_filter
";

$this->render(array(
	"records" => $records,
	"options" => $assignee_options,
	"action_options"  => $action_options,
	"next_url" => $this->urlPath(1, 1, 0, 0) . "cases",
	'pager_html' 	=> $pager_html,
	'pager_info' 	=> $pager_info,
	'message' 		=> $strMessage,
	'image_path'	=> KFW_IMAGES_URL,
	'list_counter' 	=> $list_counter,
	'tabs' 			=> KNavigationTab::getHTMLTabs(),
	'base_url'		=> $this->urlPath(1, 1, 0, 0),
	'filters'		=> Util::formContainer("arrears", $this->urlPath(1, 1, 1, 1), $filters),
	'csv_all'		=> $this->urlPath(1, 1, 0, 0) . "quickexport/csv/pages/all/",
	'csv_current'	=> $this->urlPath(1, 1, 0, 0) . "quickexport/csv/pages/current/",
	'pdf_all'		=> $this->urlPath(1, 1, 0, 0) . "quickexport/pdf/pages/all/",
	'pdf_current'	=> $this->urlPath(1, 1, 0, 0) . "quickexport/pdf/pages/current/",
));
