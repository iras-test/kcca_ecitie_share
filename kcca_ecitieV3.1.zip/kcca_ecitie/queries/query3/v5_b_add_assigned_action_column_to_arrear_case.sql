use ecitie;

ALTER TABLE [dbo].[arrear_case] ADD [assigned_action] [nvarchar](40) NULL