USE ecitie;

Sp_rename 'report_modules_config.column', 'from_column', 'COLUMN'