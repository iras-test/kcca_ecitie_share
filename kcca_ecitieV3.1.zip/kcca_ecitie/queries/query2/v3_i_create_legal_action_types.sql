use ecitie;

CREATE TABLE [dbo].[arrears_legal_action_type] (
    id INT IDENTITY(1,1) NOT NULL,
    name VARCHAR(255) NOT NULL,
    status_id SMALLINT DEFAULT 1,
    modified_by INT NULL,
    modified_date DATETIME2(0) NULL,
    created_by INT NULL,
    created_date DATETIME2(0) NULL,
)

INSERT INTO [dbo].[arrears_legal_action_type]
(name) VALUES ('Intention to Sue')

INSERT INTO [dbo].[arrears_legal_action_type]
(name) VALUES ('MOU')

INSERT INTO [dbo].[arrears_legal_action_type]
(name) VALUES ('Summary warranty')

INSERT INTO [dbo].[arrears_legal_action_type]
(name) VALUES ('Recommendation to DRC')