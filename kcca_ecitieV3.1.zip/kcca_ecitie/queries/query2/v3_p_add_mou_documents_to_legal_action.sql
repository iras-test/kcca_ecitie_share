use ecitie;

ALTER TABLE [dbo].[arrears_case_litigation] ADD mou_document [VARCHAR](255) NULL
ALTER TABLE [dbo].[arrears_case_litigation] ADD mou_document_name [VARCHAR](255) NULL
ALTER TABLE [dbo].[arrears_case_litigation] ADD mou_document_mime [VARCHAR](200) NULL
ALTER TABLE [dbo].[arrears_case_litigation] ADD mou_document_sysname [VARCHAR](200) NULL
