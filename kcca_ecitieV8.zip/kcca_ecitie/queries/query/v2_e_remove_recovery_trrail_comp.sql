
use ecitie;

DELETE FROM [dbo].[component] WHERE title = 'recovery-trail'