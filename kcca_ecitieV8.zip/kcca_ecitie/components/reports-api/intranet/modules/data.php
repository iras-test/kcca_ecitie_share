<?php

$filter_params = KRequest::getQueryStrings();
$report_data = [];
$report_data['data']=[];
$report_data['table_columns']=[];

if ($filter_params) {
    $report_data = ReportsApiManager::getData($filter_params,$report_data);
}

header("Content-type: application/json");

echo json_encode($report_data);
exit;