<?php
/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

$id = $this->getParam('id', 1);
$attachment = $this->database()->load($table = 'assignment_attachments', $where = array('id' => $id));
$docName = $attachment->document_name . '.' . KFile::getExtension($attachment->document_name);
$docPath = KFW_STORAGE_PATH . $this->getComponentRealname() . DIRECTORY_SEPARATOR . $attachment->document_sysname;
KFile::downloadFile($docName, $docPath, $delete_file_when_done = false);