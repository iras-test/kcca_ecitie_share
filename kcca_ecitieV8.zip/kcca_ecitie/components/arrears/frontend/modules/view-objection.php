<?php

/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

$objection_id = $this->getParam('id', 1);
$currentUser = KSecurity::getUserID();
$util = new Util();

$objection = (object) ObjectionManager::getObjectionByID($objection_id);

if ($objection_id) {
    $info  = (object) ArrearCase::getItem($objection->arrear_case_id);
    $info_display = null;

    if ($info) {
        $prn = $info->prn ? $info->prn : "N/A";
        $case_status = ($info->status == null) ? ArrearStatus::OPEN : $info->status;
        $bal = abs($info->arrear_amount);

        $business_details = ArrearsManager::getBusinessDetails($info->ref_name, $info->ref_id);

        $extra_details = "";

        if ($info->ref_name == "vehicle") {
            $extra_details .= "<div class=\"pt10\">
                                <strong><span class=\"bs-bold\">Park</span></strong>: {$business_details->park_name}
                            </div>
                            <div class=\"pt10\">
                                <strong><span class=\"bs-bold\">Stage</span></strong>: {$business_details->stage_name}
                            </div>
                            ";
        }

        $info_display = "
            <div class=\"clear customer-blocks pb10\">
                <h1 class=\"kfw-active-title\"><strong>[lang-arrears-case-details]<strong></h1>
                <div class=\"clear pt10\">
                    <div class=\"pt10\">
                        <strong><span class=\"bs-bold\">Customer</span></strong>: {$info->customer}
                    </div>
                    <div class=\"pt10\">
                        <strong><span class=\"bs-bold\">COIN</span></strong>: {$info->coin}
                    </div>
                    <div class=\"pt10\">
                        <strong><span class=\"bs-bold\">Revenue name</span></strong>: {$info->ref_name}
                    </div>
                    <div class=\"pt10\">
                        <strong><span class=\"bs-bold\">Branch Code</span></strong>: {$business_details->branch_code}
                    </div>
                    <div class=\"pt10\">
                        <strong><span class=\"bs-bold\">Location</span></strong>: {$business_details->location}
                    </div>
                    {$extra_details}
                    <div class=\"pt10\">
                        <strong><span class=\"bs-bold\">Outstanding balance</span></strong>: {$bal}
                    </div>
                    <div class=\"pt10\">
                        <strong><span class=\"bs-bold\">Status</span></strong>: <span class=\"{$util::StatusClass($case_status)}\">{$case_status}</span>
                    </div>
                </div>
            </div>
        ";
    }

    /** Objection Info */
    $comment = $objection->comment
        ? $objection->comment
        : "N/A";
    $obj_ground = $this->database()->load($table = 'ground_of_objection', $where = array('id' => $objection->ground_of_objection));
    $revenue_type = $this->database()->load($table = 'recovery_trail_reference', $where = array('reference_name' => $objection->ref_name));

    $objection_info = "";
    $objection_info .= "<div class=\"clear list-item{$class}\">";
    $objection_info .= "\n\t\t\t<div class=\"fl numbering-col\">{$objection->id}</div>";
    $objection_info .= "\n\t\t\t<div class=\"fl col15\">{$info->customer}</div>";
    $objection_info .= "\n\t\t\t<div class=\"fl col10\">{$info->coin}</div>";
    $objection_info .= "\n\t\t\t<div class=\"fl col10\">{$revenue_type->label}</div>";
    $objection_info .= "\n\t\t\t<div class=\"fl col15\">{$obj_ground->name}</div>";
    $objection_info .= "\n\t\t\t<div class=\"fl col20\">{$comment}</div>";
    if ($objection->document_name!=null) {
        $objection_info .= "\n\t\t\t<div class=\"fl col10\">
                                <a href=\"[link_in_use]arrears/download-objection-doc/id/{$objection->id}\">Download</a>
                            </div>";
    } else {
        $objection_info .= "\n\t\t\t<div class=\"fl col10\">
                            No attachment
                        </div>";
    }
    $objection_info .= "\n\t\t</div>";

    $this->render(array(
        "info_display" => $info_display,
        "bills" => $records,
        "objection_info" => $objection_info
    ));
} else {
    KSecurity::setActionWarning("Arrear case objection must be provided");
}
