<?php

$user = KetrouteApplication::db()->load($table = 'user', $where = array('id' => KSecurity::getUserID()));

header("Content-type: application/json");

echo json_encode($user);
exit;