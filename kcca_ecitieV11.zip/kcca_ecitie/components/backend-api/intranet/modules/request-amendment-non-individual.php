<?php
header("Content-type: application/json");
AuthWrapper::getAuthenticatedUser();

$status = 400;

if (KRequest::isPosted()) {
    // user identifier
    $intUserID = KSecurity::getUserID();
    $posted_data = KRequest::getPost("data");
    $posted_data = json_decode($posted_data, true);
    $customer_id = KRequest::getPost("customer_id");

    if (empty($posted_data['company-details'])) {
        $message = KLanguage::getWord('customer-no-legal-entity-details');
    }

    if (empty($posted_data['contacts-reference-agent'])) {
        $message = KLanguage::getWord('customer-no-contacts-reference-agent-details');
    }

    // we have an error
    if (!$message) {

        // customer details: duplicate check
        try {
            $arrCustomerObject     = $posted_data['company-details']['details_'];
            $arrCustomerObject     = array_merge($arrCustomerObject, $posted_data['company-details']['contacts_']);
            $arrCustomerObject     = array_merge($arrCustomerObject, $posted_data['company-details']['address_']);

            if (!empty($posted_data['company-details']['previous_'])) {
                $arrCustomerObject     = array_merge($arrCustomerObject, $posted_data['company-details']['previous_']);
            }

            $objCustomerObject    = (object)$arrCustomerObject;
            $objCustomerObject->id = $customer_id;
            $this->invoke('CustomerManager', 'duplicateCheckNonIndividual', array($objCustomerObject), $required = true);
        } catch (Exception $e) {
            $message = $e->getMessage();
        }

        // check if we stil have errors

        if (!$message) {
            // save forced action details
            if (!empty($posted_data['company-details']['question_']['is_forced_action']) && $posted_data['company-details']['question_']['is_forced_action'] == 1) {
                $arrForcedAction = array();
                $arrForcedAction['customer_id']                = $objCustomerObject->id;
                $arrForcedAction['recommender_surname']        = $posted_data['company-details']['forced_']['recommender_surname'];
                $arrForcedAction['recommender_firstname']    = $posted_data['company-details']['forced_']['recommender_firstname'];
                $arrForcedAction['recommender_mobile']        = $posted_data['company-details']['forced_']['recommender_mobile'];
                $arrForcedAction['recommender_email']        = $posted_data['company-details']['forced_']['recommender_email'];
                $arrForcedAction['information_source']        = $posted_data['company-details']['forced_']['information_source'];
                $arrForcedAction['remarks']                    = $posted_data['company-details']['forced_']['remarks'];

                $arrForcedAction['status_id']                = KStatus::ACTIVE;
                $arrForcedAction['created_by']                = $intUserID;
                $intForcedAction = $this->database()->createRecord('forced_action', $arrForcedAction, array('created_date' => KetrouteApplication::db()->getNowExpression()));
            }
            // create acknowledgement
            $objAcknowledgement = new stdClass;
            $objAcknowledgement->form_code         = AcknowledgementManager::COIN_REGISTRATION_FORM_AMENDMENT_FOR_NON_INDIVIDUAL_CODE;
            $objAcknowledgement->reference_name = 'customer';
            $objAcknowledgement->reference_id    = $objCustomerObject->id;
            $objAcknowledgement->status_id         = KStatus::PENDING;
            $objAcknowledgement->created_by     = $intUserID;
            $objAcknowledgement->data_set        = KRequest::getPost("data");
            $strReferenceNumber                 = AcknowledgementManager::saveToAcknowledgement($objAcknowledgement);

            // capture audit log
            $this->logAuditTrail("Captured Amendment of Registration for non-individual", 'registration', $objCustomerObject->id);


            if (!empty($posted_data['company-details']['question_']['is_forced_action']) && $posted_data['company-details']['question_']['is_forced_action'] == 1) {
                // load acknowledgement object
                $objAcknowledgement = $this->database()->load('acknowledgement', array('acknowledgement_reference' => $strReferenceNumber));

                // update forced action table with acknowledgement id					
                $this->database()->updateRecord('forced_action', array('acknowledgement_id' => $objAcknowledgement->id), array('id' => $intForcedAction), $one_record = true);
            } else {

                // send a notification
                $objCustomer = $this->database()->load('customer', array('id' => $objCustomerObject->id));
                CustomerManager::sendCustomerAmendmendNotification($objCustomer, KLanguage::getWord('acknowledgement-form-' . strtolower(AcknowledgementManager::COIN_REGISTRATION_FORM_AMENDMENT_FOR_INDIVIDUAL_CODE)),  $strReferenceNumber);
            }

            $status = 200;
            $message = "Amendment Request Submitted Successfully";
        }
    }
}else{
    $message = "Method not Allowed";
}

echo json_encode([
    "message" => $message,
    "status" => $status,
]);
exit;