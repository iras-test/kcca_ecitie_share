<?php
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

header("Content-type: application/json");

$business_id = KRequest::getQueryString("business_id", null);
$instance = KetrouteApplication::instance();
$trade_licence_business = null;
try {
    $trade_licence_business = $instance->database()->load('trading_license', array(
        'id' => $business_id
    ));
} catch (Exception $e) {
}

if ($trade_licence_business) {

    try {
        $trade_licence_business->customer = $this->runtime()->getFieldData('customer_id', (array)$trade_licence_business);
    } catch (\Exception $th) {
        $trade_licence_business->customer = "";
    }

    try {
        $trade_licence_business->nature_of_business = $instance->db()->load($table = 'nature_of_business', $where = array('id' => $trade_licence_business->business_type_id));
    } catch (\Exception $th) {
        $trade_licence_business->nature_of_business = "";
    }

    try {
        $trade_licence_business->division = $instance->db()->load($table = 'division', $where = array('id' => $trade_licence_business->division));
    } catch (\Exception $th) {
        $trade_licence_business->division = "";
    }

    try {
        $trade_licence_business->parish = $instance->db()->load($table = 'parish', $where = array('id' => $trade_licence_business->parish));
    } catch (\Exception $th) {
        $trade_licence_business->parish = "";
    }

    try {
        $trade_licence_business->village = $instance->db()->load($table = 'village', $where = array('id' => $trade_licence_business->village));
    } catch (\Exception $th) {
        $trade_licence_business->village = "";
    }

    try {
        $trade_licence_business->validity_status = $instance->db()->load($table = 'status', $where = array('id' => $trade_licence_business->status_id));
    } catch (\Exception $th) {
        $trade_licence_business->validity_status = "";
    }

    try {
        $trade_licence_business->expiry = "";
    } catch (\Exception $th) {
        $trade_licence_business->expiry = "";
    }

    try {
        $trade_licence_business->latest_payment_year = "";
    } catch (\Exception $th) {
        $trade_licence_business->latest_payment_year = "";
    }
}

echo json_encode(["details" => $trade_licence_business, "status" => 200]);

exit;
