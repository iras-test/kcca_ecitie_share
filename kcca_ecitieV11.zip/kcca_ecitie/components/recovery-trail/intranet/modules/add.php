<?php

if (Krequest::isPosted()) {

    $coin = $this->getParam('coin', null);
    $ref_name = $this->getParam('ref_name', null);
    $ref_id = $this->getParam('ref_id', null);

    if ($coin && $ref_name && $ref_id) {

        $upload_error = null;
        $attachment_upload_data = [];

        // handle attachments
        $uploaded_attachments = KRequest::getUploadFile('picture');
        $upload_errors = KRequest::getUploadError('picture');
        $uploaded_file_mimes = KRequest::getUploadMime("picture");
        $uploaded_file_names = KRequest::getUploadName("picture");

        foreach ((array)$uploaded_attachments as $key => $attachment_path) {
            if ($upload_errors[$key] == UPLOAD_ERR_OK) {
                $file_name = $uploaded_file_names[$key];
                $file_name = KGenerator::licenseKey($file_name) . '.' . KFile::getExtension($file_name);
                // try to save the attachment
                $document_saved = KFile::uploadTemporaryFile($attachment_path, KFW_STORAGE_PATH . $this->getComponentRealname() . DIRECTORY_SEPARATOR . $file_name, null, KetrouteApplication::reg()->get('CREATE_STORAGE_IF_NOT_EXISTS', false));
                if ($document_saved) {
                    $upload_data = array(
                        'document'             => 'escalation attachment',
                        'document_name'     => $uploaded_file_names[$key],
                        'document_mime'     => $uploaded_file_mimes[$key],
                        'document_sysname'     => $file_name,
                        'attachment_type' => "attachment",
                        "created_by" => KSecurity::getUserID()
                    );
                    $attachment_upload_data[] = $upload_data;
                } else {
                    $upload_error = $upload_error == null ? "" : $upload_error;
                    $upload_error .= "Error saving {$uploaded_file_names[$key]}";
                }
            }
        }

        // handle co response attachments

        $uploaded_attachments = KRequest::getUploadFile('response_attachment');
        $upload_errors = KRequest::getUploadError('response_attachment');
        $uploaded_file_mimes = KRequest::getUploadMime("response_attachment");
        $uploaded_file_names = KRequest::getUploadName("response_attachment");

        foreach ((array)$uploaded_attachments as $key => $attachment_path) {
            if ($upload_errors[$key] == UPLOAD_ERR_OK) {
                $file_name = $uploaded_file_names[$key];
                $file_name = KGenerator::licenseKey($file_name) . '.' . KFile::getExtension($file_name);
                // try to save the attachment
                $document_saved = KFile::uploadTemporaryFile($attachment_path, KFW_STORAGE_PATH . $this->getComponentRealname() . DIRECTORY_SEPARATOR . $file_name, null, KetrouteApplication::reg()->get('CREATE_STORAGE_IF_NOT_EXISTS', false));
                if ($document_saved) {
                    $upload_data = array(
                        'document'             => 'escalation attachment',
                        'document_name'     => $uploaded_file_names[$key],
                        'document_mime'     => $uploaded_file_mimes[$key],
                        'document_sysname'     => $file_name,
                        'attachment_type' => "co_response_attachment",
                        "created_by" => KSecurity::getUserID()
                    );
                    $attachment_upload_data[] = $upload_data;
                } else {
                    $upload_error = $upload_error == null ? "" : $upload_error;
                    $upload_error .= "Error saving {$uploaded_file_names[$key]}";
                }
            }
        }

        if (!$upload_error) {

            $business_details = ArrearsManager::getBusinessDetails($ref_name, $ref_id);

            $trail = $this->database()->createRecord(
                'recovery_trail',
                array(
                    'ref_name'             => $ref_name,
                    'ref_id'             => $ref_id,
                    'coin'                 => $coin,
                    "branch_code" => $business_details->branch_code,
                    "division_id" => $business_details->division_id,
                    'comment'             =>  KRequest::getpost("comment"),
                    'recovery_type_id'     => KRequest::getpost("recovery_type_id"),
                    'co_response_type'     => KRequest::getpost("co_response_type"),
                    'co_response_comment'     => KRequest::getpost("co_response_comment"),
                    'status_id'         => KStatus::ACTIVE,
                    'created_by'        => KSecurity::getUserID()
                ),
                array('created_date' => KetrouteApplication::db()->getNowExpression())
            );

            // save attachments
            foreach ($attachment_upload_data as $key => $uploaded_data) {
                $uploaded_data["recovery_trail_id"] = $trail;
                $trail_attachment = $this->database()->createRecord(
                    'recovery_trail_attachments',
                    $uploaded_data,
                    array('created_date' => KetrouteApplication::db()->getNowExpression())
                );
                // // capture audit log
                $this->logAuditTrail("Attachemt uploaded for recovery_trail #$trail", 'assignment_attachments', $trail_attachment);
            }

            // set success message
            KSecurity::setActionSuccess(KLanguage::getWord('recovery-trail-add-success'));
            KResponse::redirect("{$this->urlPath(0)}view/id/{$trail}");
        } else {
            KSecurity::setActionWarning($upload_error);
        }
    } else {
        KSecurity::setActionWarning("City Operator details not provided");
    }
}

$recovery_types = RecoveryTrail::getRecoveryTypes();
$recovery_options = "";
foreach ($recovery_types as $key => $value) {
    $recovery_options .= "<option value=\"$value->id\">{$value->name}</option>";
}

$response_types = RecoveryTrail::getCoResponseTypes();
$response_options = "";
foreach ($response_types as $value) {
    $response_options .= "<option value=\"$value\">{$value}</option>";
}

$this->render(array(
    "recovery_options" => $recovery_options,
    "response_options" => $response_options
));
