USE ecitie;

INSERT INTO [dbo].[report_modules_config] 
([report_module_id], [column], [to_table_column], 
[display_columns], [expand_relation]) VALUES (1, 'customer_id', 'customer,id','firstname,middle_name',0)