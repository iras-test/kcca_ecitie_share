<?php

/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

$payment_plan_context = [];
$current_user = KSecurity::getUserID();
$case_id_provided = KRequest::getQueryString("case_id", null);
$payment_plan_id_Provided = KRequest::getQueryString("id", null);
$util = new Util();

$payment_plan_obj = null;
if ($case_id_provided) {

    $payment_plan_obj = PaymnentPlanManager::getCasePaymentPlan($case_id_provided);
} else if ($payment_plan_id_Provided) {
    $payment_plan_obj = PaymnentPlanManager::getPaymentPlanByID($payment_plan_id_Provided);
} else {
    KSecurity::setActionWarning("Arrear case or payment plan must be provided");
}

$current_user_profile = UserManager::getProfile($current_user);

if ($payment_plan_obj) {

    $case_id = $payment_plan_obj->arrears_case_id;
    $active_assignment = ArrearCase::getCaseAssignments($info->id);
    $info  = (object) ArrearCase::getItem($case_id);
    $case_status = ($info->status == null) ? ArrearStatus::OPEN : $info->status;
    $bal = abs($info->arrear_amount);

    // round off to the nearest hundredth
    $bal = round($bal, -2);

    $business_details = ArrearsManager::getBusinessDetails($info->ref_name, $info->ref_id);

    $extra_details = "";

    if ($info->ref_name == "vehicle") {
        $extra_details .= "<div class=\"pt10\">
                            <strong><span class=\"bs-bold\">Park</span></strong>: {$business_details->park_name}
                        </div>
                        <div class=\"pt10\">
                            <strong><span class=\"bs-bold\">Stage</span></strong>: {$business_details->stage_name}
                        </div>
                        ";
    }

    $info_display = "
        <div class=\"clear customer-blocks pb10\">
            <h1 class=\"kfw-active-title\"><strong>[lang-arrears-case-details]<strong></h1>
            <div class=\"clear pt10\">
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Customer</span></strong>: {$info->customer}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">COIN</span></strong>: {$info->coin}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Revenue name</span></strong>: {$info->revenue_name}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Branch Code</span></strong>: {$business_details->branch_code}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Location</span></strong>: {$business_details->location}
                </div>
                {$extra_details}
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Outstanding balance</span></strong>: {$bal}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Case Status</span></strong>: <span class=\"{$util::StatusClass($case_status)}\">{$case_status}</span>
                </div>
            </div>
        </div>
    ";

    $payment_plan_context["case_id"] = $case_id;
    $payment_plan_context["info_display"] = $info_display;
    $payment_plan_context["pp_id"] = $payment_plan_obj->id;
    $payment_plan_context["reason"] = $payment_plan_obj->creation_reason;
    $payment_plan_context["status"] = $payment_plan_obj->approval_status == 1 ? "Approved" :($payment_plan_obj->approval_status == 3?"Closed":"Pending");

    $created_by = PaymnentPlanManager::getUserDetails($payment_plan_obj->created_by);

    $payment_plan_context["created_by"] = "{$created_by->firstname} {$created_by->surname}";

    $payment_plan_payment_periods = PaymnentPlanManager::getPaymentPlanPaymentPeriods($payment_plan_obj->id);
    $records = "";
    foreach ($payment_plan_payment_periods as $index => $period) {

        $class = ($index % 2 == 0) ? ' odd' : ' even';
        $record_number = ($index + 1);
        $period_obj = (object)$period;

        $period_date = date('d,M,Y', strtotime($period_obj->payment_date_stated));

        $status = $period_obj->payment_id != null
            ? "<div class=\"fl arrears-col arr-text-green\">Paid</div>"
            : "<div class=\"fl arrears-col arr-text-orange\">Not yet Paid</div>";

        $records .= "<div class=\"clear list-item{$class}\">";
        $records .= "\n\t\t\t<div class=\"fl numbering-col\">{$record_number}</div>";
        $records .= "\n\t\t\t<div class=\"fl arrears-col\">{$period_date}</div>";
        $records .= "\n\t\t\t<div class=\"fl arrears-col\">{$period_obj->amount_stated}</div>";
        $records .= "\n\t\t\t{$status}";
        $records .= "\n\t\t</div>";
    }


    $attachment_string = "";
    $payment_plan_attachments = PaymnentPlanManager::getPaymentPlanAttachments($payment_plan_obj->id);
    foreach ($payment_plan_attachments as $key => $attachment) {
        $attachment_string .= "<a href=\"[link_in_use]arrears/download-payment-plan-doc/id/{$attachment->id}\">{$attachment->document_name}</a><br>";
    }

    $approval_form_identifier = "mykfwform-{$this->getComponent()}-{$this->getModule()}";
    $payment_plan_context['records'] = $records;
    $payment_plan_context['form_action'] = "{$this->urlPath(0)}payment-plan-approval-action";
    $payment_plan_context['form_identifier'] = $approval_form_identifier;
    $payment_plan_context['back_url'] = KSecurity::getSession('BACK_URL');
    $payment_plan_context["attachments"] = $attachment_string;

    return $this->render($payment_plan_context);
}
$this->stopRedirector(KSecurity::getSession('BACK_URL'));
