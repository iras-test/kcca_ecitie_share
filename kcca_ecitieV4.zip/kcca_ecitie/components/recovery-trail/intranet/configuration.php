<?php
/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

$trail                                                    = array();
$trail[KSystemManager::ITEM_PROPERTY_TABLE_NAME]          = 'recovery_trail';
$trail[KSystemManager::ITEM_PROPERTY_LIST_FIELDS]         = array('id','ref_name', 'ref_id', 'coin', 'comment', 'recovery_type_id', 'created_date', 'created_by', 'picture');
$trail[KSystemManager::ITEM_PROPERTY_VIEW_FIELDS]         = array('id','ref_name', 'coin', 'recovery_type_id','comment', 'division_id', 'branch_code','co_response_type','co_response_comment', 'created_date', 'picture',  'created_by');

$trail[KSystemManager::ITEM_PROPERTY_ADD_FIELDS] 		= array('recovery_type_id','picture');																								
$trail[KSystemManager::ITEM_PROPERTY_EDIT_FIELDS] 		= array('recovery_type_id','picture');																										
$trail[KSystemManager::ITEM_PROPERTY_SORT_FIELDS] 		= array('id' => KSystemManager::SORT_DESCENDING);


$trail[KSystemManager::ITEM_PROPERTY_PRIMARY_KEY] 		= 'id';
$trail[KSystemManager::ITEM_PROPERTY_TITLE_FIELD] 		=  'coin';

$trail[KSystemManager::ITEM_PROPERTY_FIELDS] = array(); 

$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['ref_name'] 				                                  = array();
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['ref_name'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE]        = KSystemManager::FIELD_TYPE_SELECT;
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['ref_name'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL]       = 'recovery-trail-reference-name';
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['ref_name'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH]   = 100;
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['ref_name'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH]   = null;
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['ref_name'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED]    = 1;
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['ref_name'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT]     = $this->getParam('reference_name', 1);
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['ref_name'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 	   = array(
    KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'recovery_trail_reference',
    KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'reference_name' , 
    KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> 'label',
    KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
    KSystemManager::WHERE_CLAUSE 						=> null,
    KSystemManager::ORDER_BY  							=> array('reference_name' => KSystemManager::SORT_ASCENDING)
);


$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['recovery_type_id'] 				                                  = array();
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['recovery_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE]        = KSystemManager::FIELD_TYPE_SELECT;
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['recovery_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL]       = 'recovery-trail-type';
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['recovery_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH]   = 100;
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['recovery_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH]   = null;
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['recovery_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED]    = 1;
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['recovery_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT]     = '';
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['recovery_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 	   = array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'recovery_type',
    KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
    KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> 'name',
    KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
    KSystemManager::WHERE_CLAUSE 						=> null,
    KSystemManager::ORDER_BY  							=> array('name' => KSystemManager::SORT_ASCENDING),
);

$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['division_id'] 				                                  = array();
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['division_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE]        = KSystemManager::FIELD_TYPE_SELECT;
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['division_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL]       = 'division';
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['division_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH]   = 100;
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['division_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH]   = null;
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['division_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED]    = 1;
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['division_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT]     = '';
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['division_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 	   = array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'division',
    KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
    KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> 'name',
    KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
    KSystemManager::WHERE_CLAUSE 						=> null,
    KSystemManager::ORDER_BY  							=> array('name' => KSystemManager::SORT_ASCENDING),
);

$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['created_by'] 				                                  = array();
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['created_by'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE]        = KSystemManager::FIELD_TYPE_SELECT;
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['created_by'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL]       = 'recovery-trail-created-by';
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['created_by'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH]   = 100;
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['created_by'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH]   = null;
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['created_by'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED]    = 1;
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['created_by'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT]     = '';
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['created_by'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 	   = array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'user',
    KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
    KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> array('surname', 'firstname'),
    KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
    KSystemManager::WHERE_CLAUSE 						=> null,
    KSystemManager::ORDER_BY  							=> array('name' => KSystemManager::SORT_ASCENDING),
);


$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['picture'] 														= array();
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['picture'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 			= KSystemManager::FIELD_TYPE_FILE_UPLOAD;
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['picture'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 			= 'document';
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['picture'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] 		= (1024 * 1024)/1.5;
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['picture'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] 		= null;
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['picture'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 		= false;
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['picture'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 			= null;
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['picture'][KSystemManager::ITEM_FIELD_PROPERTY_AJAX_UPLOAD] 		= false;

// file storage
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['picture'][KSystemManager::ITEM_FIELD_PROPERTY_STORAGE_MEDIA] 					= KSystemManager::STORAGE_MEDIA_FILE_SYSTEM;
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['picture'][KSystemManager::ITEM_FIELD_PROPERTY_STORAGE_MEDIA_FILE_SYSTEM_PATH] 	= KFW_STORAGE_PATH . $this->getComponentRealname() . DIRECTORY_SEPARATOR;

// thumb rules
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['picture'][KSystemManager::ITEM_FIELD_PROPERTY_FILE_TYPE] 				= KSystemManager::FILE_TYPE_WEB_IMAGE;
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['picture'][KSystemManager::ITEM_FIELD_PROPERTY_DOWNLOADABLE] 			= true;
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['picture'][KSystemManager::ITEM_FIELD_PROPERTY_IGNORE_UPLOAD_ERROR ] 	= false;
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['picture'][KSystemManager::ITEM_FIELD_PROPERTY_OVERWRITE_IF_EXISTS] 		= true;
$trail[KSystemManager::ITEM_PROPERTY_FIELDS]['picture'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 					= array();
		
return $trail;