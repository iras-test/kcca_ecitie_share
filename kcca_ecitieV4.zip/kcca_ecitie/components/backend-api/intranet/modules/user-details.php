<?php

header("Content-type: application/json");
AuthWrapper::getAuthenticatedUser();

$session_key = KSecurity::sessionUserStorage();
$user_object = [
    'user' => unserialize(KSecurity::getSession($session_key)),
    "status" => 200
];

echo json_encode($user_object);
exit;