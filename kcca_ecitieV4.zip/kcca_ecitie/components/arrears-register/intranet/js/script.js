
let selectArrears = [];
let selectedAll = false;

function handleArrearSelection(select, id){
    if(select.checked) {
        selectArrears.push(id);

    } else {
        selectArrears = selectArrears.filter(it => it != id)
    }

    document.getElementById("multiselect").style.display = selectArrears.length? "inline-block": "none"
}

function selectAll(button) {
    selectedAll = !selectedAll;
    button.innerText = selectedAll? "Unselect All": "Select All";
    var inputs = document.getElementsByTagName("input");
    for(var i = 0; i < inputs.length; i++) {
        var input = inputs[i];
        if((input.type == "checkbox") && (input.checked != selectedAll)) {
            input.click(); 
        }  
    }
}

function assignMultiple() {
    const formData = new FormData();
    formData.append("ids", JSON.stringify(selectArrears));
    formData.append("assignee", document.getElementById("assignee").value);
    formData.append("assigned_action", document.getElementById("assigned_action").value);
    fetch(
        window.location.href,
        {
            method: "POST",
            body: formData
        }
    )
    .then(resp => resp.json())
    .then(() => {
        window.location.reload();
    })
    .catch(() => window.alert("Failed to create arrear cases"));
}