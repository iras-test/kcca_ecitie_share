<?php

/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

class ObjectionManager
{
    public static function create($arrear_case_id, $ref_name, $ref_id, $comment) {
        return KetrouteApplication::db()
            ->createRecord(
                'arrears_case_objection', 
                array(
                    "arrear_case_id" => $arrear_case_id,
                    "ref_id" => $ref_id,
                    "ref_name" => $ref_name,
                    "comment" => $comment,
                    "created_by" => KSecurity::getUserID()
                ),
                array('created_date' => KetrouteApplication::db()->getNowExpression())
            );
    }

    public static function getObjectionById($id) {
        return KetrouteApplication::db()->load($table = 'arrears_case_objection', $where = array('id' => $id));
    }

    public static function getList($page, $queryParams)
    {
        list($start, $end) = ArrearsManager::getPagination($page);
        $genericSQL = ObjectionManager::getQueryData($queryParams);
        $SQL = "WITH results AS
            (
                $genericSQL
            )
            SELECT * FROM results  WHERE RowNum BETWEEN $start AND $end ORDER BY id DESC
        ";

        return KetrouteApplication::db()->execute($SQL);
    }

    public static function count($queryParams)
    {
        $where = self::where($queryParams);
        $SQL = "SELECT COUNT(obj.id) AS total FROM arrears_case_objection AS obj 
        LEFT JOIN arrear_case arr ON arr.id = obj.arrear_case_id 
        LEFT JOIN customer customer ON customer.id = arr.customer_id 
        WHERE $where";
        $res = (object) KetrouteApplication::db()->execute($SQL);
        return $res->fields["total"];
    }

    public static function getQueryData($queryParams)
    {
        $where = self::where($queryParams);
        return "SELECT obj.id, obj.ref_id, (SELECT label FROM recovery_trail_reference WHERE reference_name = obj.ref_name) AS revenue_type,
            obj.created_date, (SELECT name from ground_of_objection WHERE id = obj.ground_of_objection) AS obj_ground, arr.customer_id, arr.branch_code as branch_code,
            customer.coin, obj.comment, obj.arrear_case_id,
            ROW_NUMBER() OVER (ORDER BY obj.id DESC) AS rowNum FROM arrears_case_objection AS obj 
            INNER JOIN arrear_case arr ON arr.id = obj.arrear_case_id 
            LEFT JOIN customer customer ON customer.id = arr.customer_id 
            WHERE $where
        ";
    }

    public static function where($queryParams) {
        $current_user = KSecurity::getUserID();
        $where = "obj.status_id = '1' ";
        if (UserManager::getProfile($current_user)->user_role_id != ArrearStatus::ARREARS_MANAGER_ROLE) {
            $where .= " AND obj.created_by = '$current_user' ";
        }

        $where .= self::buildWhere($queryParams);
        return $where;
    }

    public static function buildWhere($queryParams) {
        $where = "";

        if (array_key_exists("branch_code", $queryParams)  && $queryParams['branch_code']) {
            $branch_code = trim($queryParams["branch_code"]);
            $where .= " AND arr.branch_code = '$branch_code' ";
        }

        if (array_key_exists("start", $queryParams)  && $queryParams['start']) {
            $start = $queryParams["start"];
            $where .= " AND obj.created_date >= '$start 00:00:00' ";
        }

        if (array_key_exists("end", $queryParams)  && $queryParams['end']) {
            $end = $queryParams["end"];
            $where .= " AND obj.created_date <= '$end 23:59:59' ";
        }


        if (array_key_exists("coin", $queryParams)  && $queryParams['coin']) {
            $customer = "customer";
            $coin = $queryParams["coin"];
            $where .= " AND $customer.coin like '%$coin%'";
        }

        return $where;
    }
}