
<?php

(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
set_time_limit(0);

$biz_count = 0;

foreach (ArrearsManager::getExpiredYesterday() as $business) {

    $business = (object)$business;
    print("$biz_count : updating business details... ");
    # Update status
    ArrearsManager::updateBusinessArrearStatus($business->ref_name, $business->ref_id, ArrearStatus::BUSINESS_MOVED_TO_ARREARS);
    print("updated business details\n");

    // Transfer to arrears
    print("creating arrear case....");
    ArrearCase::create(
        $business->customer_id,
        $business->ref_id,
        $business->ref_name,
        null,
        ArrearStatus::OPEN,
        $business->due_date,
        $business->revenue_type_id
    );
    print("creating arrear case\n");
    $biz_count++;
}
