<?php

class BusinessSealManager
{

    const BUSINESS_SEAL_REVOKE = "revoke";

    const STATUS_REVOKED = 2;

    public static function getBusinessSealActionByID($business_seal_id)
    {
        $SQL = "SELECT * FROM arrears_business_seal WHERE id = :business_seal_id:";
        $bindings_extra[':business_seal_id:'] = $business_seal_id;

        $results = null;
        $resultsarr = KetrouteApplication::db()->execute($SQL, $bindings_extra);

        if (isset($resultsarr->fields) && $resultsarr->fields) {

            while (!$resultsarr->EOF) {

                $results = (object)$resultsarr->fields;
                $resultsarr->MoveNext();
            }
        }
        return $results;
    }

    public static function business_seal_approval_action($an_id, $approval_action, $case_status)
    {
        $action_by = KSecurity::getUserID();

        $action_on = date('Y-m-d');

        $bindings_extra = [];

        $SQL = "UPDATE arrears_business_seal SET seal_status = :approval_action:, 
                modified_by = :action_by:, modified_date = :action_on: ";

        $SQL .= "WHERE id = :an_id:";

        $bindings_extra[':approval_action:'] = $approval_action;
        $bindings_extra[':action_by:'] = $action_by;
        $bindings_extra[':an_id:'] = $an_id;
        $bindings_extra[':action_on:'] = $action_on;


        KetrouteApplication::db()->execute($SQL, $bindings_extra);

        KetrouteApplication::instance()->logAuditTrail("Changed business seal status to #$approval_action", 'arrears_agency_notice', $an_id);

        // update case
        if ($case_status) {

            $case_id = self::getBusinessSealActionByID($an_id)->arrears_case_id;
            ArrearCase::updateStatus($case_id, $case_status);
        }
    }
}
