<?php

class StatementOFAccountHelper{

    const BASE_URL = KFW_LINK_IN_USE;
    public static $STATEMENT_OF_ACCOUNT_MAPPER = [
        "property"=>"property/print-statement/id/",
        "lst"=>"localservicetax/print-statement/id/",
        "lht"=>"local-hotel-tax/print-statement/id/",
        "gound_rent"=>"groundrent/print-statement/id/",
        "trade_license"=>"registration/print-statement/id/",
    ];

    public static function getStatementOfAccount($ref, $ref_id){
        if (isset(self::$STATEMENT_OF_ACCOUNT_MAPPER[$ref])) {
            return self::BASE_URL.self::$STATEMENT_OF_ACCOUNT_MAPPER[$ref].$ref_id."/";
        }
        return self::BASE_URL."registration/print-statement/id/$ref_id/";
    }

}