use ecitie;

ALTER TABLE [dbo].[arrear_case] ADD [due_date] [DATETIME2]

ALTER TABLE [dbo].[arrear_case] ADD [revenue_type_id] [INT]
