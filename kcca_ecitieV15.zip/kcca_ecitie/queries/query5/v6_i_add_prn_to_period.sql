
use ecitie;

ALTER TABLE [dbo].[payment_plan_period] ADD [payment_prn] [nvarchar](50) NULL