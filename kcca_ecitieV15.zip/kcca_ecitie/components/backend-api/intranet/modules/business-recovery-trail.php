<?php

(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

header("Content-type: application/json");

$ref_name = KRequest::getQueryString("ref_name", null);
$ref_id = KRequest::getQueryString("ref_id", null);

$response = [];

if ($ref_name && $ref_id) {

    $activities = array();
    foreach (RecoveryTrail::getListByRef($ref_name, $ref_id) as $value) {

        $obj = (object)$value;
        $recovery_type = RecoveryTrail::getRecoveryType($obj->recovery_type_id);
        $created_by = UserManager::getProfile($obj->created_by);
        $posted_by = "$created_by->firstname $created_by->surname";
        $row = [
            "recovery_type" => $recovery_type->name,
            "posted_date" => $obj->created_date,
            "posted_by" => $posted_by,
            "picture" => "picture_url",
            "remarks" => $obj->comment,
            "x_coordinates"=>$obj->x_coordinates,
            "y_coordinates"=>$obj->y_coordinates
        ];

        array_push($activities, $row);
    }

    $response = [
        "activities" => $activities,
        "status" => 200
    ];
}else{

    $response = [
        "message" => "Missing parameters",
        "status" => 400
    ];


}



echo json_encode($response);
exit;
