<?php
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

header("Content-type: application/json");
$instance = KetrouteApplication::instance();
$applications = [];
try {
    $coin = KRequest::getQueryString("coin", null);
    $customer = $instance->db()->load($table = 'customer', $where = array('coin' => $coin));
    $where_clause = array('customer_id' => $customer->id);
    $result = $instance->db()->getList(
        "trading_license_application",
        $where = $where_clause,
        $fields = '*',
        $pager_info = null,
        $where_in = null,
        $likeforlike_binding = null,
        $startwith_binding = null,
        $endwith_binding = null,
        $hasatleast_binding = null,
        $greaterthanequal_binding = null,
        $lessthanequal_binding = null,
        $between_binding = null,
        $year_binding = null,
        $order_ascending = null,
        $order_descending = 'financial_year'
    );

    foreach ($result as $app) {
        $tlc_branch = $instance->db()->getStaticTableValue("trading_license", "id", "code", $app->trading_license_id);
        $app->tlc_branch_code = $tlc_branch;
        $app->amount = abs($app->amount);
        $applications[] = $app;
    }
} catch (\Exception $th) {
}

echo json_encode(["applications" => $applications, "status" => 200]);

exit;
