<?php

$info = null;
$error = null;
$case = array();
$util = new Util();
$escalation_info = "";
$assignee_options = "";
$active_assignment = (object)[];
$current_user = KSecurity::getUserID();
$esclation_history = "";
$case_id = $this->getParam('case', 1);

/** HANDLE DOCUMENT DOWNLOAD */
$download = $this->getParam('download', 1);

if($download == 'ackn') {
    $id = $this->getParam('id', 1);
    $litigation = $this->database()->load($table = 'arrears_case_litigation', $where = array('id' => $id));
    $docName = $litigation->document . '.' . KFile::getExtension($litigation->document_name);
    $docPath = KFW_STORAGE_PATH . $this->getComponentRealname() . DIRECTORY_SEPARATOR . $litigation->document_sysname;
    KFile::downloadFile($docName, $docPath, $delete_file_when_done = false);
}

if($download == 'mou') {
    $id = $this->getParam('id', 1);
    $litigation = $this->database()->load($table = 'arrears_case_litigation', $where = array('id' => $id));
    $docName = $litigation->mou_document . '.' . KFile::getExtension($litigation->mou_document_name);
    $docPath = KFW_STORAGE_PATH . $this->getComponentRealname() . DIRECTORY_SEPARATOR . $litigation->mou_document_sysname;
    KFile::downloadFile($docName, $docPath, $delete_file_when_done = false);
}
/** END */

if (KRequest::isPosted()) {
    // Acknowledgent
    $file_name = KRequest::getUploadName('document');
    $file_name = $file_name? KGenerator::licenseKey($file_name).'.'.KFile::getExtension($file_name): null;
    KFile::uploadTemporaryFile(KRequest::getUploadFile('document'), KFW_STORAGE_PATH . $this->getComponentRealname() . DIRECTORY_SEPARATOR .$file_name, null, KetrouteApplication::reg()->get('CREATE_STORAGE_IF_NOT_EXISTS', false));

    // MOU or summary warrant
    $mou_file_name = KRequest::getUploadName('mou_document');
    $mou_file_name = $mou_file_name? KGenerator::licenseKey($mou_file_name).'.'.KFile::getExtension($mou_file_name): null;
    KFile::uploadTemporaryFile(KRequest::getUploadFile('mou_document'), KFW_STORAGE_PATH . $this->getComponentRealname() . DIRECTORY_SEPARATOR .$mou_file_name, null, KetrouteApplication::reg()->get('CREATE_STORAGE_IF_NOT_EXISTS', false));
    
    $litigation = $this->database()->createRecord(
        'arrears_case_litigation', 
        array(
            "arrears_case_id"        => $case_id,
            "legal_action"          => KRequest::getPost("legal_action"),
            "description"           =>  KRequest::getPost('description'),
            "action_taken_by"       =>  KRequest::getPost('action_taken_by'),
            "action_date"           =>  KRequest::getPost('action_date'),

            'document' 		    	=> 'acknowledgemt_notice_or_report',
            'document_name'     	=> KRequest::getUploadName('document'),
            'document_mime' 	    => KRequest::getUploadMime('document'),
            'document_sysname'  	=> $file_name,

            'mou_document' 		    	=> 'mou_or_summary',
            'mou_document_name'     	=> KRequest::getUploadName('mou_document'),
            'mou_document_mime' 	    => KRequest::getUploadMime('mou_document'),
            'mou_document_sysname'  	=> $mou_file_name,

            "created_by"            => KSecurity::getUserID()
        ),
        array('created_date' => KetrouteApplication::db()->getNowExpression())
    );

    // // capture audit log
    $this->logAuditTrail("Litigation Action Recorded for Arrears Case #$case_id", 'arrears_case_litigation', $litigation);

    // // // set success message
    KSecurity::setActionSuccess(KLanguage::getWord('arrears-litigation-action', array('arrears_case' => $arrears_case_id)));
}

$info  = (object) ArrearCase::getItem($case_id);
$bills = ArrearsManager::getAllPaymentBills($info->ref_name, $info->ref_id);
$recovery_trail = RecoveryTrail::getListByRef($info->ref_name, $info->ref_id);
$feedbacks = ArrearCaseFeedback::getAllFeedback($case_id);
$lega_action_types = LegalManager::getTypes();

/** Recovery trail */
$trail = "";
if(count($recovery_trail) > 0) {
    // show records
    foreach ($recovery_trail as $index => $arrData) {
        $strPrimaryKey = $this->runtime()->getPrimaryKey();
        $class = ($index % 2 == 0) ? ' odd' : ' even';
        $record_number = $_page > 1? ($index + 1) + ($MAX_PER_PAGE * ($_page - 1)): ($index + 1);

        $list_counter++;

        // convert to object
        $obj = (object)$arrData;

        $customer = (object) CustomerManager::getCustomerByCoin($obj->coin);
        $revenue = RecoveryTrail::getRevenueByRef($obj->ref_name);
        $recovery_type = RecoveryTrail::getRecoveryType($obj->recovery_type_id);

        $trail .= "\n\t\t<div class=\"clear list-item{$class}\">";
        $trail .= "\n\t\t\t<div class=\"fl numbering-col\">{$record_number}</div>";
        $trail .= "\n\t\t\t<div class=\"fl col20\">{$recovery_type->name}</div>";

        $trail .= "\n\t\t\t<div class=\"fl col10\">
            <a href=\"[link_in_use]recovery-trail/view/id/{$obj->id}\">View</a>
        </div>";

        // end of item
        $trail .= "\n\t\t</div>";
    }

} else {
    $trail  = "\n\t\t<div class=\"clear list-item\">" . KLanguage::getWord('recovery-trail-no-items') . "</div>";
}

$legal_action_options = "";
foreach ($lega_action_types as $key => $value) {
    $legal_action_options .= "<option value=\"$value->id\">{$value->name}</option>";
}

$legal_actions = Util::getLegalHistory($case_id);


$info_display = null;
$actions_link = null;
if ($info) {
    $prn = $info->prn ? $info->prn : "N/A";
    $case_status = ($info->status == null) ? ArrearStatus::OPEN : $info->status;
    $bal = ArrearsManager::getOutstandingBal($info->ref_name, $info->ref_id);

    $business_details = ArrearsManager::getBusinessDetails($info->ref_name, $info->ref_id);

    $extra_details = "";

    if ($info->ref_name == "vehicle") {
        $extra_details .= "<div class=\"pt10\">
                            <strong><span class=\"bs-bold\">Park</span></strong>: {$business_details->park_name}
                        </div>
                        <div class=\"pt10\">
                            <strong><span class=\"bs-bold\">Stage</span></strong>: {$business_details->stage_name}
                        </div>
                        ";
    }

    $info_display = "
        <div class=\"clear customer-blocks pb10\">
            <h1 class=\"kfw-active-title\"><strong>[lang-arrears-case-details]<strong></h1>
            <div class=\"clear pt10\">
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Customer</span></strong>: {$info->customer}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">COIN</span></strong>: {$info->coin}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Revenue name</span></strong>: {$info->ref_name}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Branch Code</span></strong>: {$business_details->branch_code}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Location</span></strong>: {$business_details->location}
                </div>
                {$extra_details}
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Outstanding balance</span></strong>: {$bal}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Status</span></strong>: <span class=\"{$util::StatusClass($case_status)}\">{$case_status}</span>
                </div>
            </div>
        </div>
    ";


    // case escalation and actions
    $assignments = ArrearCase::getCaseAssignmentsCount($info->id);
    $active_assignment = ArrearCase::getCaseAssignments($info->id);

    if (
        (($assignments == 0) && ($info->assignee == $current_user))
        ||
        (($active_assignment != null) && ($active_assignment->user_id == $current_user))
    ) {

        $has_active_payment_plan = PaymnentPlanManager::getCasePaymentPlan($info->id, true);
        $payment_plan_created = PaymnentPlanManager::getCasePaymentPlan($info->id);

        $has_active_agency_notice_issued = ArrearCase::getCaseAgencyNoticeActions($info->id);
        $agency_notice_issued = ArrearCase::getCaseAgencyNoticeActions($info->id, false);

        $has_active_business_seal = ArrearCase::getCaseBusinessSealActions($info->id);
        $business_sealed = ArrearCase::getCaseBusinessSealActions($info->id, false);
        $actions_link = "<h1 class=\"kfw-active-title pt10\"><strong>Actions<strong></h1>";

        if (!($has_active_agency_notice_issued || $has_active_business_seal)) {
            $actions_link .= "<div class=\"clear pt10\"><div class=\"field\"><label><strong>Payment Plan<strong></label></div><div class=\"data pt10\">";
            $actions_link .= $payment_plan_created
                ? "<a class=\"arr-text-green\" href=\"[link_in_use]arrears/view-payment-plan?case_id={$info->id}\">View Requested Payment Plan</a>"
                : "<a class=\"arr-text-orange\" href=\"[link_in_use]arrears/create-payment-plan?case_id={$info->id}\">Request for Payment Plan</a>";
            $actions_link .= "</div></div>";
        }

        if (!($has_active_business_seal || $has_active_payment_plan)) {
            $actions_link .= "<div class=\"clear pt10\"><div class=\"field\"><label><strong>Agency Notice<strong></label></div><div class=\"data pt10\">";
            $actions_link .= $agency_notice_issued
                ? "<a class=\"arr-text-green\" href=\"[link_in_use]arrears/view-agency-notice?id={$agency_notice_issued->id}\">View Issued Agency Notice</a>"
                : "<a class=\"arr-text-orange\" href=\"[link_in_use]arrears/create-agency-notice?case_id={$info->id}\">Issue Agency Notice</a>";
            $actions_link .= "</div></div>";
        }


        if (!($has_active_agency_notice_issued || $has_active_payment_plan)) {
            $actions_link .= "<div class=\"clear pt10\"><div class=\"field\"><label><strong>Business Seal<strong></label></div><div class=\"data pt10\">";
            $actions_link .= $business_sealed
                ? "<a class=\"arr-text-green\" href=\"[link_in_use]arrears/view-business-seal?id={$business_sealed->id}\">View Business Seal Details</a>"
                : "<a class=\"arr-text-orange\" href=\"[link_in_use]arrears/create-business-seal?case_id={$info->id}\">Seal Business</a>";
            $actions_link .= "</div></div>";
        }

        $escalation_info = "<h1 class=\"kfw-active-title pt10\"><strong>Escalation<strong></h1>";
        if ($assignments > 0) {

            $escalation_info .= "
                    <div class=\"clear pt10\">
                    <button type=\"button\" class=\"submit\" onclick=\"escalate_back()\">Route Back</button>
                    </div>
                    <form style=\"display:none;\" action=\"[escalation_url]\" method=\"post\" id=\"escalate-case-back\" name=\"escalate-case\" enctype=\"multipart/form-data\">	
                        <input type=\"hidden\" value=\"b\" name=\"escalation_action\" />
                        <input type=\"hidden\" value=\"[arrear_case_id]\" name=\"arrear_case_id\" />
                        <input type=\"hidden\" value=\"[current_assignment]\" name=\"current_assignment\" />
                        <div>
                            <label><strong>Comment</strong></label>
                            <div class=\"clear pt10\">
                                <textarea rows=\"5\" required name=\"comment\" placeholder=\"Comment\"></textarea>
                            </div>
                            <div class=\"clear pt10\">
                                <button type=\"submit\" class=\"submit\">Submit</button>
                            </div>
                        </div>
                </form>
                    ";
        }
    }

    // escalation history
    $assigments = ArrearCase::getCaseAssignments($info->id, $active_only = false);
    foreach ($assigments as $index => $this_assignment) {

        $class = ($index % 2 == 0) ? ' odd' : ' even';
        // $assigment_obj = (object) $this_assignment;
        $record_number = $index + 1;

        $created_by = UserManager::getProfile($this_assignment->created_by);
        $created_by_names = "$created_by->firstname $created_by->surname";

        $assigned_to = UserManager::getProfile($this_assignment->user_id);
        $assigned_to_names = "$assigned_to->firstname $assigned_to->surname";

        $status = $this_assignment->active ? 'Active' : 'Done';

        $esclation_history .= "<div class=\"clear list-item{$class}\">";
        $esclation_history .= "\n\t\t\t<div class=\"fl numbering-col\">{$record_number}</div>";
        $esclation_history .= "\n\t\t\t<div class=\"fl arrears-col\">{$created_by_names}</div>";
        $esclation_history .= "\n\t\t\t<div class=\"fl arrears-col\">{$assigned_to_names}</div>";
        $esclation_history .= "\n\t\t\t<div class=\"fl arrears-col\">{$this_assignment->comment}</div>";
        $esclation_history .= "\n\t\t\t<div class=\"fl arrears-col\">{$this_assignment->created_date}</div>";
        $esclation_history .= "\n\t\t\t<div class=\"fl arrears-col\">{$status}</div>";
        $esclation_history .= "\n\t\t</div>";
    }
}

/** Bill breakdowns */
if (count($bills) > 0) {
    // show record	
    foreach ($bills as $index => $arrData) {
        $class = ($index % 2 == 0) ? ' odd' : ' even';
        $obj = (object) $arrData;
        $record_number = $index + 1;
        $prn = $obj->prn ? $obj->prn : "N/A";

        $records .= "<div class=\"clear list-item{$class}\">";
        $records .= "\n\t\t\t<div class=\"fl numbering-col\">{$record_number}</div>";
        $records .= "\n\t\t\t<div class=\"fl col20\">{$obj->financial_year}</div>";
        $records .= "\n\t\t\t<div class=\"fl col20\">{$prn}</div>";
        $records .= "\n\t\t\t<div class=\"fl col20\">{$obj->due_date}</div>";
        $records .= "\n\t\t\t<div class=\"fl col20\">{$obj->amount}</div>";
        $records .= "\n\t\t</div>";
    }
} else {
    $records  = "\n\t\t<div class=\"clear list-item\">" . KLanguage::getWord('arrears-case-items') . "</div>";
}

/** Feedback breakdowns */
$feedback_info = "";
if (count($feedbacks) > 0) {
    // show record	
    foreach ($feedbacks as $index => $arrData) {
        $class = ($index % 2 == 0) ? ' odd' : ' even';
        $obj = (object) $arrData;
        $record_number = $index + 1;

        $feedback_type = ArrearCaseFeedback::getFeedbackType($obj->feedback_type)
            ? ArrearCaseFeedback::getFeedbackType($obj->feedback_type)
            : "N/A";

        $feedback_info .= "<div class=\"clear list-item{$class}\">";
        $feedback_info .= "\n\t\t\t<div class=\"fl numbering-col\">{$record_number}</div>";
        $feedback_info .= "\n\t\t\t<div class=\"fl col20\">{$obj->created_date}</div>";
        $feedback_info .= "\n\t\t\t<div class=\"fl col20\">{$obj->location}</div>";
        $feedback_info .= "\n\t\t\t<div class=\"fl col20\">{$feedback_type}</div>";
        $feedback_info .= "\n\t\t\t<div class=\"fl col20\">{$obj->feedback}</div>";
        $feedback_info .= "\n\t\t</div>";
    }

} else {
    $feedback_info  = "\n\t\t<div class=\"clear list-item\">" . KLanguage::getWord('arrears-case-no-feedback') . "</div>";
}

$user = KSecurity::getUserObject();

$case["options"] = $options;
$case["escalation_info"] = $escalation_info;
$case["esclation_history"] = $esclation_history;
$case["info_display"] = $info_display;
$case["actions_info"] = $actions_link;
$case["legal_actions"] = $legal_actions;
$case["bills"] = $records;
$case["loggedin_user"] = "$user->surname $user->firstname";
$case["trail"] = $trail;
$case["feedback_info"] = $feedback_info;
$case["assignee_options"] = $assignee_options;
$case["legal_action_options"] = $legal_action_options;
$case["error"] = $error;
$case["arrear_case_id"] = $case_id;
$case["current_assignment"] = $active_assignment->id;
$case["close_url"] = "action={$this->urlPath(0)}close-case?id={$case_id}";
$case["escalation_url"] = "{$this->urlPath(0)}escalate-case";


$this->render($case);
