<?php

class NotificationManager
{
    public static function notifyOnPayment($prn)
    {
        /**
         * Check if it payment is made for an arrear
         * If an arrear, check is there's a case attached to it
         */
        $payment = KetrouteApplication::instance()->database()->load('payment', array('prn' => $prn));
        $payment_bill = KetrouteApplication::instance()->database()->load('payment_bill', array('payment_id' => $payment->id));
        if ($payment_bill->due_date <= date('Y-m-d')) {
            // Consider as arrear payment
            $customer = KetrouteApplication::instance()->database()->load('customer', array('id' => $payment_bill->customer_id));
            // System notice
            $body = "Drear $customer->firstname,  Please note your payment for has been received.Thank you";
            self::create($customer->id, 'Payment Notice', $body, true);
            // Email/SMS Notice
            self::notify('arrear_payment', $customer->email, $customer->mobile, $customer->firstname);

            // Check if there's an arrears case under business seal attached
            $sealed_case = ArrearCase::hasCaseUnderBusinessSeal($payment_bill->reference_id, $payment_bill->reference_name);

            /** Update payment */
            KetrouteApplication::instance()->database()->updateRecord(
                'payment',
                array('transaction_status' => 'C'),
                array('id' => $payment->id),
                $one_record = true,
                array('modified_date' => KetrouteApplication::instance()->database()->getNowExpression())
            );

            if ($sealed_case) {
                $assignee = (object) ArrearsManager::getUser($sealed_case->assignee);
                // System notice
                $body = "Drear  $assignee->firstname, Payment for $customer->name has been received and you are advised to unseal their business";
                self::create($assignee->id, 'Business Seal Payment Notice', $body, true);
                // Email/SMS Notice
                self::notify('business_seal_payment', $assignee->email, $assignee->mobile, $assignee->firstname);
            }
        }
    }

    public static function sendExpiryNotices()
    {
        foreach (ArrearsManager::getTodaysExpired() as $item) {
            $obj = (object) $item;
            // System notice
            $body = "Drear $obj->customer, this is to inform you that your payment for $obj->prn period has been expired. KCCA MGT";
            self::create($obj->customer_id, 'Expiry Notice', $body, false);
            // Email/SMS Notice
            self::notify('expiry_notice', $obj->email, $obj->mobile, $obj->customer_name);
        }
    }

    public static function sendReminderNotices()
    {
        foreach (ArrearsManager::getThatWillExpire30() as $item) {
            $obj = (object) $item;
            // System notice
            $body = "Drear $obj->customer, this is to inform you that your payment for $obj->prn period will expire in 30 days. KCCA MGT";
            self::create($obj->customer_id, 'Expiry Notice', $body, false);
            // Email/SMS Notice
            self::notify('reminder_notice', $obj->email, $obj->mobile, $obj->customer_name);
        }
    }

    public static function notifyBusinessSealPrint($business_seal_obj)
    {
        $case_obj = ArrearCase::getItem($business_seal_obj->arrears_case_id);
        $body = "Dear $case_obj->customer, A business seal ($business_seal_obj->seal_number) has been issued and printed for your business.. KCCA MGT";
        self::create($case_obj->customer_id, "Buiness Seal Print Out", $body, false);
        $tags = array("seal_no" => $business_seal_obj->seal_number);
        self::notify("business_seal_print_out", $case_obj->email, $case_obj->mobile, $case_obj->customer, $tags, $tags);
    }

    public static function notify($code, $email, $mobile, $name, $email_tags = [], $sms_tags = [])
    {
        $arrEmailHeaders = array();
        $arrEmailHeaders[]   = "X-KF-uid:1443";
        $arrEmailHeaders[]   = "X-KF-Domain:" . KRequest::getDomainName();
        $arrEmailHeaders[]   = 'X-KF-Component:vendor';

        $email_tags = array_merge(array(
            'name'     => $name,
            'email'    => $email,
            'site_name' => 'KCCA'
        ), $email_tags);

        CmsEmailManager::sendEmail(
            $code,
            array(
                'name' => $name,
                'email' => $email,
                'tags'  => $email_tags
            ),
            $arrEmailHeaders
        );

        $sms_tags = array_merge(array(
            'name'     => $name,
            'mobile'    => $mobile,
            'site_name' => 'KCCA'
        ), $sms_tags);

        CmsSmsManager::sendSms(
            $code = $code,
            $recipients = array($mobile => $mobile),
            $sms_tags,
            $encoding         = 'utf-8',
            $sms_tags         = null,
            $lang             = 'en'
        );
    }

    /** System notification */
    public static function create($user_id, $subject, $body, $delete_on_view)
    {
        KetrouteApplication::instance()->database()->createRecord(
            "arrear_notice",
            array(
                "user_id" => $user_id,
                "subject" => $subject,
                "body" => $body,
                "delete_on_view" => $delete_on_view,
                "created_by" => KSecurity::getUserID()
            ),
            array('created_date' => KetrouteApplication::db()->getNowExpression())
        );
    }
}
