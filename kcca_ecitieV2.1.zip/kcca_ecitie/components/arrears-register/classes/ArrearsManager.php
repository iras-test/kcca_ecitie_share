<?php

class ArrearsManager
{
    public static $BILL = "bill";
    public static $CUSTOMER = "customer";
    public static $REFERENCE = "reference";

    public static function select()
    {
        $bill = self::$BILL;
        return "SELECT MIN($bill.due_date) AS due_date, revenue.name AS revenue_name,
            payment.transaction_status As tranc_status, 
            payment.prn As prn, 
            $bill.customer_id As customer_id,$bill.reference_name AS ref_name,
            $bill.reference_id As ref_id, SUM($bill.amount) As amount,
            ROW_NUMBER() OVER (ORDER BY $bill.customer_id) AS rowNum
        ";
    }

    public static function join()
    {
        $bill = self::$BILL;
        return "
            LEFT JOIN payment AS payment ON payment.id = $bill.payment_id
            LEFT JOIN revenue_type AS revenue ON revenue.id = $bill.revenue_type_id
            LEFT JOIN customer AS customer ON customer.id = $bill.customer_id
        ";
    }

    public static function join_with_ref($ref_name, $due_date = null)
    {
        $bill = self::$BILL;
        $customer_colmn = $ref_name == "markets" ? "market_ownership_id" : "customer_id";
        $due_date = $due_date ? $due_date : date('Y-m-d');
        return
            " INNER JOIN (
                SELECT pb.*, 
                ROW_NUMBER() OVER (PARTITION BY pb.reference_id ORDER BY pb.created_date DESC) as pb_row 
                FROM payment_bill pb WHERE pb.reference_name='$ref_name' AND pb.due_date IS NOT NULL AND pb.due_date < '$due_date'
            ) as payment_bill ON (payment_bill.reference_id=$bill.id AND payment_bill.pb_row = 1 )
            LEFT JOIN customer AS customer ON customer.id = $bill.$customer_colmn 
            LEFT JOIN revenue_type AS revenue ON revenue.id = payment_bill.revenue_type_id 
            LEFT JOIN (
                SELECT a_case.*, 
                ROW_NUMBER() OVER (PARTITION BY a_case.ref_id ORDER BY a_case.id) as arrear_case_row 
                FROM arrear_case a_case WHERE a_case.ref_name='$ref_name' and a_case.closed = 0
            ) as arrear_case ON (arrear_case.ref_id=$bill.id AND arrear_case.arrear_case_row = 1 )";
    }

    public static function select_with_ref($ref_name)
    {
        $bill = self::$BILL;
        $customer_colmn = $ref_name == "markets" ? "market_ownership_id" : "customer_id";

        $common_select = " CASE WHEN payment_bill.reference_name is not null THEN payment_bill.reference_name ELSE '$ref_name' END AS ref_name,
                        payment_bill.due_date AS due_date, 
                        $bill.$customer_colmn As customer_id, 
                        $bill.id As ref_id,
                        revenue.name AS revenue_name, 
                        $bill.modified_date, arrear_case.modified_date AS case_modified_date, arrear_case.status As case_status, arrear_case.assignee As assignee, arrear_case.id as case_id ";

        return $common_select;
    }

    public static function groupBY()
    {
        $bill = self::$BILL;
        return "GROUP BY $bill.customer_id,$bill.reference_name,$bill.reference_id,revenue.name,
                payment.transaction_status";
    }

    public static function getQueryData($join = null, $where = null, $due_date = null)
    {
        $bill = self::$BILL;
        $case_status = ArrearStatus::BUSINESS_ACTIVE;

        $where = " AND $bill.status_id = $case_status " . ($where ? $where : "");

        $SQL = "SELECT DISTINCT $bill.balance, CONVERT(varchar(100),$bill.property_no) As branch_code, " . self::select_with_ref("property") . " FROM property $bill " . self::join_with_ref("property", $due_date) . " WHERE $bill.balance < 0 $where
                UNION ALL 
                SELECT DISTINCT $bill.balance, CONVERT(varchar(100),$bill.number_plate) as branch_code, " . self::select_with_ref("vehicle") . " from vehicle $bill " . self::join_with_ref("vehicle", $due_date) . " WHERE $bill.balance < 0 $where
                UNION ALL
                SELECT DISTINCT $bill.balance, CONVERT(varchar(100),$bill.serial_number) as branch_code, " . self::select_with_ref("trading_license") . " from trading_license $bill " . self::join_with_ref("trading_license", $due_date) . " WHERE $bill.balance < 0 $where
                UNION ALL
                SELECT DISTINCT $bill.balance, CONVERT(varchar(100),$bill.branch_code) as branch_code, " . self::select_with_ref("outdoor") . " from outdoor $bill " . self::join_with_ref("outdoor", $due_date) . " WHERE $bill.balance < 0 $where
                ";
        return $SQL;
    }

    public static function getPayment($paymentId)
    {
        $arrWhere = array('id' => $paymentId);
        return KetrouteApplication::db()->getStaticTableSelection('payment', 'id', 'prn', $where = $arrWhere);
    }

    public static function getRevenueType($revenue_type_id)
    {
        $arrWhere = array('id' => $revenue_type_id);
        return KetrouteApplication::db()->getStaticTableSelection('revenue_type', 'id', 'name', $where = $arrWhere);
    }

    public static function getOutdoorType($outdoor_type_id)
    {
        $arrWhere = array('id' => $outdoor_type_id);
        return KetrouteApplication::db()->getStaticTableSelection('outdoor_type', 'id', 'name', $where = $arrWhere);
    }

    public static function getDivision($division_id)
    {
        return KetrouteApplication::db()->getStaticTableValue('division', 'id', 'name', $division_id);
    }

    public static function getParish($parish_id)
    {
        return KetrouteApplication::db()->getStaticTableValue('parish', 'id', 'name', $parish_id);
    }

    public static function getStreet($street_id)
    {
        return KetrouteApplication::db()->getStaticTableValue('street', 'id', 'name', $street_id);
    }

    public static function getArrearsCasePaymentBill($arrears_id)
    {
        $case_obj = ArrearCase::getArrearCaseByID($arrears_id);
        return array_merge((array)$case_obj, (array)ArrearCase::getItem($arrears_id), self::getItem($case_obj->ref_id, $case_obj->ref_name));
    }


    public static function getAllPaymentBills($ref_name, $ref_id)
    {
        $bill = self::$BILL;
        $cust = self::$CUSTOMER;
        $select =  "SELECT CONCAT($cust.surname, ' ', $cust.firstname) As customer, 
            $bill.due_date, payment.prn, $bill.financial_year,
            $bill.reference_name AS ref_name, $bill.reference_id AS ref_id, $bill.amount AS amount
            FROM payment_bill As $bill
        ";
        $join = self::join();
        $where = "WHERE $bill.reference_name = '$ref_name' AND $bill.reference_id = '$ref_id' AND
            $bill.due_date IS NOT NULL AND $bill.due_date < '" . date('Y-m-d') . "' AND
            ($bill.payment_id IS NULL OR payment.transaction_status IS NULL)
        ";

        $SQL = "$select $join $where";
        return KetrouteApplication::db()->execute($SQL);
    }

    public static function getAllPenalties($ref_name, $ref_id)
    {
        $bill = self::$BILL;
        $cust = self::$CUSTOMER;
        $select =  "SELECT CONCAT($cust.surname, ' ', $cust.firstname) As customer, $bill.financial_year,
            $bill.reference_name AS ref_name, $bill.reference_id AS ref_id, $bill.amount AS amount
            FROM penalty As $bill
        ";
        $where = "WHERE $bill.reference_name = '$ref_name' AND $bill.reference_id = '$ref_id' ";

        $SQL = "$select LEFT JOIN revenue_type AS revenue ON revenue.id = $bill.revenue_type_id
        LEFT JOIN customer AS customer ON customer.id = $bill.customer_id $where";
        return KetrouteApplication::db()->execute($SQL);
    }

    public static function getAllPaymentsMade($ref_name, $ref_id)
    {
        $bill = self::$BILL;
        $cust = self::$CUSTOMER;
        $select =  "SELECT CONCAT($cust.surname, ' ', $cust.firstname) As customer, 
            $bill.due_date, payment.prn as prn, $bill.financial_year, payment.transaction_status, 
            $bill.reference_name AS ref_name, $bill.reference_id AS ref_id, $bill.amount AS amount
            FROM payment_bill As $bill
        ";
        $join = self::join();
        $where = "WHERE $bill.reference_name = '$ref_name' AND $bill.reference_id = '$ref_id' AND $bill.payment_id IS NOT NULL AND payment.prn IS NOT NULL";

        $SQL = "$select $join $where";
        return KetrouteApplication::db()->execute($SQL);
    }


    public static function getPagination($page)
    {
        $length = 10;
        return [(($page - 1) * $length) + 1, $page * $length];
    }

    public static function getSQL($page, $queryParams)
    {
        list($start, $end) = self::getPagination($page);
        $where = self::buildWhere($queryParams);
        $genericSQL = self::getQueryData(null, $where);
        $secondary_where = self::buildSecondaryWhere("", $queryParams, $where = null);
        $SQL = "WITH results AS
            (
                $genericSQL
            ), filtered AS (

                SELECT *,ROW_NUMBER() OVER (ORDER BY case_modified_date DESC) as RowNum FROM results $secondary_where

            ) select * FROM filtered WHERE RowNum BETWEEN $start AND $end
        ";

        return $SQL;
    }

    public static function getList($page, $queryParams)
    {
        return ArrearCase::getList($page, $queryParams);
    }

    public static function count($queryParams)
    {
        return ArrearCase::count($queryParams);
    }

    public static function getItem($ref_id, $ref_name)
    {
        $item_where = " AND payment_bill.reference_name = '$ref_name' AND payment_bill.reference_id = '$ref_id' ";
        $SQL = self::getQueryData(null, $item_where);
        return KetrouteApplication::db()->execute($SQL)->fields;
    }

    public static function getOfficers($role = 16)
    {
        return KetrouteApplication::instance()->database()->getList(
            $table = 'user',
            $where = array(
                'user_role_id' => $role,
                'status_id' => KStatus::ACTIVE
            )
        );
    }

    public static function buildSecondaryWhere($alias, $queryParams, $where = null)
    {

        if (array_key_exists("amount_start", $queryParams)  && $queryParams['amount_start']) {
            $amount_start = (int) $queryParams["amount_start"];
            $where = $where != null ? $where . " AND " : " ";
            // all arrears amounts are in -ve
            $amount_start = -1 * abs($amount_start);
            $where .= $alias . "balance <= '$amount_start' ";
        }

        if (array_key_exists("amount_end", $queryParams)  && $queryParams['amount_end']) {
            $amount_end = (int) $queryParams["amount_end"];
            $where = $where != null ? $where . " AND " : " ";
            // all arrears amounts are in -ve
            $amount_end = -1 * abs($amount_end);
            $where .= $alias . "balance >= '$amount_end' ";
        }

        if (array_key_exists("gen_branch_code", $queryParams)  && $queryParams['gen_branch_code']) {
            $branch_code = $queryParams["gen_branch_code"];
            $where = $where != null ? $where . " AND " : " ";
            $where .= $alias . "branch_code like '%$branch_code%' ";
        }

        if ($where != null && $where != "") {
            $where = " WHERE " . $where;
        }

        return $where;
    }

    public static function buildWhere($queryParams)
    {
        // Create where
        $where = "";
        $bill = self::$BILL;

        if (array_key_exists("customer", $queryParams)  && $queryParams['customer']) {
            $customer = self::$CUSTOMER;
            $cust = $queryParams["customer"];
            $where .= " AND ($customer.firstname like '%$cust%' OR $customer.surname like '%$cust%') ";
        }

        if (array_key_exists("coin", $queryParams)  && $queryParams['coin']) {
            $customer = self::$CUSTOMER;
            $coin = $queryParams["coin"];
            $where .= " AND $customer.coin = '$coin'";
        }

        if (array_key_exists("revenue_type", $queryParams)  && $queryParams['revenue_type']) {
            $revenue_type = $queryParams["revenue_type"];
            $where .= " AND payment_bill.revenue_type_id = $revenue_type";
        }

        if (array_key_exists("assignee", $queryParams)  && $queryParams['assignee']) {
            $assignee = $queryParams["assignee"];
            $where .= " AND arrear_case.assignee = $assignee";
        }

        if (array_key_exists("case_status", $queryParams)  && $queryParams['case_status']) {
            $status = $queryParams["case_status"];
            if ($status == ArrearStatus::OPEN) {
                $where .= " AND (arrear_case.status is null or arrear_case.status = '$status' )";
            } else {
                $where .= " AND arrear_case.status = '$status'";
            }
        }

        /**
         * For transport
         * 
         */
        if (array_key_exists("branch_code", $queryParams)  && $queryParams['branch_code']) {
            $number_plate = $queryParams["branch_code"];
            $where .= " AND bill.number_plate like '%$number_plate%' ";
        }
        if (array_key_exists("tl_branch_code", $queryParams)  && $queryParams['tl_branch_code']) {
            $tl_branch_code = $queryParams["tl_branch_code"];
            $where .= " AND bill.serial_number like '%$tl_branch_code%' ";
        }

        if (array_key_exists("gr_branch_code", $queryParams)  && $queryParams['gr_branch_code']) {
            $gr_branch_code = $queryParams["gr_branch_code"];
            $where .= " AND bill.ground_rent_number like '%$gr_branch_code%' ";
        }

        if (array_key_exists("ou_branch_code", $queryParams)  && $queryParams['ou_branch_code']) {
            $ou_branch_code = $queryParams["ou_branch_code"];
            $where .= " AND bill.branch_code like '%$ou_branch_code%' ";
        }


        if (array_key_exists("vehicle_division", $queryParams)  && $queryParams['vehicle_division']) {
            $vehicle_division = $queryParams["vehicle_division"];
            $where .= " AND bill.division_id = '$vehicle_division' ";
        }
        /** END */

        /**
         * For property
         */
        if (array_key_exists("prop_division", $queryParams)  && $queryParams['prop_division']) {
            $division_id = $queryParams["prop_division"];
            $where .= " AND bill.division_id = '$division_id' ";
        }

        if (array_key_exists("serial_no", $queryParams)  && $queryParams['serial_no']) {
            $serial_no = (int) $queryParams["serial_no"];
            $where .= " AND bill.serial_no = '$serial_no' ";
        }

        if (array_key_exists("age_start", $queryParams)  && $queryParams['age_start']) {
            $age_start = $queryParams["age_start"];
            $where .= " AND payment_bill.due_date >= '$age_start'";
        }

        if (array_key_exists("age_end", $queryParams)  && $queryParams['age_end']) {
            $age_end = $queryParams["age_end"];
            $where .= " AND payment_bill.due_date <= '$age_end'";
        }
        /** END */
        return $where;
    }


    public static function getCustomer($customer_id)
    {
        $SQL = "SELECT * FROM customer WHERE id = '$customer_id'";
        return (object) KetrouteApplication::db()->execute($SQL)->fields;
    }


    public static function getOutstandingBal($ref_name, $ref_id)
    {
        $bill = self::$BILL;
        $select =  "SELECT SUM($bill.amount) AS total FROM payment_bill AS $bill";
        $join = self::join();
        $where = "WHERE $bill.reference_name = '$ref_name' AND $bill.reference_id = $ref_id AND
            $bill.due_date IS NOT NULL AND $bill.due_date <= '" . date('Y-m-d') . "' AND
            ($bill.payment_id IS NULL OR payment.transaction_status IS NULL)
        ";

        $SQL = "$select $join $where";
        return KetrouteApplication::db()->execute($SQL)->fields["total"];
    }

    public static function getRevenueTypes()
    {
        $SQL = "SELECT r.id, r.name FROM revenue_type AS r";
        return KetrouteApplication::db()->execute($SQL);
    }

    public static function getDivisions()
    {
        $SQL = "SELECT id, name FROM division";
        return KetrouteApplication::db()->execute($SQL);
    }

    public static function getParishes()
    {
        $SQL = "SELECT id, name FROM parish";
        return KetrouteApplication::db()->execute($SQL);
    }

    /** Get transport arrears */
    public static function getTransportArrears($page, $queryParams)
    {
        // $bill = self::$BILL;
        // $join = self::join_with_ref("vehicle");

        // list($start, $end) = self::getPagination($page);
        // $where = self::buildWhere($queryParams);
        // $where = self::buildSecondaryWhere("$bill.", $queryParams, "$bill.balance < 0 $where");

        // $genericSQL = "SELECT DISTINCT $bill.division_id AS division_id, $bill.owner_tin AS owner_tin,
        // $bill.balance, CONVERT(varchar(100),$bill.number_plate) as number_plate, " . self::select_with_ref("vehicle") . " from vehicle $bill $join $where";

        // $SQL = "WITH results AS
        //     (
        //         $genericSQL
        //     ), filtered AS (
        //         SELECT *, ROW_NUMBER() OVER (ORDER BY case_modified_date DESC) as RowNum from results
        //     )
        //     SELECT * FROM filtered WHERE RowNum BETWEEN $start AND $end
        // ";
        $queryParams["case_ref_name"] = "vehicle";
        
        return ArrearCase::getList($page, $queryParams);
    }

    /** Get transport arrears */
    public static function transportArrearsCount($queryParams)
    {
        // $bill = self::$BILL;
        // $join = self::join_with_ref("vehicle");

        // $where = self::buildWhere($queryParams);
        // $where = self::buildSecondaryWhere("$bill.", $queryParams, "$bill.balance < 0 $where");
        // $SQL = "SELECT DISTINCT count(*) OVER () AS total FROM vehicle $bill $join $where";
        $queryParams["case_ref_name"] = "vehicle";
        return ArrearCase::count($queryParams);
    }

    /** Get outdoor advertising arrears */
    public static function getOutdoorArrears($page, $queryParams)
    {
        // $bill = self::$BILL;
        // $join = self::join_with_ref("outdoor");

        // list($start, $end) = self::getPagination($page);
        // $where = self::buildWhere($queryParams);
        // $where = self::buildSecondaryWhere("$bill.", $queryParams, "$bill.balance < 0 $where");
        // $genericSQL = "SELECT DISTINCT $bill.division_id AS division_id, $bill.parish_id AS parish_id,
        // $bill.street_id AS street_id, $bill.branch_code AS branch_code, $bill.balance, 
        // $bill.outdoor_type_id AS outdoor_type_id, "
        //     . self::select_with_ref("outdoor") .
        //     " from outdoor
        // $bill $join $where";

        // $SQL = "WITH results AS
        //     (
        //         $genericSQL
        //     ), filtered AS (
        //         SELECT *, ROW_NUMBER() OVER (ORDER BY case_modified_date DESC) as RowNum from results
        //     )
        //     SELECT * FROM filtered WHERE RowNum BETWEEN $start AND $end
        // ";

        // return KetrouteApplication::db()->execute($SQL);
        $queryParams["case_ref_name"] = "outdoor";
        
        return ArrearCase::getList($page, $queryParams);
    }

    /** Get outdoor advertising arrears */
    public static function outdoorArrearsCount($queryParams)
    {
        // $bill = self::$BILL;
        // $join = self::join_with_ref("outdoor");

        // $where = self::buildWhere($queryParams);
        // $where = self::buildSecondaryWhere("$bill.", $queryParams, "$bill.balance < 0 $where");
        // $SQL = "SELECT DISTINCT count(*) OVER () AS total FROM outdoor $bill $join $where";

        // return KetrouteApplication::db()->execute($SQL)->fields["total"];
        $queryParams["case_ref_name"] = "outdoor";
        return ArrearCase::count($queryParams);
    }

    /** Get property arrears */
    public static function getPropertyArrears($page, $queryParams)
    {
        // $bill = self::$BILL;
        // $join = self::join_with_ref("property");

        // list($start, $end) = self::getPagination($page);
        // $where = self::buildWhere($queryParams);
        // $where = self::buildSecondaryWhere("$bill.", $queryParams, "$bill.balance < 0 $where");
        // $genericSQL = "SELECT DISTINCT $bill.division_id AS division_id, $bill.parish_id AS parish_id, $bill.balance,
        // $bill.street_id AS street_id, $bill.serial_no AS serial_no,"
        //     . self::select_with_ref("property") .
        //     " from property
        // $bill $join $where";

        // $SQL = "WITH results AS
        //     (
        //         $genericSQL
        //     ), filtered AS (
        //         SELECT *, ROW_NUMBER() OVER (ORDER BY case_modified_date DESC) as RowNum from results
        //     )
        //     SELECT * FROM filtered WHERE RowNum BETWEEN $start AND $end
        // ";

        // return KetrouteApplication::db()->execute($SQL);

        $queryParams["case_ref_name"] = "property";
        
        return ArrearCase::getList($page, $queryParams);
    }

    /** Get property arrears */
    public static function propertyArrearsCount($queryParams)
    {
        // $bill = self::$BILL;
        // $join = self::join_with_ref("property");

        // $where = self::buildWhere($queryParams);
        // $where = self::buildSecondaryWhere("$bill.", $queryParams, "$bill.balance < 0 $where");
        // $SQL = "SELECT DISTINCT count(*) OVER () AS total FROM property $bill $join $where";

        // return KetrouteApplication::db()->execute($SQL)->fields["total"];

        $queryParams["case_ref_name"] = "property";
        return ArrearCase::count($queryParams);
    }

    /** Get markets arrears */
    public static function getMarketArrears($page, $queryParams)
    {
        // $bill = self::$BILL;
        // $join = self::join_with_ref("markets");

        // list($start, $end) = self::getPagination($page);
        // $where = self::buildWhere($queryParams);
        // $where = self::buildSecondaryWhere("$bill.", $queryParams, $where);
        // $genericSQL = "SELECT DISTINCT 
        // $bill.market_division_id AS division_id, $bill.market_code AS market_code, $bill.name AS name, "
        //     . self::select_with_ref("markets") . " from markets $bill $join $where";

        // $SQL = "WITH results AS
        //     (
        //         $genericSQL
        //     ), filtered AS (
        //         SELECT *, ROW_NUMBER() OVER (ORDER BY case_modified_date DESC) as RowNum from results
        //     )
        //     SELECT * FROM filtered WHERE RowNum BETWEEN $start AND $end
        // ";

        // return KetrouteApplication::db()->execute($SQL);
        $queryParams["case_ref_name"] = "markets";
        
        return ArrearCase::getList($page, $queryParams);
    }

    /** Get markets arrears */
    public static function marketArrearsCount($queryParams)
    {
        // $bill = self::$BILL;
        // $join = self::join_with_ref("markets");

        // $where = self::buildWhere($queryParams);
        // $where = self::buildSecondaryWhere("$bill.", $queryParams, $where);
        // $SQL = "SELECT DISTINCT count(*) OVER () AS total FROM markets $bill $join $where";

        // return KetrouteApplication::db()->execute($SQL)->fields["total"];
        $queryParams["case_ref_name"] = "markets";
        return ArrearCase::count($queryParams);
    }

    /** Get groundrent arrears */
    public static function getGroundArrears($page, $queryParams)
    {
        // $bill = self::$BILL;
        // $join = self::join_with_ref("groundrent");

        // list($start, $end) = self::getPagination($page);
        // $where = self::buildWhere($queryParams);

        // $genericSQL = "SELECT DISTINCT $bill.division_id AS division_id, $bill.main_debt As balance, 
        // $bill.parish_id AS parish_id, $bill.street_id AS street_id,"
        //     . self::select_with_ref("groundrent") .
        //     " from groundrent
        // $bill $join WHERE $bill.main_debt < 0 $where";

        // $SQL = "WITH results AS
        //     (
        //         $genericSQL
        //     ), filtered AS (
        //         SELECT *, ROW_NUMBER() OVER (ORDER BY case_modified_date DESC) as RowNum from results
        //     )
        //     SELECT * FROM filtered WHERE RowNum BETWEEN $start AND $end
        // ";

        // return KetrouteApplication::db()->execute($SQL);
        $queryParams["case_ref_name"] = "groundrent";
        
        return ArrearCase::getList($page, $queryParams);
    }

    /** Get groundrent arrears */
    public static function groundArrearsCount($queryParams)
    {
        // $bill = self::$BILL;
        // $join = self::join_with_ref("groundrent");

        // $where = self::buildWhere($queryParams);

        // $SQL = "SELECT DISTINCT count(*) OVER () AS total FROM groundrent $bill $join WHERE $bill.main_debt < 0 $where";

        // return KetrouteApplication::db()->execute($SQL)->fields["total"];
        $queryParams["case_ref_name"] = "groundrent";
        return ArrearCase::count($queryParams);
    }

    /** Get trade license arrears */
    public static function getTradeArrears($page, $queryParams)
    {

        $queryParams["case_ref_name"] = "trading_license";
        
        return ArrearCase::getList($page, $queryParams);
    }

    /** Get trade license arrears */
    public static function tradeArrearsCount($queryParams)
    {
        $queryParams["case_ref_name"] = "trading_license";
        return ArrearCase::count($queryParams);
    }

    public static function generalExport($page = null, $queryParams = null)
    {
        $bill = self::$BILL;
        $cust = self::$CUSTOMER;
        $where = self::buildWhere($queryParams);
        $extra_columns = $page ? ", ROW_NUMBER() OVER (ORDER BY $bill.customer_id) AS rowNum" : "";

        $SQL = "SELECT MIN($bill.due_date) AS due_date,
            MIN(CONCAT($cust.surname, ' ', $cust.firstname)) As customer,
            MIN($cust.coin) AS coin,
            revenue.name AS revenue_name, 
            SUM($bill.amount) As amount
            $extra_columns
            FROM payment_bill AS $bill
            LEFT JOIN payment AS payment ON payment.id = $bill.payment_id
            LEFT JOIN revenue_type AS revenue ON revenue.id = $bill.revenue_type_id
            LEFT JOIN customer AS customer ON customer.id = $bill.customer_id
            WHERE  $bill.due_date IS NOT NULL 
            AND $bill.due_date < '" . date('Y-m-d') . "' AND
            ($bill.payment_id IS NULL OR payment.transaction_status IS NULL)
            $where
            GROUP BY $bill.customer_id,$bill.reference_name,$bill.reference_id,revenue.name,
            payment.transaction_status
        ";

        if ($page) {
            list($start, $end) = self::getPagination($page);
            $where = self::buildWhere($queryParams);
            $SQL = "WITH results AS
                (
                    $SQL
                )
                SELECT * FROM results  WHERE RowNum BETWEEN $start AND $end ORDER BY due_date DESC
            ";
        }
        return KetrouteApplication::db()->execute($SQL);
    }

    public static function transportExport($page = null, $queryParams = null)
    {
        $bill = self::$BILL;
        $cust = self::$CUSTOMER;
        $where = self::buildWhere($queryParams);
        $extra_columns = $page ? ", ROW_NUMBER() OVER (ORDER BY $bill.customer_id) AS rowNum" : "";

        $SQL = "SELECT MIN($bill.due_date) AS due_date,
            (SELECT name FROM division WHERE id = MIN(vehicle.division_id)) AS div,
            MIN(CONCAT($cust.surname, ' ', $cust.firstname)) As customer,
            MIN($cust.coin) AS coin,
            MIN(vehicle.owner_tin) AS owner_tin,
            SUM($bill.amount) As amount
            $extra_columns
            FROM payment_bill AS $bill
            LEFT JOIN payment AS payment ON payment.id = $bill.payment_id
            LEFT JOIN revenue_type AS revenue ON revenue.id = $bill.revenue_type_id
            LEFT JOIN customer AS customer ON customer.id = $bill.customer_id
            LEFT JOIN vehicle AS vehicle ON vehicle.id = $bill.reference_id
            WHERE  $bill.due_date IS NOT NULL 
            AND $bill.due_date < '" . date('Y-m-d') . "' AND
            ($bill.payment_id IS NULL OR payment.transaction_status IS NULL) AND $bill.reference_name = 'vehicle'
            $where
            GROUP BY $bill.customer_id,$bill.reference_name,$bill.reference_id,revenue.name,
            payment.transaction_status
        ";

        if ($page) {
            list($start, $end) = self::getPagination($page);
            $where = self::buildWhere($queryParams);
            $SQL = "WITH results AS
                (
                    $SQL
                )
                SELECT * FROM results  WHERE RowNum BETWEEN $start AND $end ORDER BY due_date DESC
            ";
        }
        return KetrouteApplication::db()->execute($SQL);
    }

    public static function outdoorExport($page = null, $queryParams = null)
    {
        return [];
    }

    public static function propertyExport($page = null, $queryParams = null)
    {
        $bill = self::$BILL;
        $cust = self::$CUSTOMER;
        $where = self::buildWhere($queryParams);
        $extra_columns = $page ? ", ROW_NUMBER() OVER (ORDER BY $bill.customer_id) AS rowNum" : "";

        $SQL = "SELECT MIN($bill.due_date) AS due_date,
            MIN(CONCAT($cust.surname, ' ', $cust.firstname)) As customer,
            MIN($cust.coin) AS coin,
            (SELECT name FROM division WHERE id = MIN(property.division_id)) AS division,
            (SELECT name FROM parish WHERE id = MIN(property.parish_id)) AS parish,
            MIN(property.street_id) AS street,
            MIN(property.serial_no) AS serial_no,
            SUM($bill.amount) As amount
            $extra_columns
            FROM payment_bill AS $bill
            LEFT JOIN payment AS payment ON payment.id = $bill.payment_id
            LEFT JOIN revenue_type AS revenue ON revenue.id = $bill.revenue_type_id
            LEFT JOIN customer AS customer ON customer.id = $bill.customer_id
            LEFT JOIN property AS property ON property.id = $bill.reference_id
            WHERE  $bill.due_date IS NOT NULL 
            AND $bill.due_date < '" . date('Y-m-d') . "' AND
            ($bill.payment_id IS NULL OR payment.transaction_status IS NULL) AND $bill.reference_name = 'property'
            $where
            GROUP BY $bill.customer_id,$bill.reference_name,$bill.reference_id,revenue.name,
            payment.transaction_status
        ";

        if ($page) {
            list($start, $end) = self::getPagination($page);
            // $where = self::buildWhere($queryParams);
            $SQL = "WITH results AS
                (
                    $SQL
                )
                SELECT * FROM results  WHERE RowNum BETWEEN $start AND $end ORDER BY due_date DESC
            ";
        }

        $results = null;
        $resultsarr = KetrouteApplication::db()->execute($SQL);

        if (isset($resultsarr->fields) && $resultsarr->fields) {

            while (!$resultsarr->EOF) {
                $res = (object) $resultsarr->fields;
                $results[] = array(
                    'due_date' => $res->due_date, 'customer' => $res->customer,
                    'coin' => $res->coin, 'division' => $res->division,
                    'parish' => $res->parish, 'street' => $res->street,
                    'serial_no' => $res->serial_no, 'amount' => number_format($res->amount),
                );
                $resultsarr->MoveNext();
            }
        }
        return $results;
    }

    public static function getByDueDate($date)
    {
        print_r("Date: $date\n");
        $SQL = self::getQueryData(null, null, $date);
        return KetrouteApplication::db()->execute($SQL);
    }

    /** Get payment bills that expired today */
    public static function getTodaysExpired()
    {
        return self::getByDueDate(date('Y-m-d'));
    }

    public static function getExpiredYesterday()
    {
        return self::getByDueDate(date('Y-m-d', strtotime("-1 days")));
    }

    /** Get payment bills that will expire 30 days from today */
    public static function getThatWillExpire30()
    {
        $date = new DateTime();
        $thirtyDaysFromNow = $date->modify('-30 day')->format('Y-m-d');
        return self::getByDueDate($thirtyDaysFromNow);
    }

    public static function getUser($id)
    {
        $SQL = "SELECT email, mobile, firstname, surname FROM [user] WHERE id = '$id'";
        return KetrouteApplication::db()->execute($SQL)->fields;
    }

    public static function getBusinessDetails($ref_name, $ref_id)
    {

        $fields = " * ";
        $join = "";
        $result = [];

        if ($ref_name && $ref_id) {
            if ($ref_name == "vehicle") {
                $fields .= ",ref.number_plate AS branch_code, 
                ref.division_id as division_id, balance,
                ref.owner_tin,
                (SELECT name FROM division d WHERE d.id = ref.division_id) AS location, 
                park.name as park_name, 
                stage.name as stage_name";
                $join = " LEFT JOIN park AS park on park.id = ref.park_id LEFT JOIN stage AS stage on stage.id = ref.stage_id";
            }

            if ($ref_name == "trading_license") {
                $fields .= ",ref.code AS branch_code, balance,
                ref.division as division_id,
                ref.parish as parish_id, 
                ref.village as village_id, 
                ref.street_id as street_id,
                CONCAT(
                    (SELECT name FROM division d WHERE d.id = ref.division),
                    ' / ', 
                    (SELECT name FROM parish p WHERE p.id = ref.parish),
                    ' / ', 
                    (SELECT name FROM village v WHERE v.id = ref.village),
                    ' / ', 
                    (SELECT name FROM street s WHERE s.id = ref.street)
                    ) AS location ";
            }

            if ($ref_name == "groundrent") {
                $fields .= ",ref.ground_rent_number AS branch_code, main_debt as balance,
                ref.division_id as division_id,
                ref.parish_id as parish_id,
                ref.village_id as village_id, 
                (SELECT name FROM street s WHERE s.id = ref.street_id) as street_id,
                CONCAT(
                    (SELECT name FROM division d WHERE d.id = ref.division_id),
                    ' / ', 
                    (SELECT name FROM parish p WHERE p.id = ref.parish_id),
                    ' / ', 
                    (SELECT name FROM village v WHERE v.id = ref.village_id),
                    ' / ', 
                    (SELECT name FROM street s WHERE s.id = ref.street_id)
                    ) AS location ";
            }

            if ($ref_name == "markets") {
                $fields .= ",ref.market_code AS branch_code,
                ref.market_division_id as division_id,
                (SELECT name FROM division d WHERE d.id = ref.market_division_id) AS location ";
            }

            if ($ref_name == "outdoor") {

                $fields .= ",ref.branch_code AS branch_code,
                ref.division_id as division_id,balance,
                ref.parish_id as parish_id,
                ref.village_id as village_id,
                ref.outdoor_type_id as outdoor_type_id, 
                (SELECT name FROM street s WHERE s.id = ref.street_id) as street_id,
                CONCAT(
                    (SELECT name FROM division d WHERE d.id = ref.division_id),
                    ' / ', 
                    (SELECT name FROM parish p WHERE p.id = ref.parish_id),
                    ' / ', 
                    (SELECT name FROM village v WHERE v.id = ref.village_id),
                    ' / ', 
                    (SELECT name FROM street s WHERE s.id = ref.street_id)
                    ) AS location ";
            }

            if ($ref_name == "property") {

                $fields .= ",ref.property_no AS branch_code,
                ref.division_id as division_id,balance,
                ref.parish_id as parish_id,
                ref.village_id as village_id, 
                ref.street_id as street_id,
                CONCAT(
                    (SELECT name FROM division d WHERE d.id = ref.division_id),
                    ' / ', 
                    (SELECT name FROM parish p WHERE p.id = ref.parish_id),
                    ' / ', 
                    (SELECT name FROM village v WHERE v.id = ref.village_id),
                    ' / ', 
                    ref.street_id
                    ) AS location ";
            }

            $SQL = "SELECT TOP 1 $fields FROM $ref_name ref $join WHERE ref.id = '$ref_id'";
            $result = KetrouteApplication::db()->execute($SQL)->fields;
        }
        $obj = (object)$result;
        return $obj;
    }

    public static function updateBusinessArrearStatus($ref_name, $ref_id, $status)
    {
        $instance = KetrouteApplication::instance();
        $instance->database()->updateRecord($ref_name, array('status_id' => $status), array('id' => $ref_id));
    }
}
