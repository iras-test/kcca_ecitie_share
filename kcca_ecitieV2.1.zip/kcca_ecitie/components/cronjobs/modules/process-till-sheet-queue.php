<?php
/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');


set_time_limit(0);

echo "\n--begin--: ".__FILE__;
try{
	
	// check for index 5 = sms queueing file
	if(isset ($GLOBALS['argv'][5])){
		
		// the file with queue items
		$strQueueFile = $GLOBALS['argv'][5];
		
		// application instance	
		$application = KetrouteApplication::instance();
		
		// check file exists
		if(KFile::exists($strQueueFile) && KFile::isExtension($strQueueFile, 'pts') && KFile::size($strQueueFile)){
			
			// get items in file
			$strData = KFile::getContent($strQueueFile);
				
			
			// load payment end of day object
			$objPaymentEOD = $application->database()->load($table = 'payment_eod', $where = array('id' => $strData,'status_id' => KStatus::PENDING));
			
			// get file name
			$file_name = KFW_PAYMENT_PATH.$objPaymentEOD->token.'.'.PaymentManager::PAYMENT_RECONCILIATION_FILE_EXT_TILL_SHEET;
					
			// check file exists
			if(KFile::exists($file_name) && KFile::isExtension($file_name, PaymentManager::PAYMENT_RECONCILIATION_FILE_EXT_TILL_SHEET) && KFile::size($file_name)){
				
				// get till sheet file content
				$strContent = KFile::getContent($file_name);
				
				// decrypt till sheet file			
				$strDecrypted = KSecurity::aesRead($strContent, PaymentManager::generateTillSheetSecurityKey($objPaymentEOD), $objPaymentEOD->token);	
				
				//process till sheet file
				PaymentManager::processTillsheet($objPaymentEOD, $strDecrypted);
				
				//delete queue file
				KFile::deleteFile($strQueueFile);
			}
			else{
				// ignore proocess
				throw new Exception('Invalid till-sheet stored: '.print_r($file_name, true));
			}
		}
		else{
			// ignore proocess
			throw new Exception('Invalid till-sheet queue: '.print_r($strQueueFile, true));
		}

	}
}
catch(Exception $e){
	// do notiing with errors
	$this->captureErrorLog(null,ErrorLogManager::ERROR_TYPE_EXCEPTION,'Failed to run: till-sheet / process filebased queue',print_r($e->getMessage(), true));
}
echo "\n--end--";
	