<?php

$info = null;
$error = null;

$queryParams = KRequest::getQueryStrings();
$ref_name = $queryParams["ref_name"];
$ref_id = $queryParams["ref_id"];
$records = "";

if(array_key_exists("ref_name", $queryParams) && array_key_exists("ref_id", $queryParams)) {
    $info  = (object) ArrearsManager::getItem($ref_id, $ref_name);
}

$bills = ArrearsManager::getAllPaymentBills($info->ref_name, $info->ref_id);

$info_display = null;
if($info) {
    $cust = ArrearsManager::getCustomer($info->customer_id);

    $info_display = "
        <div class=\"clear customer-blocks pb10\">
            <h1 class=\"kfw-active-title\"><strong>[lang-arrears-case-details]<strong></h1>
            <div class=\"clear pt10\">
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Customer</span></strong>: {$cust->surname} {$cust->firstname} 
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">COIN</span></strong>: {$cust->coin}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Revenue Type</span></strong>: {$info->revenue_name}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Outstanding balance</span></strong>: {$info->amount}
                </div>
            </div>
        </div>
    ";
}

/** Bill breakdowns */
if(count($bills) > 0) {
    // show record	
    foreach ($bills as $index => $arrData){              
        $class = ($index % 2 == 0) ? ' odd' : ' even';
        $obj = (object) $arrData;
        $record_number = $index + 1;
        $prn = $obj->prn? $obj->prn: "N/A";

        $records .= "<div class=\"clear list-item{$class}\">";	
        $records .= "\n\t\t\t<div class=\"fl numbering-col\">{$record_number}</div>";		
        $records .= "\n\t\t\t<div class=\"fl col20\">{$obj->financial_year}</div>";
        $records .= "\n\t\t\t<div class=\"fl col20\">{$prn}</div>";
        $records .= "\n\t\t\t<div class=\"fl col20\">{$obj->due_date}</div>";
        $records .= "\n\t\t\t<div class=\"fl col20\">{$obj->amount}</div>";
        $records .= "\n\t\t</div>";

    }

} else {
    $records  = "\n\t\t<div class=\"clear list-item\">".KLanguage::getWord('arrears-case-items')."</div>";
}


$arrear["options"] = $options;
$arrear["bills"] = $records;
$arrear["info_display"] = $info_display;
$arrear["error"] = $error;
$arrear["close_url"] = "action={$this->urlPath(0)}close-case?id={$bill_id}";

$this->render($arrear);
