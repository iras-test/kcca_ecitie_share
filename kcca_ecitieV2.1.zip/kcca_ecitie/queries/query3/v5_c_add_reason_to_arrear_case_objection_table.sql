
use ecitie;

ALTER TABLE [dbo].[arrears_case_objection] ADD [reason] [nvarchar](40) NULL