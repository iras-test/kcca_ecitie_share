use ecitie;

ALTER TABLE [dbo].[arrear_case_assignment] ADD [reason] [nvarchar](1000) NULL