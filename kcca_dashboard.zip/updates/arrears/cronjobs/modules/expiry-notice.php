
<?php

(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
set_time_limit(0);
/** Send out expiry notices to city operators whose payment plan has expired */
NotificationManager::sendExpiryNotices();
