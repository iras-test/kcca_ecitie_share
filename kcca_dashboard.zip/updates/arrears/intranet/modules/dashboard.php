<?php

/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

list($start_date, $end_date) = ArrearCase::getDates();
$queryParams = array("start_date" => $start_date, "end_date" => $end_date);

$cases_today = ArrearCase::count($queryParams);
$cases_all_time = ArrearCase::count($queryParams);

$arrears_today = ArrearCase::totalAmountInArrears($queryParams);
$arrears_all_time = ArrearCase::totalAmountInArrears($queryParams);

$collected_today = ArrearCase::totalCollected($queryParams);
$collected_all_time = ArrearCase::totalCollected($queryParams);

$total_cases = 0;
$total_arrears = 0;
$total_collected = 0;

$tableData = ArrearCase::tabularStats($queryParams);
$table_rows = "";
foreach ($tableData as $item) {
    $label = $item["label"];
    $cases = $item["cases"];
    $total_cases += $cases;

    $arrears = number_format($item["arrears"]);
    $total_arrears += $item["arrears"];

    $collected = number_format($item["collected"]);
    $total_collected += $item["collected"];

    $table_rows .= "
    <tr>
        <td>$label</td>
        <td>$cases</td>
        <td>$arrears</td>
        <td>$collected</td>
    </tr>
    ";
}

$total_arrears = number_format($total_arrears);
$total_collected = number_format($total_collected);

$table_total = "
    <tr>
        <th>Total</th>
        <th>$total_cases</th>
        <th>$total_arrears</th>
        <th>$total_collected</th>
    </t>
";

$this->render(array(
    "cases_today" => $cases_today,
    "cases_all_time" => $cases_all_time,
    "arrears_today" => number_format($arrears_today),
    "arrears_all_time" => number_format($arrears_all_time),
    "collected_today" => number_format($collected_today),
    "collected_all_time" => number_format($collected_all_time),
    "table_rows" => $table_rows,
    "table_total" => $table_total
));