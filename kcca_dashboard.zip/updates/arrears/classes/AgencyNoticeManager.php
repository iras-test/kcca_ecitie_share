<?php

class AgencyNoticeManager
{

    const APPROVE = "approve";
    const OBJECT_NOTICE = "object";
    const CLOSE = "close";
    const REJECT = "reject";

    const STATUS_APPROVE = 2;
    const STATUS_OBJECT = 3;
    const STATUS_CLOSE = 0;
    const STATUS_REJECT = 4;

    public static function agency_notice_approval_action($an_id, $approval_action, $case_status, $reason = null, $comment = null)
    {
        $action_by = KSecurity::getUserID();

        $action_on = date('Y-m-d');

        $bindings_extra = [];

        $SQL = "UPDATE arrears_agency_notice SET agency_notice_status = :approval_action:, 
                modified_by = :action_by:, modified_date = :action_on: ";
        if ($reason != null) {
            $SQL .= ", reason = :reason: ";
            $bindings_extra[':reason:'] = $reason;
        }

        if ($comment != null) {
            $SQL .= ", comment = :comment: ";
            $bindings_extra[':comment:'] = $comment;
        }

        $SQL .= "WHERE id = :an_id:";

        $bindings_extra[':approval_action:'] = $approval_action;
        $bindings_extra[':action_by:'] = $action_by;
        $bindings_extra[':an_id:'] = $an_id;
        $bindings_extra[':action_on:'] = $action_on;


        KetrouteApplication::db()->execute($SQL, $bindings_extra);

        KetrouteApplication::instance()->logAuditTrail("Changed agency notice status to #$approval_action", 'arrears_agency_notice', $an_id);

        // update case
        if ($case_status) {

            $case_id = self::getCaseAgencyNoticeActionByID($an_id)->arrears_case_id;
            ArrearCase::updateStatus($case_id, $case_status);
        }
    }

    public static function getCaseAgencyNoticeActionByID($agency_notice_id)
    {
        $SQL = "SELECT * FROM arrears_agency_notice WHERE id = :agency_notice_id:";
        $bindings_extra[':agency_notice_id:'] = $agency_notice_id;

        $results = null;
        $resultsarr = KetrouteApplication::db()->execute($SQL, $bindings_extra);

        if (isset($resultsarr->fields) && $resultsarr->fields) {

            while (!$resultsarr->EOF) {

                $results = (object)$resultsarr->fields;
                $resultsarr->MoveNext();
            }
        }
        return $results;
    }
}
