
use ecitie;

update [dbo].[component]  set permissions = 'list,transport,outdoor,property,ground_rent,trade_license,market_rent', module_permission_map = 'list:list' where title = 'arrears-register'