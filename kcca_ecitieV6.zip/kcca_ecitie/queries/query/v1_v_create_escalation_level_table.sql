use ecitie;

CREATE TABLE [dbo].[escalation_levels](
	[id] [int] IDENTITY(1,1) NOT NULL,
    [role_id] [int] NOT NULL,
    [level] [int] NOT NULL,
	[name] [nvarchar](1000) NOT NULL,
	[level_status] [int] DEFAULT 1,
	[created_by] [int] NULL,
	[created_date] [datetime2](0) NULL,
	[modified_by] [int] NULL,
	[modified_date] [datetime2](0) NULL,
)
GO