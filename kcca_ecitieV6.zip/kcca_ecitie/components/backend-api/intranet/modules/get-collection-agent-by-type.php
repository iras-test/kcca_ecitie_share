<?php

(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

header("Content-type: application/json");
$type_id = KRequest::getQueryString("type", null);

echo json_encode(["vendors"=>VendorManager::getSelectionActiveByType($type_id)]);

exit;