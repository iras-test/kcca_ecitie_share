<?php
/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin
		
// get max per page
$MAX_PER_PAGE 	= $this->registry()->get(strtoupper($this->getComponentRealname()).'_MAX_PER_PAGE', $this->registry()->get('MAX_PER_PAGE',10));
// page number
$_page		 	= $this->getParam('page', KRequest::getQueryString("page", 1));
$strComponentRealname	= $this->getComponentRealname();
$user_id		= KSecurity::getUserID();
$intIgnoreID 	= $this->runtime()->getIgnoredID();
$strParentUrl	= $this->urlPath(0);
$strMessage = '';
$records = '';		
$list_counter	= 0;
$filters = "";

$queryParams = KRequest::getQueryStrings();
$result_list['count'] = PaymnentPlanManager::count($queryParams);
$data = PaymnentPlanManager::getList($_page,$queryParams);

// set active item with its configurations	
$this->runtime()->setActivePage($_page);
$this->runtime()->setActiveMaxPerPage($MAX_PER_PAGE);

if($result_list['count'] > 0) {
    // show record	
    foreach ($data as $index => $arrData){      
        $strPrimaryKey = $this->runtime()->getPrimaryKey();
        
        $class = ($index % 2 == 0) ? ' odd' : ' even';
        
        if($_page > 1)
        {
            $record_number = ($index+1)+($MAX_PER_PAGE*($_page-1));
        }
        else
        {
            $record_number = ($index+1);
        }
        
        $list_counter++;
        $objmoduleConfig = (object)$arrData;

        // Case status
        $status = $objmoduleConfig->approval_status == 1
            ? "<div class=\"fl arrears-col arr-text-green\">Approved</div>"
            : "<div class=\"fl arrears-col arr-text-orange\">Pending</div>";

        $created_on = date('d,M,Y',strtotime($objmoduleConfig->created_date));

        $records .= "<div class=\"clear list-item{$class}\">";			
        $records .= "\n\t\t\t<div class=\"fl numbering-col\">{$record_number}</div>";
        $records .= "\n\t\t\t<div class=\"fl arrears-col\">{$this->runtime()->getFieldData('customer_id', $arrData)}</div>";
        $records .= "\n\t\t\t<div class=\"fl arrears-col\">{$objmoduleConfig->branch_code}</div>";
        $records .= "\n\t\t\t<div class=\"fl arrears-col\">{$objmoduleConfig->creation_reason}</div>";
        $records .= "\n\t\t\t<div class=\"fl arrears-col\">{$created_on}</div>";
        $records .= "\n\t\t\t{$status}";
        $records .= "\n\t\t\t<div class=\"fl arrears-col\"><a href=\"[link_in_use]arrears/view-payment-plan?id={$objmoduleConfig->id}\">View Plan Details</a></div>";
        $records .= "\n\t\t</div>";
    }

    $pager = new KPager();		
    $pager->setTotalRecords($result_list['count']);
    $pager->setRecordsPerPage($MAX_PER_PAGE);
    $pager->setCurrentPage($_page);

    $url = $this->urlPath(1, 1, 1, 1);
	if (count($queryParams)>0) {
		$ex_url = explode("page=",$url);
		$url = $ex_url[0];
		if (count($ex_url)==1) {
			$url .= "&";
		}
	}else {

		$url .= "?";
	
	}
	$pager->setURL($url."page=");
    $pager_html = $pager->getPager();
    $pager_info = $pager->getPagerInfo("[lang-{$strComponentRealname}-payment-plan-list]");

} else {
    $records  = "\n\t\t<div class=\"clear list-item\">".KLanguage::getWord('arrears-payment-plan-list-no')."</div>";
}

$branch_code_filter = Util::filterInput("text", "BRANCH-CODE", "branch_code", $queryParams["branch_code"]);
$customer_filter = Util::filterInput("text", "Customer", "customer", $queryParams["customer"]);
$coin_filter = Util::filterInput("text", "COIN", "coin", $queryParams["coin"]);
$submission_start_filter = Util::filterInput("date", "Submission Start", "submission_start", $queryParams["submission_start"]);
$submission_end_filter = Util::filterInput("date", "Submission End", "submission_end", $queryParams["submission_end"]);
$filters = "$branch_code_filter
            $customer_filter
            $coin_filter 
            $submission_start_filter 
            $submission_end_filter";

$this->render(array(
    'records' => $records,
    'pager_html' 	=> $pager_html,
    'pager_info' 	=> $pager_info,
    'message' 		=> $strMessage,
    'list_counter' 	=> $list_counter,
    'tabs' 			=> KNavigationTab::getHTMLTabs(),
    'base_url'		=> $this->urlPath(1,1,0,0),
    'filters'		=> Util::formContainer("arrears", $this->urlPath(1, 1, 1, 1), $filters)
));
