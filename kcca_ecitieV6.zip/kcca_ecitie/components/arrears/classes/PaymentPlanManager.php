<?php

/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

class PaymnentPlanManager
{

    const APPROVE_ACTION = "approve";
    const OBJECT_ACTION = "object";
    const CLOSE = "close";

    public static function getQueryData($queryParams)
    {

        $where = self::buildWhere($queryParams, null);

        return "SELECT DISTINCT ac.customer_id AS customer_id, pp.id AS id, pp.creation_reason AS creation_reason, 
                pp.approval_status AS approval_status, pp.created_date AS created_date, ac.branch_code as branch_code, 
                ROW_NUMBER() OVER (ORDER BY pp.id) AS rowNum FROM arrears_payment_plan AS pp 
                INNER JOIN arrear_case AS ac ON ac.id = pp.arrears_case_id
                LEFT JOIN customer AS customer ON customer.id = ac.customer_id 
                $where";
    }


    public static function getList($page, $queryParams)
    {
        list($start, $end) = ArrearsManager::getPagination($page);
        $genericSQL = self::getQueryData($queryParams);
        $SQL = "WITH results AS
            (
                $genericSQL
            )
            SELECT * FROM results WHERE rowNum BETWEEN $start AND $end
        ";

        return KetrouteApplication::db()->execute($SQL);
    }

    public static function buildWhere($queryParams, $where = null)
    {

        if (array_key_exists("submission_start", $queryParams)  && $queryParams['submission_start']) {
            $submission_start = $queryParams["submission_start"];
            $where = $where != null ? $where . " AND " : " ";
            $where .= "pp.created_date >= '$submission_start 00:00:00' ";
        }

        if (array_key_exists("submission_end", $queryParams)  && $queryParams['submission_end']) {
            $submission_end = $queryParams["submission_end"];
            $where = $where != null ? $where . " AND " : " ";
            $where .= "pp.created_date <= '$submission_end 23:59:59' ";
        }

        if (array_key_exists("branch_code", $queryParams)  && $queryParams['branch_code']) {
            $branch_code = $queryParams["branch_code"];
            $where = $where != null ? $where . " AND " : " ";
            $where .= "ac.branch_code like '%$branch_code%' ";
        }

        if (array_key_exists("customer", $queryParams)  && $queryParams['customer']) {
            $customer = "customer";
            $cust = $queryParams["customer"];
            $where = $where != null ? $where . " AND " : " ";
            $where .= " ($customer.firstname like '%$cust%' OR $customer.surname like '%$cust%') ";
        }

        if (array_key_exists("coin", $queryParams)  && $queryParams['coin']) {
            $customer = "customer";
            $coin = $queryParams["coin"];
            $where = $where != null ? $where . " AND " : " ";
            $where .= " $customer.coin like '%$coin%'";
        }


        if ($where != null && $where != "") {
            $where = " WHERE " . $where;
        }

        return $where;
    }

    public static function getCasePaymentPlan($case_id, $active = false)
    {
        $SQL = "SELECT * FROM arrears_payment_plan WHERE arrears_case_id = :case_id:";
        if ($active) {
            $SQL .= " AND approval_status in ('0','1','2')";
        }
        $bindings_extra[':case_id:'] = $case_id;

        $results = null;

        $resultsarr = KetrouteApplication::db()->execute($SQL, $bindings_extra);

        if (isset($resultsarr->fields) && $resultsarr->fields) {

            while (!$resultsarr->EOF) {

                $results = (object)$resultsarr->fields;
                $resultsarr->MoveNext();
            }
        }
        return $results;
    }

    public static function getPaymentPlanByID($payment_plan_id)
    {
        $SQL = "SELECT * FROM arrears_payment_plan WHERE id = :payment_plan_id:";
        $bindings_extra[':payment_plan_id:'] = $payment_plan_id;
        $res = (object) KetrouteApplication::db()->execute($SQL, $bindings_extra);
        return (object)$res->fields;
    }

    public static function getPaymentPlanPaymentPeriods($payment_plan_id)
    {
        $SQL = "SELECT * FROM payment_plan_period WHERE payment_plan_id = :payment_plan_id:";
        $bindings_extra[':payment_plan_id:'] = $payment_plan_id;
        $results = null;
        $resultsarr = KetrouteApplication::db()->execute($SQL, $bindings_extra);

        if (isset($resultsarr->fields) && $resultsarr->fields) {

            while (!$resultsarr->EOF) {

                $results[] = (object)$resultsarr->fields;
                $resultsarr->MoveNext();
            }
        }
        return $results;
    }

    public static function getCasePaymentPlanCount($case_id)
    {
        $SQL = "SELECT COUNT(id) AS total FROM arrears_payment_plan WHERE arrears_case_id = :case_id:";
        $bindings_extra[':case_id:'] = $case_id;
        $res = (object) KetrouteApplication::db()->execute($SQL, $bindings_extra);
        return $res->fields["total"];
    }

    public static function count($queryParams)
    {
        $genericSQL = self::getQueryData($queryParams);
        $SQL = "WITH results AS
            (
                $genericSQL
            )
            SELECT COUNT(*) AS total FROM results
        ";
        $res = (object) KetrouteApplication::db()->execute($SQL);
        return $res->fields["total"];
    }

    public static function getUserDetails($action_owner_id)
    {
        $SQL = "SELECT * FROM [user] WHERE id = :action_owner_id:";
        $bindings_extra[':action_owner_id:'] = $action_owner_id;
        $res = (object)KetrouteApplication::db()->execute($SQL, $bindings_extra);
        return (object)$res->fields;
    }

    public static function pp_approval_action($pp_id, $approval_action, $case_status)
    {
        $action_by = KSecurity::getUserID();
        $action_on = date('Y-m-d');

        $SQL = "UPDATE arrears_payment_plan SET approval_status = :approval_action:, 
                approved_by = :action_by:, approved_on = :action_on: 
                WHERE id = :pp_id:";

        $bindings_extra[':approval_action:'] = $approval_action;
        $bindings_extra[':action_by:'] = $action_by;
        $bindings_extra[':pp_id:'] = $pp_id;
        $bindings_extra[':action_on:'] = $action_on;


        KetrouteApplication::db()->execute($SQL, $bindings_extra);

        // update case
        $case_id = self::getPaymentPlanByID($pp_id)->arrears_case_id;

        ArrearCase::updateStatus($case_id, $case_status);
    }

    public static function getPaymentPlanAttachments($payment_plan_id)
    {
        $SQL = "SELECT * FROM payment_plan_attachments WHERE payment_plan_id = :payment_plan_id: ";
        $bindings_extra[':payment_plan_id:'] = $payment_plan_id;
        
        $SQL .= " ORDER BY (id)";

        $results = null;
        $resultsarr = KetrouteApplication::db()->execute($SQL, $bindings_extra);

        if (isset($resultsarr->fields) && $resultsarr->fields) {

            while (!$resultsarr->EOF) {
                $results[] = (object)$resultsarr->fields;
                $resultsarr->MoveNext();
            }
        }
        return $results;
    }

    public static function expired() {
        // Payment bills that expired and are not yet paid
        $today = date("Y-m-d 00:00:00");
        $SQL = "SELECT pp.id, arr.branch_code, arr.ref_name, arr.customer_id, pp.amount_stated
            FROM payment_plan_period pp
            LEFT JOIN  arrears_payment_plan pay on pay.id = pp.payment_plan_id
            LEFT JOIN arrear_case arr on arr.id = pay.arrears_case_id
            LEFT JOIN payment payment on payment.id = pp.payment_id
            WHERE pp.payment_date_stated < '$today' AND (payment.id IS NULL OR payment.transaction_status != 'C')
        ";
        $res = KetrouteApplication::db()->execute($SQL);
        return $res->fields;
    }
}
