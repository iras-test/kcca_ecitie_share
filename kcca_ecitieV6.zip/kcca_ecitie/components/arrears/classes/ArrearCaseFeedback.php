<?php

class ArrearCaseFeedback {
    public static function getTypes() {
        return KetrouteApplication::instance()->database()->getList(
            $table = 'arrears_case_feedback_type',
            $where = array(
                'status_id' => KStatus::ACTIVE
            )
        );
    }

    public static function getFeedbackType($id) {
        return KetrouteApplication::instance()->database()
            ->getStaticTableValue('arrears_case_feedback_type', 'id', 'name', $id);
    }

    public static function create($case) {
        return KetrouteApplication::db()->createRecord(
            'arrears_case_feedback', 
            array(
                "arrears_case_id" => $case->id,
                "location" => KRequest::getPost("location"),
                "feedback_type" => KRequest::getPost("feedback_type"),
                "feedback" => KRequest::getPost("feedback"),
                "created_by" => KSecurity::getUserID()
            ),
            array('created_date' => KetrouteApplication::db()->getNowExpression())
        );
    }

    public static function getAllFeedback($case) {
        return KetrouteApplication::db()->getList(
            $table = 'arrears_case_feedback',
            $where = array(
                'status_id' => KStatus::ACTIVE,
                'arrears_case_id' => $case
            )
        );
    }
}