
<?php

(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
set_time_limit(0);

/**
 * Generate list of transferred businesses as a CSV
*/
$attachment = KFW_STORAGE_PATH . $this->getComponentRealname() . DIRECTORY_SEPARATOR . "{$this->getComponent()}-{$this->getModule()}.csv";
$arrHeaders = array('Due Date', 'Customer', 'Coin', 'Revenue Type', 'Amount');
$arrResults = ArrearCase::getArrearsTransferedToday();

$file = ArrearsDocumentManager::createCSV(
    $attachment,
    $arrHeaders,
    $arrResults
);

foreach (ArrearsManager::getOfficers(31) as $item) {
    print_r($item);
    print_r("\n");
    $subject = "Transfer of Businesses to Arrears";
    $body = "Dear $firstname, please note that the following businesses in the attched document have been moved to arrears";
    NotificationManager::sendEMail($item->email, $subject, $body, [$file]);
}
