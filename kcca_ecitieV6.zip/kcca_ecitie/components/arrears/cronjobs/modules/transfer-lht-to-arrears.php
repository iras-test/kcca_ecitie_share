
<?php

(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
set_time_limit(0);

// run on 1st of july

$biz_count = 0;
$due_date = date('Y-m-d', strtotime("-3 year"));
$ref_name = "localhoteltax";

$instance = KetrouteApplication::instance();

foreach (ArrearsManager::LocalHotelTaxInArrears($due_date) as $business) {

    $biz_count++;
    // check arrears status
    print("check arrears status \n ");

    $bill_where_clause = array(
        'reference_id' => $business->id,
        'reference_name' => $ref_name,
        'status_id' => KStatus::DEBITED,
        'reason' => "Local Hotel Tax"
    );
    $payment_where_clause = array(
        'reference_id' => $business->id,
        'reference_name' => $ref_name,
        'reconciliation_status' => "MR"
    );

    $total_amount_paid_up_to_date = $instance->db()->getSum(
        'payment_bill',
        'amount',
        $where = $payment_where_clause
    );

    print("total amount paid $total_amount_paid_up_to_date \n ");


    $total_debit_amount_as_of_due_date = $instance->db()->getSum(
        'payment_bill',
        'amount',
        $where = $bill_where_clause,
        $where_in = null,
        $likeforlike_binding = null,
        $startwith_binding = null,
        $endwith_binding = null,
        $hasatleast_binding = null,
        $greaterthanequal_binding = null,
        $lessthanequal_binding = array('created_date' => $due_date)
    );

    print("total bill amount $total_debit_amount_as_of_due_date \n ");

    // if existing debits are more than payments
    if ($total_debit_amount_as_of_due_date > $total_amount_paid_up_to_date) {

        // qualifies for arrears
        print("checking for arrears aging: \n");

        $bills_as_of_due_date = $instance->db()->getList(
            "payment_bill",
            $where = $bill_where_clause,
            $fields = '*',
            $pager_info = null,
            $where_in = null,
            $likeforlike_binding = null,
            $startwith_binding = null,
            $endwith_binding = null,
            $hasatleast_binding = null,
            $greaterthanequal_binding = null,
            $lessthanequal_binding = array('created_date' => $due_date),
            $between_binding = null,
            $year_binding = null, 
            $order_ascending = 'created_date'
        );
        // check non paid bill
        $paid_amount = $total_amount_paid_up_to_date;
        foreach ($bills_as_of_due_date as $index => $bill_obj) {

            $bill_amount = $bill_obj->amount;

            if ($paid_amount > $bill_amount) {

                $paid_amount = $paid_amount - $bill_amount;

            } else {

                print("$biz_count : updating business details... ");

                # Update status
                ArrearsManager::updateBusinessArrearStatus("lht_application", $business->id, ArrearStatus::BUSINESS_MOVED_TO_ARREARS);
                print("updated business details\n");

                // Transfer to arrears
                print("creating arrear case....");

                ArrearCase::create(
                    $business->customer_id,
                    $business->id,
                    $ref_name,
                    null,
                    ArrearStatus::OPEN,
                    $bill_obj->due_date,
                    $bill_obj->revenue_type_id
                );
                print("created arrear case\n");

                break;
            }
        }
    }

}
