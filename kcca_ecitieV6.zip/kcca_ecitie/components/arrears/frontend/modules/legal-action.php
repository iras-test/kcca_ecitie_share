<?php

$legal_action_id = $this->getParam('id', 1);
$download = $this->getParam('download', 1);
$response = $this->getParam('response', 1);
$legal_action = LegalManager::getLegalAction($legal_action_id);

/** Handle submission of response */
if (KRequest::isPosted()) {
    $file_name = KRequest::getUploadName('document');
    $file_name = KGenerator::licenseKey($file_name).'.'.KFile::getExtension($file_name);
    $response_to_sue = LegalManager::createLegalResponse($legal_action_id);
    $this->logAuditTrail("Recorded response for intention to Sue #$legal_action_id", 'legal_action_response', $response_to_sue);
    KSecurity::setActionSuccess('You have successfully submitted your response');
}


/** Handle download of response to sue document */
if($download == 'doc') {
    $response = $this->database()->load($table = 'legal_action_response', $where = array('id' => $response));
    $docName = $response->document . '.' . KFile::getExtension($response->document_name);
    $docPath = KFW_STORAGE_PATH . $this->getComponentRealname() . DIRECTORY_SEPARATOR . $response->document_sysname;
    KFile::downloadFile($docName, $docPath, $delete_file_when_done = false);
}
/** End */

$responses = Util::getActionResponses($legal_action_id);

if($legal_action) {
    $info_display = "
        <div class=\"clear customer-blocks pb10\">
            <h1 class=\"kfw-active-title\"><strong>[lang-arrears-case-details]<strong></h1>
            <div class=\"clear pt10\">
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Comment</span></strong>: {$legal_action->description}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Action By</span></strong>: KCCA
                </div>
            </div>
        </div>
    ";
}

$this->render(array(
    "info_display" => $info_display,
    "responses"    => $responses
));
