<?php

class ReportsApiManager
{

    const r_table = "r_table";
    const master_table_alias = "mt";
    const sec_table = "_sec_";

    public static function getData($query_params, $results)
    {

        if (isset($query_params[self::r_table])) {

            $passed_table_name = $query_params[self::r_table];
            unset($query_params[self::r_table]);
            // secondary tables have a format "{table_name}_sec_{other_naming}"
            $table_name = explode(self::sec_table, $passed_table_name)[0];
            $table_columns = self::get_table_column_details($table_name);

            $left_escape     = KetrouteApplication::db()->dbFieldLeftEscape();
            $right_escape    = KetrouteApplication::db()->dbFieldRightEscape();


            $table_ignore_columns = self::getReportModuleFieldValue("name", $table_name, "ignore_columns");

            $columns_details_ext = self::table_allowed_columns($table_columns, $table_ignore_columns, self::master_table_alias, $table_name);
            $columns = $columns_details_ext[0];
            $results['table_columns'] = $columns_details_ext[1];
            // get table configurations
            $this_module_id  = self::getReportModuleFieldValue("name", $passed_table_name, "id");
            $module_configs = self::getReportModuleConfigs($this_module_id);

            // check for secondary configs
            if ($passed_table_name != $table_name) {

                $this_module_id  = self::getReportModuleFieldValue("name", $table_name, "id");
                $module_configs = array_merge($module_configs, self::getReportModuleConfigs($this_module_id));
            }
            $where = self::where_filter_from_params("", $query_params, self::master_table_alias, $table_name);
            $joins_config_result = self::build_query_joins($module_configs, $columns, self::master_table_alias, 0, $results['table_columns'], $where, $query_params);
            $inner_joins = $joins_config_result[0];
            $columns = $joins_config_result[1];
            $results['table_columns'] = $joins_config_result[2];
            $where = $joins_config_result[3];

            $query_master_table_conc = "{$left_escape}{$table_name}{$right_escape} AS " . self::master_table_alias;
            $SQL = "SELECT {$columns} FROM {$query_master_table_conc}{$inner_joins}{$where}";

            $resultsarr = KetrouteApplication::db()->execute($SQL, []);
            if (isset($resultsarr->fields) && $resultsarr->fields) {

                $arrResults = [];
                while (!$resultsarr->EOF) {

                    $arrResults[] = (object)$resultsarr->fields;
                    $resultsarr->MoveNext();
                }

                $results['data'] =  $arrResults;
            }
        }

        return $results;
    }

    public static function build_query_joins($table_configs, $columns, $parent_table_alias, $level, $query_column_details, $where_statement, $query_params, $join_str = "", $row = 0)
    {
        $left_escape     = KetrouteApplication::db()->dbFieldLeftEscape();
        $right_escape    = KetrouteApplication::db()->dbFieldRightEscape();
        $count = 0;
        foreach ($table_configs as $value) {
            $value = (object)$value;
            $column = $value->from_column;
            $ref_table_column = $value->ref_table_column;
            $join_table_alias = "J{$level}{$row}{$count}";
            if ($ref_table_column) {

                $ref_table_value = $value->ref_table_value;
                $table_to_join = $ref_table_value;
                $ref_column = $value->to_table_column;

                $where_statement = self::add_where_param($where_statement, $ref_table_column, $ref_table_value, $parent_table_alias);
            } else {
                $to_table_column = explode(",", $value->to_table_column);
                $table_to_join = $to_table_column[0];
                $ref_column = $to_table_column[1];
            }
            $join_str .= " LEFT JOIN {$left_escape}{$table_to_join}{$right_escape} AS $join_table_alias ON $join_table_alias.{$left_escape}{$ref_column}{$right_escape} = $parent_table_alias.{$left_escape}{$column}{$right_escape}";

            $display_columns = explode(",", $value->display_columns);
            foreach ($display_columns as $column_value) {

                $column_value_disect = explode(":", $column_value);
                if (count($column_value_disect) == 2) {
                    $column_value = $column_value_disect[0];
                    $column_as_value = $column_as_ref = $column_value_disect[1];
                    $column_alias_value = "{$table_to_join}__{$column_value}__{$column_as_ref}";
                } else {
                    $column_as_value = $column_alias_value = "{$table_to_join}__{$column_value}";
                }

                $query_column_details[] = self::get_table_column_datatype($table_to_join, $column_value, $column_alias_value);

                $columns .= ", $join_table_alias.{$left_escape}{$column_value}{$right_escape} AS {$column_as_value}";
                $add_where = false;
                $query_params_keys = array_keys($query_params);

                if (in_array($column_alias_value, $query_params_keys)) {
                    $add_where = true;
                }

                if (in_array("{$column_alias_value}_on", $query_params_keys)) {

                    $column_alias_value = "{$column_alias_value}_on";
                    $column_value = "{$column_value}_on";
                    $add_where = true;
                }

                if (in_array("{$column_alias_value}_start", $query_params_keys)) {

                    $column_alias_value = "{$column_alias_value}_start";
                    $column_value = "{$column_value}_start";
                    $add_where = true;
                }

                if (in_array("{$column_alias_value}_end", $query_params_keys)) {

                    $column_alias_value = "{$column_alias_value}_end";
                    $column_value = "{$column_value}_end";
                    $add_where = true;
                }

                if ($add_where) {
                    $where_statement = self::add_where_param($where_statement, $column_value, $query_params[$column_alias_value], $join_table_alias);
                }
            }

            // get third party configs //
            // get table configurations
            $table_to_join_module_id  = self::getReportModuleFieldValue("name", $table_to_join, "id");
            $table_join_configs = self::getReportModuleConfigs($table_to_join_module_id);

            if (count($table_join_configs) > 0) {
                $row += 1;
                $level += 1;
                list($join_str, $columns, $query_column_details, $where_statement, $level) = self::build_query_joins($table_join_configs, $columns, $join_table_alias, $level, $query_column_details, $where_statement, $query_params, $join_str, $row);
                $level -= 1;
            }

            $count += 1;
        }

        return [$join_str, $columns, $query_column_details, $where_statement, $level];
    }

    public static function get_table_column_details($table_name)
    {
        $SQL = "SELECT c.Name AS Field_Name FROM sys.columns c 
        INNER JOIN sys.objects o ON o.object_id = c.object_id 
        LEFT JOIN  sys.types t on t.user_type_id  = c.user_type_id 
        WHERE o.type = 'U' and o.Name = :table_name: ";

        $bindings_extra[':table_name:'] = $table_name;
        $results = [];
        $resultsarr = KetrouteApplication::db()->execute($SQL, $bindings_extra);
        if (isset($resultsarr->fields) && $resultsarr->fields) {

            while (!$resultsarr->EOF) {

                $results[] = $resultsarr->fields['Field_Name'];
                $resultsarr->MoveNext();
            }
        }

        return $results;
    }

    public static function get_table_column_datatype($table_name, $column, $column_alias = null)
    {
        $SQL = "SELECT t.Name AS Data_Type FROM sys.columns c 
        INNER JOIN sys.objects o ON o.object_id = c.object_id 
        LEFT JOIN  sys.types t on t.user_type_id  = c.user_type_id 
        WHERE o.type = 'U' and o.Name = :table_name: and c.Name = :column_name:";

        $bindings_extra[':table_name:'] = $table_name;
        $bindings_extra[':column_name:'] = $column;

        $results = null;
        $resultsarr = KetrouteApplication::db()->execute($SQL, $bindings_extra);
        if (isset($resultsarr->fields) && $resultsarr->fields) {

            while (!$resultsarr->EOF) {
                $column_details = [];
                $column_details['name'] = ($column_alias == null) ? $column : $column_alias;
                $column_details['data_type'] = $resultsarr->fields['Data_Type'];
                $results = (object)$column_details;
                $resultsarr->MoveNext();
            }
        }

        return $results;
    }

    public static function getReportModules()
    {
        $reports = KetrouteApplication::db()->getList("report_modules", $where = array('status' => 1), $fields = ["id", "name", "display_name"]);
        return array_values($reports);
    }

    public static function getReportModuleConfigs($table_id)
    {
        return KetrouteApplication::db()->getList(
            "report_modules_config",
            $where = array('report_module_id' => $table_id),
            $fields = '*'
        );
    }

    public static function getAllReportModuleConfigs()
    {
        return KetrouteApplication::db()->getList(
            "report_modules_config",
            $where = array(),
            $fields = '*'
        );
    }

    public static function getReportModuleFieldValue($primary_column, $where_field, $field)
    {
        return KetrouteApplication::db()->getStaticTableValue("report_modules", $primary_column, $field, $where_field);
    }

    public static function table_allowed_columns($table_columns, $ignore_columns, $table_alias, $table_name)
    {
        $allowed_columns_array = [];
        $columns_details = [];
        $left_escape     = KetrouteApplication::db()->dbFieldLeftEscape();
        $right_escape    = KetrouteApplication::db()->dbFieldRightEscape();
        $ignore_columns = explode(",", $ignore_columns);
        foreach ($table_columns as $column) {
            if (!in_array($column, $ignore_columns)) {
                $columns_details[] = self::get_table_column_datatype($table_name, $column);
                $allowed_columns_array[] = "$table_alias.{$left_escape}$column{$right_escape}";
            }
        }
        return [implode(", ", $allowed_columns_array), $columns_details];
    }

    public static function endsWith($string, $endString)
    {
        $len = strlen($endString);
        if ($len == 0) {
            return true;
        }
        return (substr($string, -$len) === $endString);
    }

    public static function add_where_param($where_statement, $key, $value, $table_alias)
    {

        $left_escape     = KetrouteApplication::db()->dbFieldLeftEscape();
        $right_escape    = KetrouteApplication::db()->dbFieldRightEscape();

        $where_statement .= ($where_statement == '') ? ' WHERE ' : ' AND ';

        if (strpos($key, "_date")) {

            if (self::endsWith($key, "_start")) {

                $key = explode("_start", $key)[0];
                $where_statement .= "$table_alias.{$left_escape}{$key}{$right_escape} >= '$value 00:00:00'";
            }

            if (self::endsWith($key, "_end")) {

                $key = explode("_end", $key)[0];
                $where_statement .= "$table_alias.{$left_escape}{$key}{$right_escape} <= '$value 23:59:59'";
            }

            if (self::endsWith($key, "_on")) {

                $key = explode("_on", $key)[0];
                $where_statement .= "$table_alias.{$left_escape}{$key}{$right_escape} >= '$value 00:00:00' AND ";
                $where_statement .= "$table_alias.{$left_escape}{$key}{$right_escape} <= '$value 23:59:59'";
            }
        } else {

            $where_statement .= "$table_alias.{$left_escape}{$key}{$right_escape} = '$value'";
        }

        return $where_statement;
    }

    public static function getactualKey($key)
    {

        if (strpos($key, "_date")) {

            if (self::endsWith($key, "_start")) {
                $key = explode("_start", $key)[0];
            }

            if (self::endsWith($key, "_on")) {
                $key = explode("_on", $key)[0];
            }

            if (self::endsWith($key, "_end")) {
                $key = explode("_end", $key)[0];
            }
        }
        return $key;
    }

    public static function where_filter_from_params($where_statement, $params, $table_alias, $table_name)
    {


        $table_columns = self::get_table_column_details($table_name);
        foreach ($params as $key => $value) {

            $check_key = self::getactualKey($key);

            if (in_array($check_key, $table_columns)) {


                $where_statement = self::add_where_param($where_statement, $key, $value, $table_alias);
            }
        }

        if (count(array_keys($params)) == 0) {

            $date_today = date('Y-m-d');
            $key = "created_date_on";
            $where_statement = self::add_where_param($where_statement, $key, $date_today, $table_alias);
        }

        return $where_statement;
    }
}
