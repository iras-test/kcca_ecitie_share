<?php

/** Send out expiry notices to city operators whose payment plan has expired */
NotificationManager::sendReminderNotices();