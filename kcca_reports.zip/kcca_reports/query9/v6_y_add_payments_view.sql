CREATE VIEW [dbo].[v_payment] AS
SELECT [mt].*
      ,CASE 
        WHEN [pb].reference_name='trading_license' THEN (select top 1 lst_amount from [trading_license_application] where trading_license_id = [tl].id ORDER by id desc) 
        ELSE null
       END as lst_amount
      ,CASE 
        WHEN [pb].reference_name='trading_license' THEN [tl].village
        WHEN [pb].reference_name='localhoteltax' THEN [lht].village_zone_id
        WHEN [pb].reference_name='property' THEN [prt].village_id
        WHEN [pb].reference_name='lst_branch' THEN [lst].lst_village_id
        WHEN [pb].reference_name='ontr_customer' THEN [ontr].village
        ELSE null
       END as village_id
       ,CASE 
        WHEN [pb].reference_name='trading_license' THEN [tl].street_id
        WHEN [pb].reference_name='localhoteltax' THEN [lht].street_road_name
        WHEN [pb].reference_name='property' THEN [prt].street_id
        WHEN [pb].reference_name='lst_branch' THEN (select name from street where id = [lst].lst_street_id)
        WHEN [pb].reference_name='ontr_customer' THEN (select name from street where id =  [ontr].street)
        ELSE null
       END as business_street
  FROM [ecitie].[dbo].[payment] as [mt] 
  LEFT JOIN [payment_bill] as [pb] on [pb].payment_id = [mt].id
  LEFT JOIN [trading_license] as [tl] on ([tl].id = [pb].reference_id and [pb].reference_name='trading_license')
  LEFT JOIN [lht_application] as [lht] on ([lht].id = [pb].reference_id and [pb].reference_name='localhoteltax')
  LEFT JOIN [property] as [prt] on ([prt].id = [pb].reference_id and [pb].reference_name='property')
  LEFT JOIN [ontr_customer] as [ontr] on ([ontr].id = [pb].reference_id and [pb].reference_name='ontr_customer')
  LEFT JOIN [lst_branch] as [lst] on ([lst].id = [pb].reference_id and [pb].reference_name='lst_branch')
  LEFT JOIN [vehicle] as [vh] on ([vh].id = [pb].reference_id and [pb].reference_name='vehicle')

