<?php

/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

$arrReportConfig                                                    = array();
$arrReportConfig[KSystemManager::ITEM_PROPERTY_TABLE_NAME]          = 'report_modules_config';
$arrReportConfig[KSystemManager::ITEM_PROPERTY_LIST_FIELDS]         = array('report_module_id', 'from_column', 'to_table_column', 'display_columns', 'ref_table_column', 'ref_table_value','status');
$arrReportConfig[KSystemManager::ITEM_PROPERTY_VIEW_FIELDS]         = array('report_module_id', 'from_column', 'to_table_column', 'display_columns', 'ref_table_column', 'ref_table_value','status');

$arrReportConfig[KSystemManager::ITEM_PROPERTY_ADD_FIELDS]             = array('report_module_id', 'from_column', 'to_table_column', 'display_columns', 'ref_table_column', 'ref_table_value','status');
$arrReportConfig[KSystemManager::ITEM_PROPERTY_EDIT_FIELDS]         = array('report_module_id', 'from_column', 'to_table_column', 'display_columns', 'ref_table_column', 'ref_table_value','status');
$arrReportConfig[KSystemManager::ITEM_PROPERTY_SORT_FIELDS]         = array('report_module_id' => KSystemManager::SORT_ASCENDING);


$arrReportConfig[KSystemManager::ITEM_PROPERTY_PRIMARY_KEY]         = 'id';
$arrReportConfig[KSystemManager::ITEM_PROPERTY_TITLE_FIELD]         =  'to_table_column';

$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]                                                                         = array();

$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['report_module_id']                                                     = array();
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['report_module_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE]        = KSystemManager::FIELD_TYPE_SELECT;
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['report_module_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL]       = 'report-module-name';
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['report_module_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH]   = 100;
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['report_module_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH]   = null;
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['report_module_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED]    = 1;
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['report_module_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT]     = '';
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['report_module_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD]         = array(
    KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'report_modules',
    KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID         => 'id',
    KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE     => 'name',
    KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED      => false,
    KSystemManager::WHERE_CLAUSE                         => null,
    KSystemManager::ORDER_BY                              => array('name' => KSystemManager::SORT_ASCENDING),
);

$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['from_column']                                                     = array();
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['from_column'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE]             = KSystemManager::FIELD_TYPE_TEXT;
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['from_column'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL]         = 'column';
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['from_column'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH]     = 50;
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['from_column'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH]     = null;
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['from_column'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED]         = 1;
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['from_column'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT]         = '';
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['from_column'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD]         = array();

$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['to_table_column']                                                     = array();
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['to_table_column'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE]         = KSystemManager::FIELD_TYPE_TEXT;
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['to_table_column'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL]         = 'to-table';
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['to_table_column'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH]    = 50;
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['to_table_column'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH]    = null;
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['to_table_column'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED]     = 1;
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['to_table_column'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT]         = '';
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['to_table_column'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD]         = array();

$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['display_columns']                                                     = array();
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['display_columns'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE]         = KSystemManager::FIELD_TYPE_TEXTAREA;
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['display_columns'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL]         = 'display-columns';
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['display_columns'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH]    = null;
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['display_columns'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH]    = null;
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['display_columns'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED]     = 1;
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['display_columns'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT]         = '';
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['display_columns'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD]         = array();

$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['ref_table_column']                                                     = array();
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['ref_table_column'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE]         = KSystemManager::FIELD_TYPE_TEXT;
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['ref_table_column'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL]         = 'ref_table_column';
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['ref_table_column'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH]    = 1000;
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['ref_table_column'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH]    = null;
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['ref_table_column'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED]     = 0;
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['ref_table_column'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT]         = '';
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['ref_table_column'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD]         = array();

$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['ref_table_value']                                                     = array();
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['ref_table_value'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE]         = KSystemManager::FIELD_TYPE_TEXT;
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['ref_table_value'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL]         = 'ref_table_value';
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['ref_table_value'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH]    = 1000;
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['ref_table_value'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH]    = null;
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['ref_table_value'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED]     = 0;
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['ref_table_value'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT]         = '';
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['ref_table_value'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD]         = array();


$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['status'] 				                                    = array();
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['status'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 		= KSystemManager::FIELD_TYPE_YESNO;
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['status'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 	    = 'status';
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['status'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH]    = 50;
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['status'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH]    = null;
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['status'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 	= 1;
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['status'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 	    = '';
$arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['status'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 	    = array();

return $arrReportConfig;
