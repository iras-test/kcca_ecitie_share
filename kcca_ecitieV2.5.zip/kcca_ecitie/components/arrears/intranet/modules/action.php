<?php

$error = null;

$queryParams = KRequest::getQueryStrings();
$ref_name = $queryParams["ref_name"];
$ref_id = $queryParams["ref_id"];
$records = "";
$info = ArrearCase::getArrearCase($ref_id, $ref_name);

if (KRequest::isPosted()) {
    $assignee = KRequest::getPost("assignee");
    // If already assigned, get case and re-assign
    $payment_bill = $this->database()->load($table = 'payment_bill', $where = array('reference_name' => $ref_name, 'reference_id' => $ref_id));
    if ($info) {
        // Change assignee
        $this->database()->updateRecord('arrear_case', array('assignee' => $assignee), array('id' => $info->id), $one_record = true, array('modified_date' => $this->database()->getNowExpression()));
    } 
}

/** Case assignment officers */
$officers = ArrearsManager::getOfficers();
$assignee_options = "";
foreach ($officers as $key => $value) {
    $assignee_options .= "<option value=\"$value->id\">{$value->surname} {$value->firstname}</option>";
}



$bills = ArrearsManager::getAllPaymentBills($ref_name, $ref_id);

$info_display = null;
if ($info) {
    $business_details = ArrearsManager::getBusinessDetails($ref_name, $ref_id);

    $extra_details = "";

    if ($info->ref_name == "vehicle") {
        $extra_details .= "<div class=\"pt10\">
                            <strong><span class=\"bs-bold\">Park</span></strong>: {$business_details->park_name}
                        </div>
                        <div class=\"pt10\">
                            <strong><span class=\"bs-bold\">Stage</span></strong>: {$business_details->stage_name}
                        </div>
                        ";
    }

    $customer_name = $this->runtime()->getFieldData('customer_id', (array)$info)
			? $this->runtime()->getFieldData('customer_id', (array)$info)
			: "N/A";

    $info_display = "
        <div class=\"clear customer-blocks pb10\">
            <h1 class=\"kfw-active-title\"><strong>[lang-arrears-case-details]<strong></h1>
            <div class=\"clear pt10\">
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Customer</span></strong>: {$customer_name}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">COIN</span></strong>: {$info->coin}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Revenue Type</span></strong>: {$info->revenue_name}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Branch Code</span></strong>: {$info->branch_code}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Location</span></strong>: {$business_details->location}
                </div>
                {$extra_details}
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Outstanding balance</span></strong>: " . abs($info->arrear_amount) . "
                </div>
            </div>
        </div>
    ";
}

/** Bill breakdowns */
if (count($bills) > 0) {
    // show record	
    foreach ($bills as $index => $arrData) {
        $class = ($index % 2 == 0) ? ' odd' : ' even';
        $obj = (object) $arrData;
        $record_number = $index + 1;
        $prn = $obj->prn ? $obj->prn : "N/A";

        $records .= "<div class=\"clear list-item{$class}\">";
        $records .= "\n\t\t\t<div class=\"fl numbering-col\">{$record_number}</div>";
        $records .= "\n\t\t\t<div class=\"fl col20\">{$obj->financial_year}</div>";
        $records .= "\n\t\t\t<div class=\"fl col20\">{$prn}</div>";
        $records .= "\n\t\t\t<div class=\"fl col20\">{$obj->due_date}</div>";
        $records .= "\n\t\t\t<div class=\"fl col20\">{$obj->amount}</div>";
        $records .= "\n\t\t</div>";
    }
} else {
    $records  = "\n\t\t<div class=\"clear list-item\">" . KLanguage::getWord('arrears-case-items') . "</div>";
}

/** Get current assignee */
$curr_asignee = "N/A";
if ($info) {
    $user = ArrearsManager::getUser($assignee);
    if ($user) {
        $user = (object) $user;
        $curr_asignee = "$user->surname $user->firstname";
    }
}


$arrear["options"] = $options;
$arrear["bills"] = $records;
$arrear["info_display"] = $info_display;
$arrear["curr_asignee"] = $curr_asignee;
$arrear["error"] = $error;
$arrear["options"] = $assignee_options;
$arrear["close_url"] = "action={$this->urlPath(0)}close-case?id={$bill_id}";

$this->render($arrear);
