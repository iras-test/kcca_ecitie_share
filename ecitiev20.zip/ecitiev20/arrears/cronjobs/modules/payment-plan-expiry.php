
<?php

(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
set_time_limit(0);

// Everyday 8:00AM
$results = PaymnentPlanManager::expired();
print_r($results);
