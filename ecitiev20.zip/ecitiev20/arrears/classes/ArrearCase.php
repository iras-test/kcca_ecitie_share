<?php

/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

class ArrearCase
{

    public static function getArrearSelect()
    {
        return "SELECT arr_case.id, arr_case.created_date, arr_case.created_by, arr_case.ref_id, arr_case.ref_name, 
        arr_case.customer_id, arr_case.assigned_action,
        arr_case.assignee, arr_case.status, arr_case.closed, 
        arr_case.due_date, arr_case.modified_date,
        arr_case.division,
        arr_case.revenue_type_id, arr_case.revenue_name, arr_case.mobile, arr_case.email, 
        arr_case.customer, arr_case.coin, arr_case.branch_code, 
        arr_case.arrear_amount 
        FROM v_arrear_case AS arr_case ";
    }

    public static function getQueryData($queryParams)
    {
        $where = self::where($queryParams);
        $join = self::buildJoin($queryParams);
        $select = self::getArrearSelect();
        return "$select $join WHERE $where ORDER BY id ";
    }

    public static function getCountQuery($queryParams)
    {
        $where = self::where($queryParams);
        $join = self::buildJoin($queryParams);
        return "SELECT Count(*) As total FROM v_arrear_case As arr_case $join WHERE $where ";
    }

    public static function where($queryParams)
    {
        $current_user = KSecurity::getUserID();
        $amount_filter = null;

        if (array_key_exists("amount_start", $queryParams)  && $queryParams['amount_start']) {
            $amount_start = $queryParams["amount_start"];
            // all arrears amounts are in -ve
            $amount_start = -1 * abs($amount_start);

            $amount_filter .= " arr_case.arrear_amount <= $amount_start ";
        }

        if (array_key_exists("amount_end", $queryParams)  && $queryParams['amount_end']) {
            $amount_end = $queryParams["amount_end"];
            // all arrears amounts are in -ve
            $amount_end = -1 * abs($amount_end);
            $amount_filter = $amount_filter ? ($amount_filter . " AND ") : " ";
            $amount_filter .= " arr_case.arrear_amount >= $amount_end ";
        }

        $amount_filter = $amount_filter ? $amount_filter : " 1=1 ";

        $where = " $amount_filter ";
        if (array_key_exists("assigned", $queryParams)  && $queryParams['assigned']) {
            $where .= " AND arr_case.assignee != 0 ";
        }
        if (!((array_key_exists("g_s", $queryParams) && $queryParams['g_s']) || (array_key_exists("legal", $queryParams) && $queryParams['legal'] ))) {
            if (UserManager::getProfile($current_user)->user_role_id != ArrearStatus::ARREARS_MANAGER_ROLE) {
                $where .= " AND (( arr_case.id in (SELECT arrears_case_id FROM arrear_case_assignment WHERE 
                                  user_id = '$current_user' AND active = '1' )
                                ) 
                                OR arr_case.assignee = '$current_user' OR  arr_case.created_by = '$current_user'
                                OR arr_case.customer_id in (SELECT customer_id from [dbo].[user] where id = '$current_user'))  ";
            }
        }

        $where .= self::buildWhere($queryParams);
        return $where;
    }


    public static function getList($page, $queryParams)
    {
        list($start, $end) = ArrearsManager::getPagination($page);
        $genericSQL = ArrearCase::getQueryData($queryParams);

        $PAGE_OFFSET = ($start - 1);

        $offset = " OFFSET $PAGE_OFFSET ROWS FETCH NEXT 10 ROWS ONLY ";

        $SQL = " $genericSQL $offset ";
        $instance = KetrouteApplication::instance();
        return $instance->database()->execute($SQL);
    }

    public static function buildJoin($queryParams)
    {

        $join = " ";
        return $join;
    }

    public static function count($queryParams)
    {
        $genericSQL = ArrearCase::getCountQuery($queryParams);
        $instance = KetrouteApplication::instance();
        $res = (object) $instance->database()->execute($genericSQL);
        return $res->fields["total"];
    }

    public static function buildWhere($queryParams)
    {
        $where = "";
        if (array_key_exists("coin", $queryParams)  && $queryParams['coin']) {
            $coin = $queryParams["coin"];
            $where .= " AND arr_case.coin = '$coin' ";
        }

        if (array_key_exists("assignee", $queryParams)  && $queryParams['assignee']) {
            $assignee = (int) $queryParams["assignee"];
            $where .= " AND arr_case.assignee = '$assignee' ";
        }

        if (array_key_exists("status", $queryParams)  && $queryParams['status']) {
            $status = $queryParams["status"];
            $where .= " AND arr_case.status = '$status' ";
        }

        if (array_key_exists("division", $queryParams)  && $queryParams['division']) {
            $division = $queryParams["division"];
            $where .= " AND arr_case.division like '%$division%' ";
        }

        if (array_key_exists("case_ref_name", $queryParams)  && $queryParams['case_ref_name']) {
            $case_ref_name = $queryParams["case_ref_name"];
            $where .= " AND arr_case.ref_name = '$case_ref_name' ";
        }

        if (array_key_exists("customer", $queryParams)  && $queryParams['customer']) {
            $cust = $queryParams["customer"];
            $cust = str_replace(' ', '', $cust);
            $where .= " AND arr_case.customer like '%$cust%' ";
        }

        if (array_key_exists("branch_code", $queryParams)  && $queryParams['branch_code']) {
            $branch_code = $queryParams["branch_code"];
            $where .= " AND arr_case.branch_code like '%$branch_code%' ";
        }

        if (array_key_exists("revenue_type", $queryParams)  && $queryParams['revenue_type']) {
            $revenue_type = $queryParams["revenue_type"];
            $where .= " AND arr_case.revenue_type_id = '$revenue_type' ";
        }

        if (array_key_exists("age_start", $queryParams)  && $queryParams['age_start']) {
            $age_start = $queryParams["age_start"];
            $where .= " AND arr_case.due_date >= '$age_start' ";
        }

        if (array_key_exists("age_end", $queryParams)  && $queryParams['age_end']) {
            $age_end = $queryParams["age_end"];
            $where .= " AND arr_case.due_date <= '$age_end' ";
        }

        if (array_key_exists("parish", $queryParams)  && $queryParams['parish']) {
            $parish = $queryParams["parish"];
            $where .= " AND arr_case.parish_id <= '$parish' ";
        }

        if (array_key_exists("village", $queryParams)  && $queryParams['village']) {
            $village = $queryParams["village"];
            $where .= " AND arr_case.village_id <= '$village' ";
        }

        if (array_key_exists("created_date", $queryParams)  && $queryParams['created_date']) {
            $created_date = $queryParams["created_date"];
            $where .= " AND arr_case.created_date = '$created_date' ";
        }

        return $where;
    }

    public static function create($customer_id, $ref_id, $ref_name, $assignee_id, $status, $due_date, $revenue_type_id)
    {
        $business_details = ArrearsManager::getBusinessDetails($ref_name, $ref_id);
        $instance = KetrouteApplication::instance();
        $date_today = date('Y-m-d');

        $instance->database()->createRecord(
            "arrear_case",
            array(
                "customer_id" => $customer_id,
                "ref_id" => $ref_id,
                "ref_name" => $ref_name,
                "assignee" => $assignee_id,
                "branch_code" => $business_details->branch_code,
                "division_id" => $business_details->division_id,
                "parish_id" => $business_details->parish_id,
                "village_id" => $business_details->village_id,
                "street_id" => (string) $business_details->street_id,
                "status" => ($status ? $status : ArrearStatus::ASSIGNED),
                "created_date" => $date_today,
                "modified_date" => $date_today,
                "due_date" => date("Y-m-d", strtotime($due_date)),
                'revenue_type_id' => $revenue_type_id
            )
        );
    }

    public static function createCaseAssignmentPeriod($case_id, $assignee, $period,$created_by){
        $date_today = date('Y-m-d');

        $instance = KetrouteApplication::instance();
        $instance->database()->updateRecord(
            'case_assignment_period',
            array(
                'active' => 0,
                'modified_by' => $created_by,
                "modified_date" => $date_today
            ),
            array('arrears_case_id' => $case_id),
            $one_record = true
        );

        $instance->database()->createRecord(
            "case_assignment_period",
            array(
                "assignee" => $assignee,
                "arrears_case_id" => $case_id,
                "period" => $period,
                "active"=>1,
                "created_date" => $date_today,
                "modified_date" => $date_today,
                "created_by" => $created_by
            )
        );
    }

    public static function create_assignment($assignee, $case_id, $case_status = null)
    {
        $assignment = KetrouteApplication::db()->createRecord(
            "arrear_case_assignment",
            array(
                "user_id" => $assignee,
                "arrears_case_id" => $case_id,
                "created_by" => KSecurity::getUserID()
            ),
            array('created_date' => KetrouteApplication::db()->getNowExpression())
        );
        // Update assignment
        self::updateStatus($case_id, $case_status, null, $assignee);
        return $assignment;
    }

    public static function getCaseAssignments($arrear_case_id, $active_only = true)
    {
        $SQL = "SELECT * FROM arrear_case_assignment WHERE arrears_case_id = :arrears_case_id:";
        if ($active_only) {
            $SQL .= " AND active = '1'";
        }
        $bindings_extra[':arrears_case_id:'] = $arrear_case_id;

        $SQL .= " ORDER BY (id)";

        $results = null;
        $resultsarr = KetrouteApplication::db()->execute($SQL, $bindings_extra);

        if (isset($resultsarr->fields) && $resultsarr->fields) {

            while (!$resultsarr->EOF) {
                if ($active_only) {

                    $results = (object)$resultsarr->fields;
                } else {

                    $results[] = (object)$resultsarr->fields;
                }
                $resultsarr->MoveNext();
            }
        }
        return $results;
    }

    public static function getAssignmentAttachments($assignment_id)
    {
        $SQL = "SELECT * FROM assignment_attachments WHERE assignment_id = :assignment_id:";
        $bindings_extra[':assignment_id:'] = $assignment_id;

        $SQL .= " ORDER BY (id)";

        $results = null;
        $resultsarr = KetrouteApplication::db()->execute($SQL, $bindings_extra);

        if (isset($resultsarr->fields) && $resultsarr->fields) {

            while (!$resultsarr->EOF) {
                $results[] = (object)$resultsarr->fields;
                $resultsarr->MoveNext();
            }
        }
        return $results;
    }

    public static function deactivatePreviousAssignments($case_id)
    {

        $SQL = "UPDATE arrear_case_assignment SET active = '0' WHERE arrears_case_id = '$case_id' ";
        KetrouteApplication::db()->execute($SQL);
    }

    public static function addAssignmentComment($assignment, $comment, $reason)
    {
        $SQL = "UPDATE arrear_case_assignment SET comment = '$comment', reason = '$reason' WHERE id = '$assignment' ";
        KetrouteApplication::db()->execute($SQL);
    }

    public static function getPreviousAssignment($case_id, $current_assignment_id)
    {
        $SQL = "SELECT TOP 1 * FROM arrear_case_assignment WHERE arrears_case_id = '$case_id' AND 
                active = '0' AND id < '$current_assignment_id' ORDER BY id DESC";

        return KetrouteApplication::db()->execute($SQL)->fields;
    }

    public static function getCaseAssignmentsCount($case_id)
    {
        $SQL = "SELECT COUNT(id) AS total FROM arrear_case_assignment WHERE arrears_case_id = '$case_id'";
        $res = (object) KetrouteApplication::db()->execute($SQL);
        return $res->fields["total"];
    }


    public static function updateStatus($case_id, $status = null, $comment = null, $assignee = null, $close_reason = null)
    {
        // TO DO Generic update of status

        $UPDATE_SQL = "UPDATE arrear_case SET modified_date = GETDATE() ";

        $update_bindings[':case_id:'] = $case_id;

        $status_update = false;

        $case_update_log = "Changed Arrear case ";

        if ($status) {
            $UPDATE_SQL .= ", status = :case_status: ";
            $update_bindings[':case_status:'] = $status;
            $status_update = true;
            $case_update_log .= "status to $status ";
        }

        if ($comment) {

            if ($status_update) {
                $case_update_log .= "and ";
            }

            $UPDATE_SQL .= ", reason = :comment: ";
            $update_bindings[':comment:'] = $comment;
            $case_update_log .= " comment/reason to $comment";
        }

        if ($close_reason) {

            if ($status_update) {
                $case_update_log .= "and ";
            }

            $UPDATE_SQL .= ", closed_reason = :closed_reason: , closed = 1 ";
            $update_bindings[':closed_reason:'] = $close_reason;
            $case_update_log .= " closed_reason to $close_reason";
        }

        if ($assignee) {
            if ($status_update) {
                $case_update_log .= "and ";
            }

            $UPDATE_SQL .= ", assignee = :assignee: ";
            $update_bindings[':assignee:'] = $assignee;
            $case_update_log .= " assignee to $assignee";

            // Notify new assignee about this task
            NotificationManager::notifyAssignee($case_id, $assignee);
        }

        $UPDATE_SQL .= "WHERE id = :case_id:";

        KetrouteApplication::db()->execute($UPDATE_SQL, $update_bindings);

        // capture audit log
        KetrouteApplication::instance()->logAuditTrail($case_update_log, 'arrear_case', $case_id);
    }

    public static function getCaseBusinessSealActions($arrear_case_id, $active_only = true)
    {
        $SQL = "SELECT * FROM arrears_business_seal WHERE arrears_case_id = :arrears_case_id:";
        if ($active_only) {
            $SQL .= " AND seal_status = '1'";
        }
        $bindings_extra[':arrears_case_id:'] = $arrear_case_id;

        $results = null;
        $resultsarr = KetrouteApplication::db()->execute($SQL, $bindings_extra);

        if (isset($resultsarr->fields) && $resultsarr->fields) {

            while (!$resultsarr->EOF) {
                $results = (object)$resultsarr->fields;
                $resultsarr->MoveNext();
            }
        }
        return $results;
    }

    public static function getCaseAgencyNoticeActions($arrear_case_id, $active_only = true)
    {
        $SQL = "SELECT * FROM arrears_agency_notice WHERE arrears_case_id = :arrears_case_id:";
        if ($active_only) {
            $SQL .= " AND agency_notice_status in ('1','2','3')";
        }
        $bindings_extra[':arrears_case_id:'] = $arrear_case_id;

        $results = null;
        $resultsarr = KetrouteApplication::db()->execute($SQL, $bindings_extra);

        if (isset($resultsarr->fields) && $resultsarr->fields) {

            while (!$resultsarr->EOF) {
                $results = (object)$resultsarr->fields;
                $resultsarr->MoveNext();
            }
        }
        return $results;
    }

    public static function getArrearCaseByID($case_id)
    {

        $sql = "SELECT * FROM arrear_case WHERE id = :case_id:";

        $bindings_extra[':case_id:'] = $case_id;

        $results = null;

        $resultsarr = KetrouteApplication::db()->execute($sql, $bindings_extra);

        if (isset($resultsarr->fields) && $resultsarr->fields) {

            while (!$resultsarr->EOF) {

                $results = (object)$resultsarr->fields;
                $resultsarr->MoveNext();
            }
        }

        return $results;
    }

    public static function getArrearCase($ref_id, $ref_name)
    {

        $sql = "SELECT * FROM v_arrear_case WHERE ref_id = :ref_id: AND ref_name = :ref_name:";

        $bindings_extra[':ref_id:'] = $ref_id;
        $bindings_extra[':ref_name:'] = $ref_name;

        $results = null;

        $resultsarr = KetrouteApplication::db()->execute($sql, $bindings_extra);

        if (isset($resultsarr->fields) && $resultsarr->fields) {

            while (!$resultsarr->EOF) {

                $results = (object)$resultsarr->fields;
                $resultsarr->MoveNext();
            }
        }

        return $results;
    }

    public static function getItem($case_id)
    {

        $join = self::buildJoin([]);
        $select = self::getArrearSelect();

        $SQL = "$select $join WHERE arr_case.id = '$case_id'";
        return KetrouteApplication::db()->execute($SQL)->fields;
    }

    public static function getAssignee($assignee_id)
    {
        $users = KetrouteApplication::db()->getList("user", $where = array("id" => $assignee_id));
        return (count($users) > 0)
            ? $users[0]->surname . " " . $users[0]->firstname
            : "N/A";
    }

    public static function getObjectionGrounds()
    {
        return KetrouteApplication::instance()->database()->getList(
            $table = 'ground_of_objection',
            $where = array(
                'status_id' => KStatus::ACTIVE
            )
        );
    }

    public static function hasCaseUnderBusinessSeal($ref_id, $ref_name)
    {
        $case = self::getArrearCase($ref_id, $ref_name);
        return $case->status === ArrearStatus::UNDER_BUSINESS_SEAL ? $case : null;
    }

    public static function getArrearsTransferedToday($queryParams)
    {
        $date_today = date('Y-m-d');
        $SQL = "SELECT arr_case.due_date, arr_case.customer, arr_case.coin, arr_case.coin, arr_case.arrear_amount 
            FROM v_arrear_case AS arr_case WHERE arr_case.created_date = '$date_today'
        ";
        return KetrouteApplication::db()->execute($SQL);
    }

    public static function countCases($queryParams)
    {
        $where = self::buildStatWhere($queryParams);

        $SQL = "SELECT COUNT(arr_case.id) AS total FROM v_arrear_case AS arr_case $where";
        $res = KetrouteApplication::db()->execute($SQL);
        return $res ? $res->fields['total'] : 0;
    }

    public static function totalAmountInArrears($queryParams)
    {
        $where = self::buildStatWhere($queryParams);

        $SQL = "SELECT SUM(arr_case.arrear_amount) AS total_amount FROM v_arrear_case AS arr_case $where";
        $res = KetrouteApplication::db()->execute($SQL);
        return $res ? abs($res->fields['total_amount']) : 0;
    }

    public static function totalCollected($queryParams)
    {
        $where = self::buildStatWhere($queryParams);

        $SQL = "SELECT SUM(arr_case.arrear_amount) AS total_amount FROM v_arrear_case AS arr_case $where";
        $res = KetrouteApplication::db()->execute($SQL);
        return $res ? $res->total_amount : 0;
    }

    public static function buildStatWhere($queryParams)
    {
        $closed_status = ArrearStatus::CLOSED;
        $where = " WHERE arr_case.status != '$closed_status' ";

        if (array_key_exists("ref_name", $queryParams)  && $queryParams['ref_name']) {
            $ref = $queryParams["ref_name"];
            $where .= " AND arr_case.ref_name = '$ref' ";
        }

        if (array_key_exists("start_date", $queryParams)  && $queryParams['start_date']) {
            $start_date = $queryParams["start_date"];
            $where .= " AND arr_case.created_date >= '$start_date' ";
        }

        if (array_key_exists("end_date", $queryParams)  && $queryParams['end_date']) {
            $end_date = $queryParams["end_date"];
            $where .= " AND arr_case.created_date <= '$end_date' ";
        }

        return $where;
    }

    public static function tabularStats($queryParams)
    {

        $data = array();
        $where = self::buildStatWhere($queryParams);
        $SQL = "select count(arr_case.id) as cases, sum(arr_case.arrear_amount) as arrears, arr_case.ref_name as label from v_arrear_case as arr_case $where GROUP BY arr_case.ref_name";

        $res = KetrouteApplication::db()->execute($SQL);

        $results = [];

        if (isset($res->fields) && $res->fields) {

            while (!$res->EOF) {

                $results[] = $res->fields;
                $res->MoveNext();
            }
        }

        foreach ($results as $key => $value) {
            $value['label'] = ucwords(join(" ",explode("_",$value['label'])));
            // $value["collected"] = 0;
            array_push($data, $value);
        }

        return $data;
    }

    public static function getDates()
    {
        return [date('Y-m-d'), date('Y-m-d')];
    }
}
