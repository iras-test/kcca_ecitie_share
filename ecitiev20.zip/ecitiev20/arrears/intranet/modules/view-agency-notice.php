<?php

/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

$agency_notice_context = [];

$agency_notice_id_Provided = KRequest::getQueryString("id", null);
$format = KRequest::getQueryString("format", "html");
$util = new Util();

if ($format == "json") {
    header("Content-type: application/json");
    AuthWrapper::getAuthenticatedUser();
}
$current_user = KSecurity::getUserID();
$current_user_profile = UserManager::getProfile($current_user);

$agency_notice_obj = null;

if ($agency_notice_id_Provided) {

    $agency_notice_obj = AgencyNoticeManager::getCaseAgencyNoticeActionByID($agency_notice_id_Provided);
} else {

    KSecurity::setActionWarning("Agency notice must be provided");
}


if ($agency_notice_obj) {

    $case_id = $agency_notice_obj->arrears_case_id;
    $info  = (object) ArrearCase::getItem($case_id);
    $case_status = ($info->status == null) ? ArrearStatus::OPEN : $info->status;
    $bal = abs($info->arrear_amount);
    $active_assignment = ArrearCase::getCaseAssignments($info->id);
    $business_details = ArrearsManager::getBusinessDetails($info->ref_name, $info->ref_id);

    $extra_details = "";

    if ($info->ref_name == "vehicle") {
        $extra_details .= "<div class=\"pt10\">
                            <strong><span class=\"bs-bold\">Park</span></strong>: {$business_details->park_name}
                        </div>
                        <div class=\"pt10\">
                            <strong><span class=\"bs-bold\">Stage</span></strong>: {$business_details->stage_name}
                        </div>
                        ";
    }

    $info_display = "
        <div class=\"clear customer-blocks pb10\">
            <h1 class=\"kfw-active-title\"><strong>[lang-arrears-case-details]<strong></h1>
            <div class=\"clear pt10\">
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Customer</span></strong>: {$info->customer}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">COIN</span></strong>: {$info->coin}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Revenue name</span></strong>: {$info->revenue_name}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Branch Code</span></strong>: {$business_details->branch_code}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Location</span></strong>: {$business_details->location}
                </div>
                {$extra_details}
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Outstanding balance</span></strong>: {$bal}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Case Status</span></strong>: <span class=\"{$util::StatusClass($case_status)}\">{$case_status}</span>
                </div>
            </div>
        </div>
    ";

    $agency_notice_context["case_id"] = $case_id;
    if ($format != "json"){
        
        $agency_notice_context["info_display"] = $info_display;

    }else {

        $agency_notice_context['customer'] = $info->customer;
        $agency_notice_context['revenue_type'] = $info->revenue_name;
        $agency_notice_context['out_balance'] = $bal;

    }
    $agency_notice_context["pp_id"] = $agency_notice_obj->id;
    $agency_notice_context["reason"] = $agency_notice_obj->issue_reason;
    $agency_notice_context["status"] = $agency_notice_obj->agency_notice_status == 1 ? "Issued"
        : ($agency_notice_obj->agency_notice_status == AgencyNoticeManager::STATUS_APPROVE
            ? "Approved" : ($agency_notice_obj->agency_notice_status == AgencyNoticeManager::STATUS_CLOSE
                ? "Closed" : ($agency_notice_obj->agency_notice_status == AgencyNoticeManager::STATUS_REJECT ? "Rejected" : "Objected")
            )
        );

    $created_by = UserManager::getProfile($agency_notice_obj->created_by);

    $agency_notice_context["created_by"] = "{$created_by->firstname} {$created_by->surname}";

    $agents_info = json_decode($agency_notice_obj->agents_info);
    $records = "";

    if ($format == "json") {
        $agency_notice_context['agents_info'] = $agents_info;
        echo json_encode([
            "notice_details" => $agency_notice_context,
            "status" => 200,
        ]);
        exit;
    }

    foreach ($agents_info as $index => $agent) {

        $class = ($index % 2 == 0) ? ' odd' : ' even';
        $record_number = ($index + 1);
        $agent_obj = (object)$agent;
        $preview_url = "{$this->urlPath(0)}agency-notice-preview/?id={$agency_notice_obj->id}&t={$index}";
        $records .= "<div class=\"clear list-item{$class}\">";
        $records .= "\n\t\t\t<div class=\"fl numbering-col\">{$record_number}</div>";
        $records .= "\n\t\t\t<div class=\"fl arrears-col\">{$agent_obj->name}</div>";
        $records .= "\n\t\t\t<div class=\"fl arrears-col\">{$agent_obj->email}</div>";
        $records .= "\n\t\t\t<div class=\"fl arrears-col\">{$agent_obj->phone_no}</div>";
        $records .= "\n\t\t\t<div class=\"fl arrears-col\"><a href=\"{$preview_url}\">Preview / Print</a></div>";
        $records .= "\n\t\t</div>";
    }

    $approval_form_identifier = "mykfwform-{$this->getComponent()}-{$this->getModule()}";
    $agency_notice_context['records'] = $records;
    $agency_notice_context['form_action'] = "{$this->urlPath(0)}agency-notice-approval-action";
    $agency_notice_context['form_identifier'] = $approval_form_identifier;
    $agency_notice_context['back_url'] = KSecurity::getSession('BACK_URL');

    $approval_action = "";
    if ($agency_notice_obj->agency_notice_status == 1) {

        if (
            (($active_assignment != null) && ($active_assignment->user_id == $current_user)) // case has been escalated to user
            ||
            ($current_user_profile->user_role_id == ArrearStatus::ARREARS_MANAGER_ROLE) // user is SAM
        ){
            $approval_action = "<input type=\"submit\" name=\"approval_action\" class=\"finish\" value=\"Approve Notice\" onclick=\"approve()\" />";

            $approval_action .= "<input type=\"submit\" name=\"approval_action\" class=\"cancel\" value=\"Reject Notice\" onclick=\"reject_notice()\" />";
        }
    }

    if ($agency_notice_obj->agency_notice_status == AgencyNoticeManager::STATUS_APPROVE || $agency_notice_obj->agency_notice_status == AgencyNoticeManager::STATUS_REJECT) {
        $approval_action = "<input type=\"submit\" name=\"approval_action\" class=\"cancel\" value=\"Close Notice\" onclick=\"close_notice()\" />";
    }

    $reject_details = "";

    // has reject details
    if ($agency_notice_obj->reason!=null) {
        $reject_details = " <h1 class=\"kfw-active-title pt10\"><strong>Reject Details</strong></h1> <div class=\"clear\">
                <div class=\"field pt10\">
                    <label><strong>Reject Reason</strong></label>
                </div>
                <div class=\"data pt10\">
                    <span>$agency_notice_obj->reason</span>
                </div>
        </div>";
        $reject_details .= "<div class=\"clear\">
                <div class=\"field pt10\">
                    <label><strong>Reject Comment</strong></label>
                </div>
                <div class=\"data pt10\">
                    <span>$agency_notice_obj->comment</span>
                </div>
        </div>";
    }

    $approval_js = "<script type=\"text/javascript\">

                        let reject_open = false;
                        function approve(){
                            document.getElementById(\"{$approval_form_identifier}-yes\").submit()
                        }
                        function object_notice(){
                            document.getElementById(\"{$approval_form_identifier}-no\").submit()
                        }

                        function close_notice(){
                            document.getElementById(\"{$approval_form_identifier}-close\").submit()
                        }

                        function reject_notice(){
                            if(!reject_open){
                                document.getElementById(\"{$approval_form_identifier}-reject\").style.display = '';
                            }else{
                                document.getElementById(\"{$approval_form_identifier}-reject\").style.display = 'none';
                            }
                            reject_open = !reject_open
                        }
                    </script>";

    $agency_notice_context["approval_js"] = $approval_js;
    $agency_notice_context["approval_action"] = $approval_action;
    $agency_notice_context["reject_details"] = $reject_details;
    

    return $this->render($agency_notice_context);
}

if ($format == "json") {
    echo json_encode([
        "message" => "failed to get agency notice detials",
        "status" => 400,
    ]);
    exit;
}
$this->stopRedirector(KSecurity::getSession('BACK_URL'));
