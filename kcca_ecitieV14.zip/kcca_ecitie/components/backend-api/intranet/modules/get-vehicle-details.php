<?php
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

header("Content-type: application/json");

$business_id = KRequest::getQueryString("business_id", null);
$instance = KetrouteApplication::instance();
$vehicle_details = null;
try {
    $vehicle_details = $instance->database()->load('vehicle', array(
        'id' => $business_id
    ));
} catch (Exception $e) {
}

if ($vehicle_details) {

    try {
        $vehicle_details->customer = $this->runtime()->getFieldData('customer_id', (array)$vehicle_details);
    } catch (\Exception $th) {
        $vehicle_details->customer = "";
    }

    try {
        $vehicle_details->division_id = $instance->db()->load($table = 'division', $where = array('id' => $vehicle_details->division_id));
    } catch (\Exception $th) {
        $vehicle_details->division_id = "";
    }

    try {
        $vehicle_details->park_id = $instance->db()->load($table = 'park', $where = array('id' => $vehicle_details->park_id));
    } catch (\Exception $th) {
        $vehicle_details->park_id = "";
    }



    try {
        $vehicle_details->vehicle_operation_type_id = $instance->db()->load($table = 'vehicle_operation_type', $where = array('id' => $vehicle_details->vehicle_operation_type_id));
    } catch (\Exception $th) {
        $vehicle_details->vehicle_operation_type_id = "";
    }

    try {
        $vehicle_details->city_id = $instance->db()->load($table = 'city', $where = array('id' => $vehicle_details->city_id));
    } catch (\Exception $th) {
        $vehicle_details->city_id = "";
    }

    try {
        $vehicle_details->stage_id = $instance->db()->load($table = 'stage', $where = array('id' => $vehicle_details->stage_id));
    } catch (\Exception $th) {
        $vehicle_details->stage_id = "";
    }

    try {
        $vehicle_details->validity_status = $instance->db()->load($table = 'status', $where = array('id' => $vehicle_details->status_id));
    } catch (\Exception $th) {
        $vehicle_details->validity_status = "";
    }
}

echo json_encode(["details" => $vehicle_details, "status" => 200]);

exit;
