<?php

/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin


$payment_plan_id = KRequest::getQueryString("payment_plan", null);
$payment_period = KRequest::getQueryString("payment_period", null);


if ($payment_period && $payment_plan_id) {

    $payment_plan = PaymnentPlanManager::getPaymentPlanByID($payment_plan_id);
    $payment_plan_arrear_case = ArrearCase::getArrearCaseByID($payment_plan->arrears_case_id);
    $customer_obj = CustomerManager::getCustomerbyID($payment_plan_arrear_case->customer_id);

    //form prefix
    $form_detail_prefix             = 'choose_coin_';

    //Reload session data
    $arrSessionData = KSecurity::getSession('PAYMENT-REGISTRATION');
    $arrFormData     = array();
    $arrData = array('coin' => $customer_obj->coin);
    $arrFormData[$form_detail_prefix] = $arrData;

    //manage session
    $arrSessionData['choose-coin']                         = $arrFormData;
    $arrSessionData['choose-coin']['validated']         = true;
    $arrSessionData['choose-coin']['cid']                = $this->database()->hasDuplicate('customer', array('coin' => $arrFormData[$form_detail_prefix]['coin']), null, 'id');

    $arrSessionData['payment_plan']['payment_period'] = $payment_period;

    // clear other tabs data where applicable
    if (isset($arrSessionData['revenue-source'])) {
        unset($arrSessionData['revenue-source']);
    }
    if (isset($arrSessionData['collecting-agent'])) {
        unset($arrSessionData['collecting-agent']);
    }
    if (isset($arrSessionData['confirmation'])) {
        unset($arrSessionData['confirmation']);
    }

    KSecurity::setSession('PAYMENT-REGISTRATION', $arrSessionData);

    // response with the redirector rule
    $this->stopRedirector("{$this->relativeUrl()}payment/register-payment/choose-coin#revenue-source");
} else {

    $this->stopRedirector(KSecurity::getSession('BACK_URL'));
}
