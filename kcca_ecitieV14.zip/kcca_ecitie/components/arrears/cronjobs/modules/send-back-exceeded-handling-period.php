
<?php

(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
set_time_limit(0);

// run daily

$instance = KetrouteApplication::instance();

print("checking for exceeded handling days: \n");

$cases_handling_periods = $instance->db()->getList(
    "case_assignment_period",
    $where = array('active' => 1),
    $fields = '*',
    $pager_info = null,
    $where_in = null,
    $likeforlike_binding = null,
    $startwith_binding = null,
    $endwith_binding = null,
    $hasatleast_binding = null,
    $greaterthanequal_binding = null,
    $lessthanequal_binding = null,
    $between_binding = null,
    $year_binding = null,
    $order_ascending = 'created_date'
);

$biz_count = 0;

foreach ($cases_handling_periods as $index => $handling_period) {

    print("$biz_count : checking expiry... \n");

    $date = new DateTime();
    $period = ($handling_period->period + 1);
    $expiry_date = $date->modify("-{$period} day")->format('Y-m-d');

    $case = ArrearCase::getArrearCaseByID($handling_period->arrears_case_id);

    if (
        ($expiry_date == $handling_period->created_date)
        &&
        ($case->status == ArrearStatus::ASSIGNED)
        &&
        ($case->assignee == $handling_period->assignee)
    ) {

        print("$biz_count: updating case details");
        $SAM_USER = ArrearsManager::getOfficers(ArrearStatus::ARREARS_MANAGER_ROLE);
        if (count($SAM_USER) > 0) {
            $SAM_USER = $SAM_USER[0];
        } else {
            $SAM_USER = null;
        }

        if ($SAM_USER) {

            $comment = "Exceeded Handling Period";

            ArrearCase::updateStatus($case->id, ArrearStatus::SENT_BACK, $comment, $SAM_USER->id);

            // Send back
            $instance->database()->createRecord(
                'arrear_case_send_back',
                array(
                    "arrear_case_id"    =>  $case->id,
                    "comment"           =>  $comment,
                    "created_by"        =>  null
                ),
                array('created_date' => KetrouteApplication::db()->getNowExpression())
            );
        }
    }
    $biz_count++;
}
