<?php

class ArrearsDocumentManager {
    public static function createCSV($filename, $labels, $data){
        // create the temporary file
		$temp = fopen($filename, 'w');
		
		// set header
		fputcsv($temp,$labels);
				
		// records
		foreach($data as $entry){
			// add data
			$record = array();
			// apply html special chars on data
			foreach($entry as $value){
                $record[] = htmlspecialchars($value);
            }
			fputcsv($temp, $record);		
		}

        return chunk_split(base64_encode(stream_get_contents($temp)));
    }
}