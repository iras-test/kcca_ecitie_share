USE ecitie;

ALTER TABLE [dbo].[report_modules] ADD [status] [smallint] NOT NULL DEFAULT 1
