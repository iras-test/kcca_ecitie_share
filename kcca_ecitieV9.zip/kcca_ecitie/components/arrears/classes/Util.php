<?php

class Util
{
    function tableLabel($table)
    {
        switch ($table) {
            case "vehicle":
                return "number_plate";

            default:
                throw new ErrorException("Table $table is not configured in Util.php");
        }
    }

    public static function filterInput($type, $title, $name, $default_value = "", $options = null)
    {
        switch ($type) {
            case "text":
                $input = "
                    <input
                        name=\"$name\" 
                        type=\"$type\"
                        style=\"width:175px!important;\" 
                        id=\"group-filter-$name\"
                        placeholder=$title
                        value=\"$default_value\"
                    />
                ";
                return self::container($title, $input);

            case "date":
                $input = "
                    <input
                        name=\"$name\" 
                        type=\"$type\"
                        style=\"width:175px!important; padding: 5px;\" 
                        id=\"group-filter-$name\"
                        placeholder=$title
                        value=\"$default_value\"
                    />
                ";
                return self::container($title, $input);

            case "number":
                $input = "
                    <input
                        name=\"$name\" 
                        type=\"$type\"
                        style=\"width:175px!important; padding: 5px;\" 
                        id=\"group-filter-$name\"
                        placeholder=$title
                        value=\"$default_value\"
                    />
                ";
                return self::container($title, $input);

            case "select":
                $options = self::buildOptions(
                    $options['data'],
                    $options['id'],
                    $options['label'],
                    $options['placeholder'],
                    $default_value
                );
                $select = "
                    <select 
                        name=\"$name\" 
                        style=\"width:175px!important; padding: 5px;\" 
                        id=\"group-filter-$name\"
                        placeholder=$title
                    >
                        $options
                    </select>
                ";
                return self::container($title, $select);

            default:
                return null;
        }
    }

    public static function container($title, $children)
    {
        return "
            <div class=\"fl group-filter pt10 pr10\" title=\"Filter By: $title\">
                <div class=\"fl pr10 icon-holder\">
                    <img src=\"" . KFW_IMAGES_URL . "/objects/filter.png\" alt=\"Filter By\" class=\"icor\"/>
                </div>
                <div class=\"fl pr10\" style=\"width:160px!important;\">
                    $children
                </div>
            </div>
        ";
    }

    public static function buildOptions($data, $id, $label, $placeholder, $default_value)
    {
        $options = "<option value>$placeholder</option>";
        foreach ($data as $value) {
            $id = $value["id"];
            $label = $value["name"];
            $options .= ($id == $default_value)
                ? "<option value=\"$id\" selected>$label</option>"
                : "<option value=\"$id\" >$label</option>";
        }

        return $options;
    }

    /** Build options from an object */
    public static function buildObjectOptions($data, $id, $label, $placeholder, $default_value)
    {
        $options = "<option value>$placeholder</option>";
        foreach ($data as $value) {
            $id = $value->id;
            $label = $value->name;
            $options .= ($id == $default_value)
                ? "<option value=\"$id\" selected>$label</option>"
                : "<option value=\"$id\" >$label</option>";
        }

        return $options;
    }

    public static function formContainer($id, $action, $children)
    {
        return "
            <div id=\"kfw-filters\" class=\"clear kfw-filters\">
                <form 
                    method=\"get\"
                    id=\"form-filter-$id\" 
                    action=\"$action\"
                >
                    $children

                    <div class=\"fl group-filter-search\" title=\"Search\">
                        <div class=\"fl pr10 search-holder\">
                            <input 
                                type=\"submit\" 
                                class=\"search\" 
                                src=\"" . KFW_IMAGES_URL . "/objects/filter.png\" 
                                alt=\"Search\" 
                                value=\" Search \"
                            />
                        </div>
                    </div>
                </form>
            </div>
        ";
    }

    public static function StatusClass($status)
    {
        switch ($status) {
            case ArrearStatus::OPEN:
                return "arr-text-orange";

            case ArrearStatus::CLOSED:
                return "arr-text-green";

            default:
                return "";
        }
    }

    public static function getLegalHistory($case_id)
    {
        $legal_actions = "";
        $_LEGAL_ACTIONS = LegalManager::getActionsByCase($case_id);
        if (count($_LEGAL_ACTIONS) > 0) {
            foreach ($_LEGAL_ACTIONS as $index => $value) {
                # code...
                $class = ($index % 2 == 0) ? ' odd' : ' even';
                $record_number = $index + 1;

                $action_date = date('Y-m-d', strtotime($value->action_date));
                $created_date = date('Y-m-d', strtotime($value->created_date));
                $legal_action = LegalManager::getTypeName($value->legal_action);

                $legal_actions .= "<div class=\"clear list-item{$class}\">";
                $legal_actions .= "\n\t\t\t<div class=\"fl numbering-col\">{$record_number}</div>";
                $legal_actions .= "\n\t\t\t<div class=\"fl col8\">{$created_date}</div>";
                $legal_actions .= "\n\t\t\t<div class=\"fl col10\">{$legal_action}</div>";
                $legal_actions .= "\n\t\t\t<div class=\"fl col10\">{$value->description}</div>";
                $legal_actions .= "\n\t\t\t<div class=\"fl col10\">{$action_date}</div>";
                $legal_actions .= "\n\t\t\t<div class=\"fl col10\">{$value->action_taken_by}</div>";
                if ($value->document_sysname) {
                    $legal_actions .= "\n\t\t\t<div class=\"fl col10\">
                        <a href=\"[link_in_use]arrears/litigation-details/case/$case_id/download/ackn/id/{$value->id}\">Download</a>
                    </div>";
                } else {
                    $legal_actions .= "\n\t\t\t<div class=\"fl col10\">N/A</div>";
                }

                if ($value->mou_document_sysname) {
                    $legal_actions .= "\n\t\t\t<div class=\"fl col10\">
                        <a href=\"[link_in_use]arrears/litigation-details/case/$case_id/download/mou/id/{$value->id}\">Download</a>
                    </div>";
                } else {
                    $legal_actions .= "\n\t\t\t<div class=\"fl col10\">N/A</div>";
                }

                // Add response if action is intention to sue
                if ($legal_action == ArrearStatus::INTENTION_TO_SUE) {
                    $legal_actions .= "\n\t\t\t<div class=\"fl col8\">
                        <a href=\"[link_in_use]arrears/legal-action/id/{$value->id}/response\" class=\"bsd-response\">Response</a>
                    </div>";
                } else {
                    $legal_actions .= "N/A";
                }

                $legal_actions .= "\n\t\t</div>";
            }
        } else {
            $legal_actions  = "\n\t\t<div class=\"clear list-item\">" . "No legal action" . "</div>";
        }

        return $legal_actions;
    }

    public static function getActionResponses($legal_action_id)
    {
        $legal_response = "";
        $responses = LegalManager::getLegalResponses($legal_action_id);
        if (count($responses) > 0) {
            foreach ($responses as $index => $value) {
                # code...
                $class = ($index % 2 == 0) ? ' odd' : ' even';
                $record_number = $index + 1;

                $created_date = date('Y-m-d', strtotime($value->created_date));

                $legal_response .= "<div class=\"clear list-item{$class}\">";
                $legal_response .= "\n\t\t\t<div class=\"fl numbering-col\">{$record_number}</div>";
                $legal_response .= "\n\t\t\t<div class=\"fl col10\">{$created_date}</div>";
                $legal_response .= "\n\t\t\t<div class=\"fl col20\">{$value->description}</div>";
                if ($value->document_sysname) {
                    $legal_response .= "\n\t\t\t<div class=\"fl col10\">
                        <a href=\"[link_in_use]arrears/legal-action/response/{$value->id}/download/doc\">Download</a>
                    </div>";
                } else {
                    $legal_response .= "\n\t\t\t<div class=\"fl col10\">N/A</div>";
                }

                $legal_response .= "\n\t\t</div>";
            }
        } else {
            $legal_response  = "\n\t\t<div class=\"clear list-item text-center\">" . "No previous response" . "</div>";
        }

        return $legal_response;
    }

    public static function sendBack($case_id, $role, $redirect)
    {
        return "
           <div style=\"margin-top: 20px;\">
            <form method=\"post\" enctype=\"multipart/form-data\" action=\"[link_in_use]arrears/send-back-case/case/$case_id/redirect/$redirect?role=$role\">
                    <h1 class=\"kfw-active-title pt10\"><strong>Send Back to $role<strong></h1>

                    <div class=\"clear inputboxes\">
                        <div class=\"field\">
                            <label for=\"comment\">
                                <span title=\"This field is required\" class=\"required\"> *</span>
                                <strong>Comment:</strong>
                            </label>
                        </div>
                        <div class=\"data\">
                            <textarea rows=\"2\" columns=\"2\" name=\"comment\"  id=\"comment\" required></textarea>
                        </div>
                    </div>
                
                    <div class=\"clear inputboxes\">
                        <div class=\"field\"></div>	
                        <div class=\"data\">
                            <input type=\"submit\" name=\"Send Back\" title=\"Send Back\" class=\"finish\" value=\"Send Back\" />	
                        </div>							
                    </div>
                </form>
            </div>
        ";
    }

    public static function sendBackToOfficer($case_id, $role, $redirect)
    {
        $orc_options = "";
        $officer_role = ArrearStatus::ARREARS_OFFICER_ROLE;
        if ($role == ArrearStatus::MAI) {

            $officer_role = ArrearStatus::MANAGER_AUDIT_AND_INSPECTION;

        }else if ($role == ArrearStatus::ARREARS_MANAGER_ROLE) {

            $officer_role = ArrearStatus::ARREARS_MANAGER_ROLE;

        }else if ($role == ArrearStatus::SUPERVISOR_REVENUE_COLLECTION) {

            $officer_role = ArrearStatus::SUPERVISOR_REVENUE_COLLECTION;

        }
        
        $officers = ArrearsManager::getOfficers($officer_role);
        foreach ($officers as $key => $value) {
            $orc_options .= "<option value=\"$value->id\">{$value->surname} {$value->firstname}</option>";
        }

        return "
           <div style=\"margin-top: 20px;\">
            <form method=\"post\" enctype=\"multipart/form-data\" action=\"[link_in_use]arrears/send-back-case/case/$case_id/redirect/$redirect?role=$role\">

                    <div class=\"clear pt10\">
                            <p class=\"kfw-active-title pt10\"><strong>Send Back Case<strong></p>
                    </div>

                    <div class=\"clear inputboxes\">
                        <div class=\"field\">
                            <label for=\"Officers\">
                                <span title=\"This field is required\" class=\"required\"> *</span>
                                <strong>Officer:</strong>
                            </label>
                        </div>
                        <div class=\"data\">
                            <select name=\"assignee\">
                                $orc_options
                            </select>
                        </div>
                    </div>

                    <div class=\"clear inputboxes\">
                        <div class=\"field\">
                            <label for=\"comment\">
                                <span title=\"This field is required\" class=\"required\"> *</span>
                                <strong>Comment:</strong>
                            </label>
                        </div>
                        <div class=\"data\">
                            <textarea rows=\"2\" columns=\"2\" name=\"comment\"  id=\"comment\" required></textarea>
                        </div>
                    </div>
                
                    <div class=\"clear inputboxes\">
                        <div class=\"field\"></div>	
                        <div class=\"data\">
                            <input type=\"submit\" name=\"Send Back\" title=\"Send Back\" class=\"finish\" value=\"Send Back\" />	
                        </div>							
                    </div>
                </form>
            </div>
        ";
    }

    public static function closeCaseForm()
    {
        return "<div class=\"clear pt10\">
                <input type=\"button\" class=\"cancel\" onclick=\"show_close_form()\" value=\"Close Arrear\">
            </div>
            <form style=\"display:none;\" class=\"pt10 hide\" method=\"post\" id=\"close-case-form\" name=\"close-case\" enctype=\"multipart/form-data\" [close_url]>	
                <input type=\"hidden\" value=\"[arrear_case_id]\" name=\"arrear_case_id\" />
                <div>
                    <label><strong>Reason</strong></label>
                    <div class=\"clear pt10\">
                        <textarea rows=\"5\" name=\"close_reason\" required placeholder=\"Reason For Closing Arrear\"></textarea>
                    </div>
                </div>
                <div class=\"clear pt10\">
                    <button type=\"submit\" class=\"submit\">Submit</button>
                </div>
            </form>";
    }
}
