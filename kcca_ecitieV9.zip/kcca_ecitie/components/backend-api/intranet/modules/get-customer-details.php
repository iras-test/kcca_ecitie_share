<?php
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

header("Content-type: application/json");

$coin = KRequest::getQueryString("coin", null);
$customer = CustomerManager::getCustomerbyCOIN($coin);
$instance = KetrouteApplication::instance();

if ($customer != null) {
    try {
        $customer->residential_address_district_id = $instance->db()->load($table = 'district', $where = array('id' => $customer->residential_address_district_id));
    } catch (\Exception $th) {
    }

    try {
        $customer->residential_address_county_id = $instance->db()->load($table = 'county', $where = array('id' => $customer->residential_address_county_id));
    } catch (\Exception $th) {
    }

    try {
        $customer->residential_address_sub_county_id = $instance->db()->load($table = 'sub_county', $where = array('id' => $customer->residential_address_sub_county_id));
    } catch (\Exception $th) {
    }

    try {
        $customer->residential_address_parish_id = $instance->db()->load($table = 'parish', $where = array('id' => $customer->residential_address_parish_id));
    } catch (\Exception $th) {
    }

    try {
        $customer->residential_address_village_id = $instance->db()->load($table = 'village', $where = array('id' => $customer->residential_address_village_id));
    } catch (\Exception $th) {
    }

    try {
        $customer->previous_business_address_district_id = $instance->db()->load($table = 'district', $where = array('id' => $customer->previous_business_address_district_id));
    } catch (\Exception $th) {
    }

    try {
        $customer->previous_business_address_county_id = $instance->db()->load($table = 'county', $where = array('id' => $customer->previous_business_address_county_id));
    } catch (\Exception $th) {
    }

    try {
        $customer->previous_business_address_sub_county_id = $instance->db()->load($table = 'sub_county', $where = array('id' => $customer->previous_business_address_sub_county_id));
    } catch (\Exception $th) {
    }

    try {
        $customer->previous_business_address_parish_id = $instance->db()->load($table = 'parish', $where = array('id' => $customer->previous_business_address_parish_id));
    } catch (\Exception $th) {
    }

    try {
        $customer->previous_business_address_village_id = $instance->db()->load($table = 'village', $where = array('id' => $customer->previous_business_address_village_id));
    } catch (\Exception $th) {
    }

    try {
        $customer->customer_applicant_type_id = $instance->db()->load($table = 'customer_applicant_type', $where = array('id' => $customer->customer_applicant_type_id));
    } catch (\Exception $th) {
    }

    try {
        $customer->customer_business_type_id = $instance->db()->load($table = 'customer_business_type', $where = array('id' => $customer->customer_business_type_id));
    } catch (\Exception $th) {
    }
}

echo json_encode(["customer" => $customer,"status" => 200]);

exit;
