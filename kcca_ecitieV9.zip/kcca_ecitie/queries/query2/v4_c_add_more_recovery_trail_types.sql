use ecitie;

INSERT INTO recovery_type
(name)
VALUES
('Meeting')

INSERT INTO recovery_type
(name)
VALUES
('Message')

INSERT INTO recovery_type
(name)
VALUES
('Email')