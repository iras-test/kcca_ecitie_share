
use ecitie;

CREATE TABLE [dbo].[recovery_trail] (
    id INT IDENTITY(1,1) NOT NULL,
    arrear_case_id INT NOT NULL,
    attachment VARCHAR(1000) NOT NULL,
    recovery_type_id SMALLINT NOT NULL,
    status_id SMALLINT DEFAULT 1,
    modified_by INT NULL,
    modified_date DATETIME2(0) NULL
)
