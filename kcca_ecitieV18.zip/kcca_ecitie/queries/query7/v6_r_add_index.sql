use ecitie;

CREATE INDEX financial_year_index ON [dbo].[payment_bill] (financial_year)