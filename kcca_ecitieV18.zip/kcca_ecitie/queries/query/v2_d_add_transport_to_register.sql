
use ecitie;

update [dbo].[component]  set permissions = 'list,transport', module_permission_map = 'list:list' where title = 'arrears-register'