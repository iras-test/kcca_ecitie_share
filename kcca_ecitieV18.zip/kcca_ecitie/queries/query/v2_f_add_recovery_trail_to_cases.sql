
use ecitie;

update [dbo].[component]  set permissions = 'cases,action,close-case,create-payment-plan,payment-plan-list,view-payment-plan,payment-plan-approval-action,create-agency-notice,view-agency-notice,create-business-seal,agency-notice-preview,agency-notice-approval-action,view-business-seal,case-details,escalate-case,add-recovery-trail,recovery-trail-list', module_permission_map = '' where title = 'arrears'
update [dbo].[component]  set blocked_dptm = 'action,close-case,create-payment-plan,view-payment-plan,payment-plan-approval-action,create-agency-notice,view-agency-notice,create-business-seal,agency-notice-preview,agency-notice-approval-action,view-business-seal,case-details,escalate-case,add-recovery-trail' where title = 'arrears'
