<?php
/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');


set_time_limit(0);

ini_set("memory_limit","512M");

echo "\n--begin--: ".__FILE__;
try{
	
	// set start time	
	$strStartTime		= date('h:i:s A');
	
	// set start microtime	
	$strStartMicrotime = microtime(true);
	
	// overwrite the start date if the one supplied
	$strStartCreditDate = date('2017-08-25');
	
	//greater than constraints
	$arrgreater = array('id' => 1857052);	
				
	// get all list of active paymmets that are not reconciliation with RMS
	//$arrAvailableTransactions 	= $this->database()->getStandardObject('payment', array('status_id'=> KStatus::ACTIVE, 'registration_status' => PaymentManager::REGISTRATION_STATUS_AVAILABLE, ), $fields = '*', $one_record = false, $index_field_for_multiple_results = 'id', $pager_info = null, $where_in = null, $likeforlike_binding = null, $startwith_binding = null, $endwith_binding = null, $hasatleast_binding = null, $greaterthanequal_binding = $arrgreater, $lessthanequal_binding = null, $between_binding = null, $year_binding = null, $order_ascending = null, $order_descending = null, $distinct = null, $group_by = null, $ignore_fields = array());
	$arrAvailableTransactions 	= $this->database()->getStandardObject('payment', array('prn'=>'2210001172708','status_id'=> KStatus::ACTIVE, 'registration_status' => PaymentManager::REGISTRATION_STATUS_AVAILABLE, ), $fields = '*', $one_record = false, $index_field_for_multiple_results = 'id', $pager_info = null, $where_in = null, $likeforlike_binding = null, $startwith_binding = null, $endwith_binding = null, $hasatleast_binding = null, $greaterthanequal_binding = $arrgreater, $lessthanequal_binding = null, $between_binding = null, $year_binding = null, $order_ascending = null, $order_descending = null, $distinct = null, $group_by = null, $ignore_fields = array());
				
	// set the current customer id to zero
	$current_customer_id 	= 0;
						
	foreach($arrAvailableTransactions as $objAvailableTransaction){
		
		try{
			//Get the prn.
			$prn 			= $objAvailableTransaction->prn;
			$customer_id 	= $objAvailableTransaction->customer_id;
			$payment_id 	= $objAvailableTransaction->id;
			
			//echo "\n-- ".$prn;
			
			//connect to URA for the prns.
			$arrURAPRN = PaymentManager::CheckURAPRNStatus($customer_id, $prn);	
			
			kresponse::trace($arrURAPRN);
			exit;
							
			$status_code = $arrURAPRN['status_code'];		
			$status_desc = $arrURAPRN['status_desc'];
				
			//echo "\n-- ".$status_code." ".$status_desc; 
					
			if($arrURAPRN['error_code'] == PaymentManager::URA_RECEIVED_AND_CREDITED_STATUS_CODE && $arrURAPRN['status_code'] == PaymentManager::URA_RECEIVED_AND_CREDITED_STATUS_CODE){
							
				// update customer if customer id is different from the previously processed vehicle's customer id
				if($current_customer_id != 0 && $current_customer_id != $objAvailableTransaction->customer_id){
					// update customer balance
					CustomerManager::getCustomerBalance($current_customer_id);
				}
																		
				// run the transaction payment update	
				PaymentManager::runURAPaymentUpdate($objAvailableTransaction, $arrURAPRN);
				try {
					
					NotificationManager::notifyOnPayment($prn);

				} catch (\Throwable $th) {
					
				}	
				//echo "\n-- ".$prn;
				//echo $ex;
			
				// update current customer id
				$current_customer_id = $objAvailableTransaction->customer_id;	
			}	
			else if($arrURAPRN['status_code'] == PaymentManager::REGISTRATION_STATUS_EXPIRED){
					
				// update payment expire status	
				//PaymentManager::updateExpiresPaymentFromURA($payment_id);
			}
		}catch(Exception $ex){
			
			//echo $ex;
			continue;
		}			
	}	
		
	// set total records processed
	$intAvailableTransactions 	= count($arrAvailableTransactions);
	
	// set script name
	$strScriptName 		= KFile::getFilename(__FILE__);
		
	// set end time
	$strEndTime			= date('h:i:s A');
	
	// set start microtime	
	$strEndMicrotime = microtime(true);
	
	echo "\n--end--: ".__FILE__;
	
	// custom header
  	$arrEmailHeaders 	 = array();
  	$arrEmailHeaders[]   = "X-KF-uid:NA";
  	$arrEmailHeaders[]   = "X-KF-Domain:".KRequest::getDomainName();
  	$arrEmailHeaders[]   = 'X-KF-Component:payment';
  	$arrEmailHeaders[]   = 'X-KF-Process:{$strScriptName}';	

	// send email notification to admin
	CmsEmailManager::sendEmail('system-automated-process', 
								array(  'email' => array('itstaff@kcca.go.ug' => 'IT Support: eCitie'), 
										'tags'  => array(
															'process_name' 			=> 'URA payment update on ecitie Transaction Trigger',
															'script_name'   		=> $strScriptName,
															'datetime'   			=> KDate::getFriendlyDateTime(),
															'start_time'   			=> $strStartTime,
															'end_time'   			=> $strEndTime,
															'time_spend'   			=> number_format(( $strEndMicrotime - $strStartMicrotime), 4) . '  Seconds',
															'application'   		=> KRequest::getDomainName(),
															'database'   			=> KSystem::dBHost() . ' / ' . KSystem::dBName(),
															'data'   				=> "{$intAvailableTransactions} Transaction(s)",
															'details'				=> 'Update all the pending prns on ecitie from e-tax system at every 5 minutes.'
														)
										),
									$arrEmailHeaders, $attachments = null, $lang = null, $owner = 1, $queue = null
								);									
	}
	catch(Exception $e)
	{
		// do notiing with errors
		$this->captureErrorLog(null,ErrorLogManager::ERROR_TYPE_EXCEPTION,'Failed to run:Update Pending prns on ecitie from e-tax system',print_r($e->getMessage(), true));
	}
	echo "\n--end--";