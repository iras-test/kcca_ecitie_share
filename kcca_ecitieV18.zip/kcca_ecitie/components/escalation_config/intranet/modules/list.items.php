<?php
/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin
		
		$results_html_items = '';		
		$strComponentRealname	= $this->getComponentRealname();
					
		
		$user_id		= KSecurity::getUserID();
		
		$intIgnoreID 	= $this->runtime()->getIgnoredID();
		$strParentUrl	= $this->urlPath(0);
		
		
		
		// show record	
		foreach ($result_list['results'] as $index => $arrData){
			
			//kresponse::trace($result_list['results']);
			//exit;
			
			$strPrimaryKey = $this->runtime()->getPrimaryKey();
			
			$class = ($index % 2 == 0) ? ' odd' : ' even';
			
			if($_page > 1)
			{
				$record_number = ($index+1)+($MAX_PER_PAGE*($_page-1));
			}
			else
			{
				$record_number = ($index+1);
			}
			
			$list_counter++;			
			// // convert to object
			$objmoduleConfig = (object)$arrData;
			// $report_module_name = ReportsApiManager::getReportModuleFieldValue("id",$objmoduleConfig->report_module_id,"name");
			$role_name = KetrouteApplication::db()->getStaticTableValue("user_role", "id", "name", $objmoduleConfig->role_id);;		
			$results_html_items .= "\n\t\t<div class=\"clear list-item{$class}\">";			
			$results_html_items .= "\n\t\t\t<div class=\"fl numbering-col\">{$record_number}</div>";
			
			$results_html_items .= "\n\t\t\t<div class=\"fl customers-col\"><a title=\"[lang-{$strComponentRealname}-view]\" href=\"[link_in_use]{$strComponentRealname}/view/id/{$objmoduleConfig->id}/\">{$objmoduleConfig->name}</a></div>";
			$results_html_items .= "\n\t\t\t<div class=\"fl customers-col\"><a title=\"[lang-{$strComponentRealname}-view]\" href=\"[link_in_use]{$strComponentRealname}/view/id/{$objmoduleConfig->id}/\">{$role_name}</a></div>";
			$results_html_items .= "\n\t\t\t<div class=\"fl customers-col\"><a title=\"[lang-{$strComponentRealname}-view]\" href=\"[link_in_use]{$strComponentRealname}/view/id/{$objmoduleConfig->id}/\">{$objmoduleConfig->level}</a></div>";
			$results_html_items .= "\n\t\t\t<div class=\"fl customers-col\"><a title=\"[lang-{$strComponentRealname}-view]\" href=\"[link_in_use]{$strComponentRealname}/view/id/{$objmoduleConfig->id}/\">{$objmoduleConfig->level_status}</a></div>";
			$results_html_items .= "\n\t\t\t<div class=\"fl customers-col\">
									<a title=\"[lang-{$strComponentRealname}-edit]\" href=\"[link_in_use]{$strComponentRealname}/edit/id/{$objmoduleConfig->id}/\">[lang-{$strComponentRealname}-edit]</a> <br><br>
									<a title=\"[lang-{$strComponentRealname}-edit]\" href=\"[link_in_use]{$strComponentRealname}/delete/id/{$objmoduleConfig->id}/\">[lang-{$strComponentRealname}-delete]</a>
								</div>";
			$results_html_items .= "\n\t\t</div>";
		}
		
	
		return $results_html_items;
		