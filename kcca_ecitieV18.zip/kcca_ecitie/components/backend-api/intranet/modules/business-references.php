<?php

(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

header("Content-type: application/json");

$ref_types_arr = array();
foreach (RecoveryTrail::getRefTypes() as $value) {
    array_push($ref_types_arr, array("id" => $value->reference_name, "name" => $value->label));
}

$response = [
    "business_refs" => $ref_types_arr,
    "status" => 200
];

echo json_encode($response);
exit;
