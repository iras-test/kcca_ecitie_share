<?php

class AuthWrapper
{

    public static function getAuthenticatedUser()
    {
        $request_headers = apache_request_headers();
        if ($request_headers && isset($request_headers['Authorization'])) {
            $auth_token = explode(" ", $request_headers['Authorization']);
            $auth_token = $auth_token[1];
            $decrypted_token = self::decryptCredentials($auth_token);
            $user_credentials = explode(" ", $decrypted_token);
            $username = $user_credentials[0];
            $password = $user_credentials[1];
            try {
                KSecurity::login($username, $password);
            } catch (Exception $th) {
                echo json_encode([
                    "message" => $th->getMessage(),
                    "status" => 400
                ]);
                exit;
            }
        } else {
            echo json_encode([
                "message" => "Unauthorized Access",
                'status'=>401
            ]);
            exit;
        }
    }

    public static function encryptCredentials($username, $password)
    {
        // Store a string into the variable which
        // need to be Encrypted
        $simple_string = $username . " " . $password;

        // Store cipher method
        $ciphering = "BF-CBC";

        // Use OpenSSl encryption method
        // $iv_length = openssl_cipher_iv_length($ciphering);
        $options = 0;

        // Use random_bytes() function which gives
        // randomly 16 digit values
        $encryption_iv = '1234567891011121';

        // Alternatively, we can use any 16 digit
        // characters or numeric for iv
        $encryption_key = openssl_digest(php_uname(), 'MD5', TRUE);

        // Encryption of string process starts
        $encryption = openssl_encrypt(
            $simple_string,
            $ciphering,
            $encryption_key,
            $options,
            $encryption_iv
        );

        return $encryption;
    }

    public static function decryptCredentials($encryption)
    {

        // Decryption of string process starts
        // Used random_bytes() which gives randomly
        // 16 digit values
        // Store cipher method
        $ciphering = "BF-CBC";

        // Use OpenSSl encryption method
        // $iv_length = openssl_cipher_iv_length($ciphering);
        $options = 0;
        $decryption_iv = '1234567891011121';

        // Store the decryption key
        $decryption_key = openssl_digest(php_uname(), 'MD5', TRUE);

        // Descrypt the string
        $decryption = openssl_decrypt(
            $encryption,
            $ciphering,
            $decryption_key,
            $options,
            $decryption_iv
        );

        // Display the decrypted string
        return $decryption;
    }

    public static function authenticateUser()
    {
        KSecurity::setActionClear(null);

        if (KRequest::isPosted()) {

            try {
                $username = KRequest::getPost('frmUsername');
                $password = KRequest::getPost('frmPassword');
                KSecurity::login($username, $password);
                $session_key = KSecurity::sessionUserStorage();
                $user = unserialize(KSecurity::getSession($session_key));
                $user->is_portal_user = ($user->user_role_id == 18);
                return [
                    'token' => self::encryptCredentials($username, $password),
                    'user' => $user,
                    "status" => 200
                ];
            } catch (Exception $e) {
                // exception on login
                return [
                    "message" => $e->getMessage(),
                    "status" => 400
                ];
            }
        }

        return [
            'message' => "Un Allowed method",
            'status' => 503
        ];
    }
}
