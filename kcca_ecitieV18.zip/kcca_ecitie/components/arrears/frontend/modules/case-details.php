<?php

$info = null;
$error = null;
$case = array();
$util = new Util();
$escalation_info = "";
$assignee_options = "";
$active_assignment = (object)[];
$esclation_history = "";
$queryParams = KRequest::getQueryStrings();
$case_id = $queryParams["id"];

if (array_key_exists("id", $queryParams)) {
    $info  = (object) ArrearCase::getItem($case_id);
}

$bills = ArrearsManager::getAllPaymentBills($info->ref_name, $info->ref_id);
$feedbacks = ArrearCaseFeedback::getAllFeedback($case_id);


$info_display = null;
$actions_link = null;
if ($info) {
    $prn = $info->prn ? $info->prn : "N/A";
    $case_status = ($info->status == null) ? ArrearStatus::ASSIGNED : $info->status;
    $bal = abs($info->arrear_amount);
    $business_details = ArrearsManager::getBusinessDetails($info->ref_name, $info->ref_id);

    $extra_details = "";
    if ($info->ref_name == "vehicle") {
        $extra_details .= "<div class=\"pt10\">
                            <strong><span class=\"bs-bold\">Park</span></strong>: {$business_details->park_name}
                        </div>
                        <div class=\"pt10\">
                            <strong><span class=\"bs-bold\">Stage</span></strong>: {$business_details->stage_name}
                        </div>
                        ";
    }

    $info_display = "
        <div class=\"clear customer-blocks pb10\">
            <h1 class=\"kfw-active-title\"><strong>[lang-arrears-case-details]<strong></h1>
            <div class=\"clear pt10\">
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Customer</span></strong>: {$info->customer}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">COIN</span></strong>: {$info->coin}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Revenue name</span></strong>: {$info->revenue_name}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Branch Code</span></strong>: {$info->branch_code}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Location</span></strong>: {$business_details->location}
                </div>
                {$extra_details}
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Outstanding balance</span></strong>: {$bal}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Status</span></strong>: <span class=\"{$util::StatusClass($case_status)}\">{$case_status}</span>
                </div>
            </div>
        </div>
    ";


    $has_active_payment_plan = PaymnentPlanManager::getCasePaymentPlan($info->id, true);
    $payment_plan_created = PaymnentPlanManager::getCasePaymentPlan($info->id);

    $has_active_agency_notice_issued = ArrearCase::getCaseAgencyNoticeActions($info->id);
    $agency_notice_issued = ArrearCase::getCaseAgencyNoticeActions($info->id, false);

    $has_active_business_seal = ArrearCase::getCaseBusinessSealActions($info->id);
    $business_sealed = ArrearCase::getCaseBusinessSealActions($info->id, false);

    $actions_link = "<h1 class=\"kfw-active-title pt10\"><strong>Actions<strong></h1>";

    if (!($has_active_agency_notice_issued || $has_active_business_seal)) {
        $actions_link .= "<div class=\"clear pt10\"><div class=\"field\"><label><strong>Payment Plan<strong></label></div><div class=\"data pt10\">";
        $actions_link .= $payment_plan_created
            ? "<a class=\"arr-text-green\" href=\"[link_in_use]arrears/view-payment-plan?case_id={$info->id}\">View Requested Payment Plan</a>"
            : "<a class=\"arr-text-orange\" href=\"[link_in_use]arrears/create-payment-plan?case_id={$info->id}\">Request for Payment Plan</a>";
        $actions_link .= "</div></div>";
    }

    if ($agency_notice_issued) {
        $actions_link .= "<div class=\"clear pt10\"><div class=\"field\"><label><strong>Agency Notice<strong></label></div><div class=\"data pt10\">";
        $actions_link .=  "<a class=\"arr-text-green\" href=\"[link_in_use]arrears/view-agency-notice?id={$agency_notice_issued->id}\">View Issued Agency Notice</a>";
        $actions_link .= "</div></div>";
    }


    if ($business_sealed) {
        $actions_link .= "<div class=\"clear pt10\"><div class=\"field\"><label><strong>Business Seal<strong></label></div><div class=\"data pt10\">";
        $actions_link .= "<a class=\"arr-text-green\" href=\"[link_in_use]arrears/view-business-seal?id={$business_sealed->id}\">View Business Seal Details</a>";
        $actions_link .= "</div></div>";
    }
}

/** Bill breakdowns */
if (count($bills) > 0) {
    // show record	
    foreach ($bills as $index => $arrData) {
        $class = ($index % 2 == 0) ? ' odd' : ' even';
        $obj = (object) $arrData;
        $record_number = $index + 1;
        $prn = $obj->prn ? $obj->prn : "N/A";
        $due_date = $obj->due_date?$obj->due_date:"N/A";
        $record_type = $obj->reason;

        $records .= "<div class=\"clear list-item{$class}\">";
        $records .= "\n\t\t\t<div class=\"fl numbering-col\">{$record_number}</div>";
        $records .= "\n\t\t\t<div class=\"fl col20\">{$obj->financial_year}</div>";
        $records .= "\n\t\t\t<div class=\"fl col20\">{$record_type}</div>";
        $records .= "\n\t\t\t<div class=\"fl col20\">{$due_date}</div>";
        $records .= "\n\t\t\t<div class=\"fl col20\">{$obj->amount}</div>";
        $records .= "\n\t\t</div>";
    }
} else {
    $records  = "\n\t\t<div class=\"clear list-item\">" . KLanguage::getWord('arrears-case-items') . "</div>";
}

/** Feedback breakdowns */
$feedback_info = "";
if (count($feedbacks) > 0) {
    // show record	
    foreach ($feedbacks as $index => $arrData) {
        $class = ($index % 2 == 0) ? ' odd' : ' even';
        $obj = (object) $arrData;
        $record_number = $index + 1;

        $feedback_type = ArrearCaseFeedback::getFeedbackType($obj->feedback_type)
            ? ArrearCaseFeedback::getFeedbackType($obj->feedback_type)
            : "N/A";

        $feedback_info .= "<div class=\"clear list-item{$class}\">";
        $feedback_info .= "\n\t\t\t<div class=\"fl numbering-col\">{$record_number}</div>";
        $feedback_info .= "\n\t\t\t<div class=\"fl col20\">{$obj->created_date}</div>";
        $feedback_info .= "\n\t\t\t<div class=\"fl col20\">{$obj->location}</div>";
        $feedback_info .= "\n\t\t\t<div class=\"fl col20\">{$feedback_type}</div>";
        $feedback_info .= "\n\t\t\t<div class=\"fl col20\">{$obj->feedback}</div>";
        $feedback_info .= "\n\t\t</div>";
    }
} else {
    $feedback_info  = "\n\t\t<div class=\"clear list-item\">" . KLanguage::getWord('arrears-case-no-feedback') . "</div>";
}

$legal_actions = Util::getLegalHistory($case_id);

$case["options"] = $options;
$case["info_display"] = $info_display;
$case["legal_actions"] = $legal_actions;
$case["actions_info"] = $actions_link;
$case["bills"] = $records;
$case["feedback_info"] = $feedback_info;
$case["error"] = $error;
$case["arrear_case_id"] = $case_id;
$case["current_assignment"] = $active_assignment->id;
$case["close_url"] = "action={$this->urlPath(0)}close-case?id={$case_id}";
$case["escalation_url"] = "{$this->urlPath(0)}escalate-case";


$this->render($case);
