<?php

if(KRequest::isPosted()) {
    $queryParams = KRequest::getQueryStrings();
    $closed_reason = KRequest::getPost("close_reason");
    ArrearCase::updateStatus($queryParams["id"], $status = ArrearStatus::CLOSED, null, null, $closed_reason);

    // Send back business to register
    $case = ArrearCase::getArrearCaseByID($queryParams["id"]);
    ArrearsManager::updateBusinessArrearStatus($case->ref_name, $case->ref_id,ArrearStatus::BUSINESS_ACTIVE);

    KResponse::redirect("{$this->urlPath(0)}cases");

} else {
    KResponse::redirect("{$this->urlPath(0)}list");
}
