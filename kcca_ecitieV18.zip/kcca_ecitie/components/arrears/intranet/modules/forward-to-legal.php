<?php

if (KRequest::isPosted()) {
    
    $queryParams = KRequest::getQueryStrings();
    ArrearCase::updateStatus($queryParams["id"], ArrearStatus::UNDER_LITIGATION);
    ArrearCase::deactivatePreviousAssignments($queryParams["id"]);
    KSecurity::setActionSuccess("Succesfully forwared case to legal");
    KResponse::redirect("{$this->urlPath(0)}cases");

}
KSecurity::setActionWarning("Illegal Access Method");
$this->stopRedirector(KSecurity::getSession('BACK_URL'));
