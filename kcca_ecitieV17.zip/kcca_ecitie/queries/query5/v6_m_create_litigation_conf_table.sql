use ecitie;

CREATE TABLE [dbo].[forward_for_litigation_config](
	[id] [int] IDENTITY(1,1) NOT NULL,
    [recovery_mechanism_status] [VARCHAR](255) UNIQUE NOT NULL,
	[no_of_days] [int] NOT NULL,
    [config_status] [int] DEFAULT 1,
	[created_by] [int] NULL,
	[created_date] [datetime2](0) NULL,
	[modified_by] [int] NULL,
	[modified_date] [datetime2](0) NULL,
)
GO