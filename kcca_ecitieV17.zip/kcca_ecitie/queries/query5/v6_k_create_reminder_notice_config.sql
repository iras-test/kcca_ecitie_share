use ecitie;

CREATE TABLE [dbo].[reminder_notice_config](
	[id] [int] IDENTITY(1,1) NOT NULL,
    [ref_id] [int] UNIQUE NOT NULL,
	[before_expire] [int] NOT NULL,
	[after_expire] [int] NOT NULL,
    [config_status] [int] DEFAULT 1,
	[created_by] [int] NULL,
	[created_date] [datetime2](0) NULL,
	[modified_by] [int] NULL,
	[modified_date] [datetime2](0) NULL,
)
GO