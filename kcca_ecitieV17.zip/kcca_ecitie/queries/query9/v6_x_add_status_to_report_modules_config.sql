
use ecitie;

ALTER TABLE [dbo].[report_modules_config] ADD [status] [int] DEFAULT 1
-- Update rows in table 'TableName'
UPDATE [dbo].[report_modules_config]
SET [status] = 1