use ecitie;

ALTER TABLE [ecitie].[dbo].[recovery_type] ADD [field_supported] [INT]


-- Insert rows into table 'TableName'
INSERT INTO [ecitie].[dbo].[recovery_type]
( -- columns to insert data into
 [name], [status_id], [field_supported]
)
VALUES
( -- first row: values for the columns in the list above
 'Seal Business', 1, 1
),
( -- first row: values for the columns in the list above
 'Issue Agency Notice', 1, 1
)


-- -- Update rows in table 'TableName'
-- UPDATE [ecitie].[dbo].[recovery_type]
-- SET
--     [status_id] = 1
--     -- add more columns and values here
-- WHERE [id] in (6,7)