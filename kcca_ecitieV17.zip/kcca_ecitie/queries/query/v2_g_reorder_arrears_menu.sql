
use ecitie;

UPDATE [dbo].[component] SET ordering = '511' WHERE key_default = 'arrears'
UPDATE [dbo].[component] SET ordering = '512' WHERE key_default = 'escalation_config'