
USE ecitie;

update [dbo].[component]   set permissions = 'list,cases,action,close-case,create-payment-plan', module_permission_map = 'list:list' where title = 'arrears'
