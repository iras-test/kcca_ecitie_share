
ALTER VIEW [dbo].[v_arrear_case] AS
SELECT arr_case.id, arr_case.created_date,
arr_case.created_by, arr_case.ref_id,
arr_case.ref_name, arr_case.customer_id,
arr_case.assigned_action, arr_case.assignee,
arr_case.status, arr_case.closed,
arr_case.due_date,
arr_case.modified_date,
(SELECT name FROM division WHERE id = arr_case.division_id) AS division,
(SELECT name FROM parish WHERE id = arr_case.parish_id) AS parish,
(SELECT name FROM village WHERE id = arr_case.village_id) AS village,
arr_case.street_id,
arr_case.revenue_type_id,
rt.name as revenue_name,
customer.mobile AS mobile,
customer.email AS email,
CASE 
    WHEN customer.customer_type_id = 1 THEN CONCAT(customer.surname, ' ', customer.firstname)
    ELSE customer.entity_legal_name
END As customer,
customer.coin, arr_case.branch_code as branch_code,
CASE
    WHEN arr_case.ref_name = 'property' THEN CONVERT(float, property.balance)
    WHEN arr_case.ref_name = 'vehicle' THEN CONVERT(float, vehicle.balance)
    WHEN arr_case.ref_name = 'outdoor' THEN CONVERT(float, outdoor.balance)
END As arrear_amount
FROM arrear_case AS arr_case 
LEFT JOIN customer AS customer ON customer.id = arr_case.customer_id
LEFT JOIN property AS property ON (property.id = arr_case.ref_id AND property.balance < 0)
LEFT JOIN vehicle AS vehicle ON (vehicle.id = arr_case.ref_id AND vehicle.balance < 0 )
LEFT JOIN outdoor outdoor ON (outdoor.id = arr_case.ref_id AND outdoor.balance < 0 )
LEFT JOIN revenue_type rt ON rt.id = arr_case.revenue_type_id


-- SELECT TOP (1000) [id]
--       ,[created_date]
--       ,[created_by]
--       ,[ref_id]
--       ,[ref_name]
--       ,[customer_id]
--       ,[assigned_action]
--       ,[assignee]
--       ,[status]
--       ,[closed]
--       ,[due_date]
--       ,[modified_date]
--       ,[division]
--       ,[revenue_type_id]
--       ,[revenue_name]
--       ,[mobile]
--       ,[email]
--       ,[customer]
--       ,[coin]
--       ,[branch_code]
--       ,[arrear_amount]
--   FROM [dbo].[v_arrear_case]




-- SELECT arr_case.id, arr_case.created_date, 
-- arr_case.created_by, arr_case.ref_id, 
-- arr_case.ref_name, arr_case.customer_id, 
-- arr_case.assigned_action, arr_case.assignee, 
-- arr_case.status, arr_case.closed, pb.due_date AS due_date, 
-- arr_case.modified_date, 
-- (SELECT name FROM division WHERE id = arr_case.division_id) AS division,
-- pb.revenue_type_id, 
-- rt.name as revenue_name, 
-- customer.mobile AS mobile, 
-- customer.email AS email, 
-- CONCAT(customer.surname, ' ', customer.firstname) AS customer, 
-- customer.coin, arr_case.branch_code as branch_code, 
-- CASE 
--     WHEN arr_case.ref_name = 'property' THEN CONVERT(int, property.balance) 
--     WHEN arr_case.ref_name = 'vehicle' THEN CONVERT(int, vehicle.balance) 
--     WHEN arr_case.ref_name = 'trading_license' THEN CONVERT(int, trading_license.balance) 
--     WHEN arr_case.ref_name = 'outdoor' THEN CONVERT(int, outdoor.balance) 
-- END As arrear_amount 
-- FROM arrear_case AS arr_case 
-- CROSS APPLY (
--     SELECT TOP 1 bill.* FROM payment_bill bill where 
--     bill.reference_id = arr_case.ref_id AND bill.reference_name = arr_case.ref_name 
--     ORDER BY bill.created_date DESC ) AS pb 
-- LEFT JOIN customer AS customer ON customer.id = arr_case.customer_id 
-- LEFT JOIN property property ON property.id = arr_case.ref_id 
-- LEFT JOIN vehicle vehicle ON vehicle.id = arr_case.ref_id 
-- LEFT JOIN trading_license trading_license ON trading_license.id = arr_case.ref_id 
-- LEFT JOIN outdoor outdoor ON outdoor.id = arr_case.ref_id 
-- LEFT JOIN revenue_type rt ON rt.id = pb.revenue_type_id 
-- WHERE ( (arr_case.ref_name='property' AND property.balance < 0 ) 
--         OR (arr_case.ref_name='vehicle' AND vehicle.balance < 0 ) 
--         OR (arr_case.ref_name='trading_license' AND trading_license.balance < 0 ) 
--         OR (arr_case.ref_name='outdoor' AND outdoor.balance < 0 ) 
--         ) ORDER BY arr_case.modified_date DESC OFFSET 0 ROWS FETCH NEXT 10 ROWS ONLY

