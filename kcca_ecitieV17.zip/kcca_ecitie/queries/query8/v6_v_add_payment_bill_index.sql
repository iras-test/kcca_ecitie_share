use ecitie;

CREATE INDEX payment_id_index ON [dbo].[payment_bill] (payment_id)
CREATE INDEX reference_name_index ON [dbo].[payment_bill] (reference_name)
CREATE INDEX reference_id_index ON [dbo].[payment_bill] (reference_id)