
let selectedRecords = [];
let selectedAllRecords = false;

function handleRecordSelection(select, ref_name,ref_id,coin){
    data = {
        ref_name,ref_id,coin
    }
    if(select.checked) {
        selectedRecords.push(data);
    } else {
        selectedRecords = selectedRecords.filter(it => it.ref_id != ref_id)
    }

    document.getElementById("multiselect").style.display = selectedRecords.length? "inline-block": "none"
}

function selectAllRecords(button) {
    selectedAllRecords = !selectedAllRecords;
    button.innerText = selectedAllRecords? "Unselect All": "Select All";
    var inputs = document.getElementsByTagName("input");
    for(var i = 0; i < inputs.length; i++) {
        var input = inputs[i];
        if((input.type == "checkbox") && (input.checked != selectedAllRecords)) {
            input.click(); 
        }  
    }
}

function sendMultiple(url) {
    const formData = new FormData();
    formData.append("selected_data", JSON.stringify(selectedRecords));
    formData.append("bulk_submission",true);
    fetch(
       url,
        {
            method: "POST",
            body: formData
        }
    )
    .then(resp => resp.json())
    .then(() => {
        window.location.href = url;
    })
    .catch(() => window.alert("Failed to submit"));
}