<?php
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

header("Content-type: application/json");
$instance = KetrouteApplication::instance();
$where_clause = array('status_id'=>KStatus::ACTIVE);
$prop_types = $instance->db()->getList(
    "sub_property_type",
    $where = $where_clause,
    $fields = '*',
    $pager_info = null,
    $where_in = null,
    $likeforlike_binding = null,
    $startwith_binding = null,
    $endwith_binding = null,
    $hasatleast_binding = null,
    $greaterthanequal_binding = null,
    $lessthanequal_binding = null,
    $between_binding = null,
    $year_binding = null, 
    $order_ascending = 'name'
);

echo json_encode(["results" => $prop_types,"status" => 200]);

exit;
