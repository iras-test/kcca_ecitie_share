<?php
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

header("Content-type: application/json");

$coin = KRequest::getQueryString("coin", null);
$customer = CustomerManager::getCustomerbyCOIN($coin);
$instance = KetrouteApplication::instance();

if ($customer != null) {

    try {
        $customer->citizenship_country_id = $instance->db()->load($table = 'country', $where = array('id' => $customer->citizenship_country_id));
    } catch (\Exception $th) {
    }

    try {
        $customer->residential_address_district_id = $instance->db()->load($table = 'district', $where = array('id' => $customer->residential_address_district_id));
    } catch (\Exception $th) {
    }

    try {
        $customer->box_district_id = $instance->db()->load($table = 'district', $where = array('id' => $customer->box_district_id));
    } catch (\Exception $th) {
    }

    try {
        $customer->residential_address_county_id = $instance->db()->load($table = 'county', $where = array('id' => $customer->residential_address_county_id));
    } catch (\Exception $th) {
    }

    try {
        $customer->residential_address_sub_county_id = $instance->db()->load($table = 'sub_county', $where = array('id' => $customer->residential_address_sub_county_id));
    } catch (\Exception $th) {
    }

    try {
        $customer->residential_address_parish_id = $instance->db()->load($table = 'parish', $where = array('id' => $customer->residential_address_parish_id));
    } catch (\Exception $th) {
    }

    try {
        $customer->residential_address_village_id = $instance->db()->load($table = 'village', $where = array('id' => $customer->residential_address_village_id));
    } catch (\Exception $th) {
    }

    try {
        $customer->previous_business_address_district_id = $instance->db()->load($table = 'district', $where = array('id' => $customer->previous_business_address_district_id));
    } catch (\Exception $th) {
    }

    try {
        $customer->previous_business_address_county_id = $instance->db()->load($table = 'county', $where = array('id' => $customer->previous_business_address_county_id));
    } catch (\Exception $th) {
    }

    try {
        $customer->previous_business_address_sub_county_id = $instance->db()->load($table = 'sub_county', $where = array('id' => $customer->previous_business_address_sub_county_id));
    } catch (\Exception $th) {
    }

    try {
        $customer->previous_business_address_parish_id = $instance->db()->load($table = 'parish', $where = array('id' => $customer->previous_business_address_parish_id));
    } catch (\Exception $th) {
    }

    try {
        $customer->previous_business_address_village_id = $instance->db()->load($table = 'village', $where = array('id' => $customer->previous_business_address_village_id));
    } catch (\Exception $th) {
    }

    try {
        $customer->customer_applicant_type_id = $instance->db()->load($table = 'customer_applicant_type', $where = array('id' => $customer->customer_applicant_type_id));
    } catch (\Exception $th) {
    }

    try {
        $customer->customer_business_type_id = $instance->db()->load($table = 'customer_business_type', $where = array('id' => $customer->customer_business_type_id));
    } catch (\Exception $th) {
    }

    try {
        $customer->title_id = $instance->db()->load($table = 'title', $where = array('id' => $customer->title_id));
    } catch (\Exception $th) {
    }

    try {
        $customer->gender_id = $instance->db()->load($table = 'gender', $where = array('id' => $customer->gender_id));
    } catch (\Exception $th) {
    }

    try {
        $customer->customer_reference = $instance->db()->load($table = 'customer_reference', $where = array('customer_id' => $customer->id));
    } catch (\Exception $th) {
        $customer->customer_reference = (object)[];
    }

    try {
        $customer->customer_contact_person = $instance->db()->load($table = 'customer_contact_person', $where = array('customer_id' => $customer->id));
    } catch (\Exception $th) {
        $customer->customer_contact_person = (object)[];
    }

    try {
        $customer->customer_revenue_agent = $instance->db()->load($table = 'customer_revenue_agent', $where = array('customer_id' => $customer->id));
    } catch (\Exception $th) {
        $customer->customer_revenue_agent = (object)[];
    }


    $associates = $instance->db()->getList(
        "customer_business_associate",
        $where = ['customer_id'=>$customer->id],
        $fields = '*'
    );

    $business_associaties = [];
    foreach ($associates as $key => $associate) {
        $associate_types = $instance->db()->getList(
            "customer_business_associate_type",
            $where = ['customer_business_associate_id'=>$associate->id,'status_id'=>KStatus::ACTIVE],
            $fields = '*'
        );
        $associate_types_load = [];
        foreach ($associate_types as $key => $associate_type) {
            try {
                $associate_type->associate_type_id = $instance->db()->load($table = 'associate_type', $where = array('id' => $associate_type->associate_type_id));
            } catch (\Throwable $th) {
                $associate_type->associate_type_id = (object)[];
            }
            $associate_types_load[] = $associate_type;
        }
        $associate->associate_types = $associate_types_load;
        $business_associaties[] = $associate;
    }


    $customer->business_associaties = $business_associaties;


}

echo json_encode(["customer" => $customer, "status" => 200]);

exit;
