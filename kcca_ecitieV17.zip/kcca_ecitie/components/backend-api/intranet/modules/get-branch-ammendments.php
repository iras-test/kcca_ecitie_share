<?php
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

header("Content-type: application/json");
AuthWrapper::getAuthenticatedUser();

$instance = KetrouteApplication::instance();

$ammendments = $instance->db()->getList(
    "amendment",
    $where = array('created_by'=>KSecurity::getUserID()),
    $fields = '*',
    $pager_info = null,
    $where_in = null,
    $likeforlike_binding = null,
    $startwith_binding = null,
    $endwith_binding = null,
    $hasatleast_binding = null,
    $greaterthanequal_binding = null,
    $lessthanequal_binding = null,
    $between_binding = null,
    $year_binding = null,
    $order_ascending = 'amendment_reference'
);

$result = array();
foreach ($ammendments as $key => $ammendment) {

    $ammendment->customer =  CustomerManager::getProfile($ammendment->customer_id);
    try {
        $amendment_link = $instance->db()->load($table = 'amendment_link', $where = array('amendment_id' => $ammendment->id));
        $ammendment->amendment_link = $amendment_link;
    } catch (\Exception $th) {
        $ammendment->amendment_link = (object)[];
    }

    try {
        $ammendment->status = $instance->db()->load($table = 'status', $where = array('id' => $ammendment->status_id));
    } catch (\Exception $th) {
        $ammendment->status = (object)[];
    }
    $result[] = $ammendment;

}

echo json_encode(["amendments" => $result, "status" => 200]);

exit;
