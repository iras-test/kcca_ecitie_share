<?php

(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

header("Content-type: application/json");


$year = (int) date('Y');
if (date('Y-m-d H:m:s') > date("$year-06-30 23:59:59")) {

    $start_year = $year;
    $end_year = $year + 1;

} else {

    $start_year = $year - 1;
    $end_year = $year;

}

$result = [];

while ($start_year >= 2014) {
    
    $result[] = ['id'=>$start_year, 'name'=> "$start_year/$end_year"];
    $end_year = $start_year;
    $start_year -= 1;

}

echo json_encode(["years"=>$result, 'status'=>200]);
exit;