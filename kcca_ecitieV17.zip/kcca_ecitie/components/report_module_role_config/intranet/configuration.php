<?php
/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

    $arrReportConfig                                                    = array();
    $arrReportConfig[KSystemManager::ITEM_PROPERTY_TABLE_NAME]          = 'report_modules_access';
    $arrReportConfig[KSystemManager::ITEM_PROPERTY_LIST_FIELDS]         = array('role_id','report_module','status');
    $arrReportConfig[KSystemManager::ITEM_PROPERTY_VIEW_FIELDS]         = array('role_id','report_module','status');

    $arrReportConfig[KSystemManager::ITEM_PROPERTY_ADD_FIELDS] 			= array('role_id','report_module','status');																								
    $arrReportConfig[KSystemManager::ITEM_PROPERTY_EDIT_FIELDS] 		= array('role_id','report_module','status');																										
    $arrReportConfig[KSystemManager::ITEM_PROPERTY_SORT_FIELDS] 		= array('report_module' => KSystemManager::SORT_ASCENDING);


    $arrReportConfig[KSystemManager::ITEM_PROPERTY_PRIMARY_KEY] 		= 'id';
    $arrReportConfig[KSystemManager::ITEM_PROPERTY_TITLE_FIELD] 		=  'report_module';

    $arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS] 				                                                        = array(); 

    $arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['role_id'] 				                                    = array();
    $arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['role_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE]        = KSystemManager::FIELD_TYPE_SELECT;
    $arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['role_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL]       = 'role-name';
    $arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['role_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH]   = 100;
    $arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['role_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH]   = null;
    $arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['role_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED]    = 1;
    $arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['role_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT]     = '';
    $arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['role_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 	    = array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'user_role',
                                                                                                                                        KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
                                                                                                                                        KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> 'name',
                                                                                                                                        KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
                                                                                                                                        KSystemManager::WHERE_CLAUSE 						=> null,
                                                                                                                                        KSystemManager::ORDER_BY  							=> array('name' => KSystemManager::SORT_ASCENDING),
                                                                                                                                    );
                                                                                                                                    
    $arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['report_module'] 				                                    = array();
    $arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['report_module'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE]        = KSystemManager::FIELD_TYPE_SELECT;
    $arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['report_module'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL]       = 'report-module';
    $arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['report_module'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH]   = 100;
    $arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['report_module'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH]   = null;
    $arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['report_module'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED]    = 1;
    $arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['report_module'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT]     = '';
    $arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['report_module'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 	    = array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'report_modules',
                                                                                                                                        KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
                                                                                                                                        KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> 'display_name',
                                                                                                                                        KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
                                                                                                                                        KSystemManager::WHERE_CLAUSE 						=> null,
                                                                                                                                        KSystemManager::ORDER_BY  							=> array('display_name' => KSystemManager::SORT_ASCENDING),
                                                                                                                                    );

    $arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['status'] 				                                    = array();
    $arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['status'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 		= KSystemManager::FIELD_TYPE_YESNO;
    $arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['status'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 	    = 'status';
    $arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['status'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH]    = 50;
    $arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['status'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH]    = null;
    $arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['status'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 	= 1;
    $arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['status'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 	    = '';
    $arrReportConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['status'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 	    = array();

     return $arrReportConfig;