
<?php

(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
set_time_limit(0);

// run daily

$instance = KetrouteApplication::instance();

print("checking for paid arrears: \n");

$arrears_cases_cleared = $instance->db()->getList(
    "v_arrear_case",
    $where = array('ignore' => array('status' => ArrearStatus::CLOSED)),
    $fields = '*',
    $pager_info = null,
    $where_in = null,
    $likeforlike_binding = null,
    $startwith_binding = null,
    $endwith_binding = null,
    $hasatleast_binding = null,
    $greaterthanequal_binding = array('arrear_amount' => "1"),
    $lessthanequal_binding = null,
    $between_binding = null,
    $year_binding = null,
    $order_ascending = 'created_date'
);

$biz_count = 0;

foreach ($arrears_cases_cleared as $index => $arrear_case) {

    print("$biz_count : updating business details... ");

    # Update status
    $comment = "Business Arrears Paid";
    ArrearCase::updateStatus($arrear_case->id,  ArrearStatus::CLOSED, null, null, $comment);
    ArrearsManager::updateBusinessArrearStatus($arrear_case->ref_name, $arrear_case->ref_id, ArrearStatus::BUSINESS_ACTIVE);
    print("updated business details\n");

    // Send back
    $instance->database()->createRecord(
        'arrear_case_send_back',
        array(
            "arrear_case_id"    =>  $arrear_case->id,
            "comment"           =>  $comment,
            "created_by"        =>  null
        ),
        array('created_date' => KetrouteApplication::db()->getNowExpression())
    );

    $biz_count++;
}
