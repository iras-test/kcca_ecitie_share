<?php

if (KRequest::isPosted()) {

    $selected_escalation_action = KRequest::getPost('escalation_action');
    $case_id = KRequest::getPost('arrear_case_id');
    $comment = KRequest::getPost('comment');
    $reason = KRequest::getPost("reason");

    $current_assignment_id = KRequest::getPost('current_assignment');
    $status = null;

    ArrearCase::deactivatePreviousAssignments($case_id);
    if ($reason == EscalationLevels::$ESCALATION_REASONS[0]) {
        ArrearCase::updateStatus($case_id, ArrearStatus::DUE_FOR_LITIGATION, null, null, null);
    }
    $next_assignee = null;
    $new_assignment = null;

    $next_assignee =  KRequest::getPost('assignee');

    if (!$current_assignment_id && ($selected_escalation_action == EscalationLevels::ESCALATE_BACK)) {
        $previous_assignment = end(ArrearCase::getCaseAssignments($case_id, $active_only=false));
        $next_assignee = $previous_assignment->user_id;
        $status = ArrearStatus::DEFFERED_BY_LEGAL;
    }

    if ($next_assignee) {
        $new_assignment = ArrearCase::create_assignment($next_assignee, $case_id, $status);
        KSecurity::setActionSuccess("Escalated Case Successfully");
    }else{
        KSecurity::setActionWarning("Could not identify next level recipient!");
    }

    if ($new_assignment) {

        ArrearCase::addAssignmentComment($new_assignment, $comment, $reason);
        if (KRequest::isUploaded('attachments')) {

            $uploaded_attachments = KRequest::getUploadFile('attachments');
            $upload_errors = KRequest::getUploadError('attachments');
            $uploaded_file_mimes = KRequest::getUploadMime("attachments");
            $uploaded_file_names = KRequest::getUploadName("attachments");
            foreach ((array)$uploaded_attachments as $key => $attachment_path) {
                if ($upload_errors[$key] == UPLOAD_ERR_OK) {
                    $file_name = $uploaded_file_names[$key];
                    $file_name = KGenerator::licenseKey($file_name) . '.' . KFile::getExtension($file_name);
                    // try to save the attachment
                    $document_saved = KFile::uploadTemporaryFile($attachment_path, KFW_STORAGE_PATH . $this->getComponentRealname() . DIRECTORY_SEPARATOR . $file_name, null, KetrouteApplication::reg()->get('CREATE_STORAGE_IF_NOT_EXISTS', false));
                    if ($document_saved) {
                        $attachment_saved = $this->database()->createRecord(
                            'assignment_attachments',
                            array(
                                "assignment_id" => $new_assignment,
                                'document'             => 'escalation attachment',
                                'document_name'     => $uploaded_file_names[$key],
                                'document_mime'     => $uploaded_file_mimes[$key],
                                'document_sysname'     => $file_name,
                                "created_by" => KSecurity::getUserID()
                            ),
                            array('created_date' => KetrouteApplication::db()->getNowExpression())
                        );
                        // // capture audit log
                        $this->logAuditTrail("Attachemt uploaded for assignment #$new_assignment", 'assignment_attachments', $attachment_saved);
                    }
                }
            }
        }
    }

}else {
    KSecurity::setActionWarning("Illegal Access Method");
}
$this->stopRedirector(KSecurity::getSession('BACK_URL'));
