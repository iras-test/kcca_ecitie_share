<?php
/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin
		
// get max per page
$MAX_PER_PAGE 	= $this->registry()->get(strtoupper($this->getComponentRealname()).'_MAX_PER_PAGE', $this->registry()->get('MAX_PER_PAGE',10));
// page number
$_page		 	= $this->getParam('page', KRequest::getQueryString("page", 1));
$strComponentRealname	= $this->getComponentRealname();
$user_id		= KSecurity::getUserID();
$intIgnoreID 	= $this->runtime()->getIgnoredID();
$strParentUrl	= $this->urlPath(0);
$strMessage = '';
$records = '';		
$list_counter	= 0;
$util = new Util();

$queryParams = KRequest::getQueryStrings();
$queryParams = array_merge($queryParams, array(
    "status" => ArrearStatus::DUE_FOR_LITIGATION,
    "legal"=>1
));

$pending_litigation = ArrearCase::getList($_page, $queryParams);

$result_list['count'] = ArrearCase::count($queryParams);
$data = ArrearCase::getList($_page, $queryParams);

// set active item with its configurations	
$this->runtime()->setActivePage($_page);
$this->runtime()->setActiveMaxPerPage($MAX_PER_PAGE);

/** Case assignment officers */
$officers = ArrearsManager::getOfficers();
$assignee_options = "";
foreach ($officers as $key => $value) {
	$assignee_options .= "<option value=\"$value->id\">{$value->surname} {$value->firstname}</option>";
}

/** Section for filters */
/** Status Filter */
$status_arr = array(
    array("id" => ArrearStatus::UNDER_AGENCY_NOTICE, "name" => ArrearStatus::UNDER_AGENCY_NOTICE),
    array("id" => ArrearStatus::UNDER_BUSINESS_SEAL, "name" => ArrearStatus::UNDER_BUSINESS_SEAL)
);
$status_filter = Util::filterInput(
	"select",
	"Status",
	"status",
	$queryParams["status"],
	$options = array(
		"data" => $status_arr,
		"id" => "id",
		"label" => "name",
		"placeholder" => " - Status - "
	)
);
/** End of Status Filter */

/** Assignee filters */
$assignee_arr = array();
foreach (ArrearsManager::getOfficers() as $value) {
    # code...
    array_push($assignee_arr, array("id" => $value->id, "name" => $value->surname . " " . $value->firstname));
}

$assignee_filter = Util::filterInput(
	"select",
	"Assignee",
	"assignee",
	$queryParams["assignee"],
	$options = array(
		"data" => $assignee_arr,
		"id" => "id",
		"label" => "name",
		"placeholder" => " - Assignee - "
	)
);
/** End assignee */
$branch_code_filter = Util::filterInput("text", "Branch-Code", "branch_code", $queryParams["branch_code"]);

$filters = "
    $branch_code_filter
	$assignee_filter
";

/** End section of filters */

if($result_list['count'] > 0) {
    // show record	
    foreach ($data as $index => $arrData){      
        $strPrimaryKey = $this->runtime()->getPrimaryKey();
        
        $class = ($index % 2 == 0) ? ' odd' : ' even';
        
        if($_page > 1)
        {
            $record_number = ($index+1)+($MAX_PER_PAGE*($_page-1));
        }
        else
        {
            $record_number = ($index+1);
        }
        
        $list_counter++;
        $obj = (object)$arrData;

        $customer_name = (isset($arrData['customer_id']) && $arrData['customer_id'])
        ? $this->runtime()->getFieldData('customer_id', $arrData)
        : "N/A";

        $revenue_name = $obj->revenue_name
        ? $obj->revenue_name
        : "N/A";

        $amount = $obj->arrear_amount
        ? number_format(abs($obj->arrear_amount))
        : "N/A";

        $branch_code = $obj->branch_code!=null? $obj->branch_code: "N/A";

        $assignee = ArrearCase::getAssignee($obj->assignee);
        $case_status = ($obj->status == null)?ArrearStatus::OPEN:$obj->status;
        
        $records .= "<div class=\"clear list-item{$class}\">";			
        $records .= "\n\t\t\t<div class=\"fl numbering-col\">{$record_number}</div>";
        $records .= "\n\t\t\t<div class=\"fl col20\">{$customer_name}</div>";
        $records .= "\n\t\t\t<div class=\"fl col15\">{$revenue_name}</div>";
        $records .= "\n\t\t\t<div class=\"fl col10\">{$branch_code}</div>";
        $records .= "\n\t\t\t<div class=\"fl col10\">{$amount}</div>";
        $records .= "\n\t\t\t<div class=\"fl col15\">{$assignee}</div>";
        $records .= "\n\t\t\t<div class=\"fl col8 {$util::StatusClass($case_status)}\">{$case_status}</div>";
        $records .= "\n\t\t\t<div class=\"fl col10\">
            <a href=\"[link_in_use]arrears/case-details/?id={$obj->id}&previous=legal\">Details</a>
        </div>";
        $records .= "\n\t\t</div>";

    }

} else {
    $records  = "\n\t\t<div class=\"clear list-item\">".KLanguage::getWord('arrears-case-items')."</div>";
}

$pager = new KPager();		
$pager->setTotalRecords($result_list['count']);
$pager->setRecordsPerPage($MAX_PER_PAGE);
$pager->setCurrentPage($_page);
$url = $this->urlPath(1, 1, 1, 1);
	if (count($queryParams)>0) {
		$ex_url = explode("page=",$url);
		$url = $ex_url[0];
		if (count($ex_url)==1) {
			$url .= "&";
		}
	}else {

		$url .= "?";
	
	}
	$pager->setURL($url."page=");
$pager_html = $pager->getPager();
$pager_info = $pager->getPagerInfo("[lang-{$strComponentRealname}-case-items]");

$this->render(array(
    'records' => $records,
    'pager_html' 	=> $pager_html,
    "options"       => $assignee_options,
    'pager_info' 	=> $pager_info,
    'message' 		=> $strMessage,
    'list_counter' 	=> $list_counter,
    'tabs' 			=> KNavigationTab::getHTMLTabs(),
    'base_url'		=> $this->urlPath(1,1,0,0),
    'filters'		=> Util::formContainer("arrears", $this->urlPath(1,1,1,1), $filters),
));
