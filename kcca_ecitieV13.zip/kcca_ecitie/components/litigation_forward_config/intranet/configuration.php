<?php

/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

$arrReminderConfig                                                    = array();
$arrReminderConfig[KSystemManager::ITEM_PROPERTY_TABLE_NAME]          = 'forward_for_litigation_config';
$arrReminderConfig[KSystemManager::ITEM_PROPERTY_LIST_FIELDS]         = array('recovery_mechanism_status', 'no_of_days', 'config_status');
$arrReminderConfig[KSystemManager::ITEM_PROPERTY_VIEW_FIELDS]         = array('recovery_mechanism_status', 'no_of_days', 'config_status');

$arrReminderConfig[KSystemManager::ITEM_PROPERTY_ADD_FIELDS]             = array('recovery_mechanism_status', 'no_of_days', 'config_status');
$arrReminderConfig[KSystemManager::ITEM_PROPERTY_EDIT_FIELDS]         = array('recovery_mechanism_status', 'no_of_days', 'config_status');
$arrReminderConfig[KSystemManager::ITEM_PROPERTY_SORT_FIELDS]         = array('recovery_mechanism_status' => KSystemManager::SORT_ASCENDING);


$arrReminderConfig[KSystemManager::ITEM_PROPERTY_PRIMARY_KEY]         = 'id';
$arrReminderConfig[KSystemManager::ITEM_PROPERTY_TITLE_FIELD]         =  'recovery_mechanism_status';

$arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]                                                                         = array();

$arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['recovery_mechanism_status']                                                     = array();
$arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['recovery_mechanism_status'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE]        = KSystemManager::FIELD_TYPE_SELECT;
$arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['recovery_mechanism_status'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL]       = 'recovery_mechanism_status';
$arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['recovery_mechanism_status'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH]   = 100;
$arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['recovery_mechanism_status'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH]   = null;
$arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['recovery_mechanism_status'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED]    = 1;
$arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['recovery_mechanism_status'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT]     = '';
$arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['recovery_mechanism_status'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD]         = array(
    KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ARRAY => array(
        ArrearStatus::UNDER_AGENCY_NOTICE => ArrearStatus::UNDER_AGENCY_NOTICE,
        ArrearStatus::UNDER_BUSINESS_SEAL => ArrearStatus::UNDER_BUSINESS_SEAL,
        ArrearStatus::UNDER_PAYMENT_PLAN => ArrearStatus::UNDER_PAYMENT_PLAN
    )
);

$arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['no_of_days']                                                     = array();
$arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['no_of_days'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE]             = KSystemManager::FIELD_TYPE_DIGIT;
$arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['no_of_days'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL]         = 'no_of_days';
$arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['no_of_days'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH]     = 10;
$arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['no_of_days'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH]     = null;
$arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['no_of_days'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED]         = 1;
$arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['no_of_days'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT]         = '';
$arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['no_of_days'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD]         = array();

$arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['config_status']                                                     = array();
$arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['config_status'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE]         = KSystemManager::FIELD_TYPE_YESNO;
$arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['config_status'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL]         = 'status';
$arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['config_status'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH]    = 50;
$arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['config_status'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH]    = null;
$arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['config_status'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED]     = 1;
$arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['config_status'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT]         = '';
$arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['config_status'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD]         = array();

return $arrReminderConfig;
