<?php

(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

header("Content-type: application/json");

/** Section for filters */
/** Ref type filters */
$ref_types_arr = array();
foreach (RecoveryTrail::getRecoveryTypes(false) as $value) {
    # code...
    array_push($ref_types_arr, array("id" => $value->id, "name" => $value->name));
}

$response = [
    "recovery_types" => $ref_types_arr,
    "status" => 200
];

echo json_encode($response);
exit;
