<?php

use JetBrains\PhpStorm\ArrayShape;

$_page    = KRequest::getQueryString("page", 1);
$queryParams = KRequest::getQueryStrings();

header("Content-type: application/json");
AuthWrapper::getAuthenticatedUser();

$queryParams["assigned"] = 1;
$data = ArrearCase::getList($_page, $queryParams);
$cases_details = [];

foreach ($data as $index => $arrData) {
    $case_obj = (object)$arrData;

    $branch_code = $case_obj->branch_code != null ? $case_obj->branch_code : "N/A";
    $revenue_name = $case_obj->revenue_name
        ? $case_obj->revenue_name
        : "N/A";

    $amount = $case_obj->arrear_amount
        ? number_format(abs($case_obj->arrear_amount))
        : "N/A";

    $assignee = ArrearCase::getAssignee($case_obj->assignee);
    $case_status = ($case_obj->status == null) ? ArrearStatus::OPEN : $case_obj->status;

    $case_obj->status = $case_status;
    $case_obj->revenue_name = $revenue_name;
    $case_obj->customer = $case_obj->customer."\n ".$case_obj->email."\n ".$case_obj->mobile;
    $case_obj->amount = $amount;
    $case_obj->assignee = $assignee;
    $case_obj->branch_code = $branch_code;

    $cases_details[] = $case_obj;
}
$response = [
    "cases" => $cases_details,
    "status" => 200
];
echo json_encode($response);
exit;
