<?php
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

header("Content-type: application/json");

$business_id = KRequest::getQueryString("business_id", null);
$instance = KetrouteApplication::instance();
$property_branch = null;
try {
    $property_branch = $instance->database()->load('property', array(
        'id' => $business_id
    ));
} catch (Exception $e) {
}

if ($property_branch) {

    try {
        $property_branch->customer = $this->runtime()->getFieldData('customer_id', (array)$property_branch);
    } catch (\Exception $th) {
        $property_branch->customer = "";
    }

    try {
        $property_branch->division_id = $instance->db()->load($table = 'division', $where = array('id' => $property_branch->division_id));
    } catch (\Exception $th) {
        $property_branch->division_id = "";
    }

    try {
        $property_branch->parish_id = $instance->db()->load($table = 'parish', $where = array('id' => $property_branch->parish_id));
    } catch (\Exception $th) {
        $property_branch->parish_id = "";
    }

    try {
        $property_branch->village_id = $instance->db()->load($table = 'village', $where = array('id' => $property_branch->village_id));
    } catch (\Exception $th) {
        $property_branch->village_id = "";
    }


    try {
        $property_branch->property_type_id = $instance->db()->load($table = 'property_type', $where = array('id' => $property_branch->property_type_id));
    } catch (\Exception $th) {
        $property_branch->property_type_id = "";
    }

    try {
        $property_branch->sub_property_type_id = $instance->db()->load($table = 'sub_property_type', $where = array('id' => $property_branch->sub_property_type_id));
    } catch (\Exception $th) {
        $property_branch->sub_property_type_id = "";
    }

    try {
        $property_branch->property_rented_status_id = $instance->db()->load($table = 'property_rented_status', $where = array('id' => $property_branch->property_rented_status_id));
    } catch (\Exception $th) {
        $property_branch->property_rented_status_id = "";
    }

    try {
        $property_branch->validity_status = $instance->db()->load($table = 'status', $where = array('id' => $property_branch->status_id));
    } catch (\Exception $th) {
        $property_branch->validity_status = "";
    }
}

echo json_encode(["details" => $property_branch, "status" => 200]);

exit;
