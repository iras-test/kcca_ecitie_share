<?php

/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

class RecoveryTrail
{
    public static function create($attachment, $arrear_case_id, $recovery_type_id)
    {
        KetrouteApplication::db()->createRecord(
            "recovery_trail",
            array(
                "arrear_case_id" => $arrear_case_id,
                "attachment" => $attachment,
                "recovery_type_id" => $recovery_type_id,
                "created_by" => KSecurity::getUserID(),

            ),
            array("created_date" => KetrouteApplication::db()->getNowExpression())
        );
    }

    public static function getList($page, $queryParams)
    {
        list($start, $end) = ArrearsManager::getPagination($page);
        $where = self::buildWhere($queryParams);

        $GENERIC_SQL = "SELECT rec.id, rec.ref_name, rec.ref_id, rec.recovery_type_id, rec.coin,
            rec.division_id, rec.branch_code, rec.created_by, (SELECT name from division WHERE id = rec.division_id) AS division,
            ROW_NUMBER() OVER (ORDER BY rec.created_date DESC) AS rowNum FROM recovery_trail AS rec
            WHERE rec.status_id = '1' $where
        ";

        $SQL = "WITH results AS
            (
                $GENERIC_SQL
            )
            SELECT * FROM results  WHERE RowNum BETWEEN $start AND $end
        ";

        return KetrouteApplication::db()->execute($SQL);
    }

    public static function count($queryParams)
    {
        $where = self::buildWhere(($queryParams));
        $SQL = "SELECT COUNT(*) AS total
            FROM recovery_trail AS rec
            WHERE rec.status_id = '1' $where
        ";
        $res = (object) KetrouteApplication::db()->execute($SQL);
        return $res->fields["total"];
    }

    public static function buildWhere($queryParams)
    {
        $where = "";
        if (array_key_exists("coin", $queryParams)  && $queryParams['coin']) {
            $coin = trim($queryParams["coin"]);
            $where .= " AND rec.coin = '$coin'";
        }

        if (array_key_exists("division", $queryParams)  && $queryParams['division']) {
            $division = (int) $queryParams["division"];
            $where .= " AND rec.division_id = '$division' ";
        }

        if (array_key_exists("branch_code", $queryParams)  && $queryParams['branch_code']) {
            $branch_code = trim($queryParams["branch_code"]);
            $where .= " AND rec.branch_code = '$branch_code' ";
        }

        return $where;
    }

    public static function getRecoveryTypes($non_field_options_only=true)
    {
        if ($non_field_options_only) {
            $search_options = array('status_id'=>KStatus::ACTIVE, 'field_supported'=>null);
        }else{
            $search_options = array('status_id'=>KStatus::ACTIVE);
        }
        return KetrouteApplication::instance()->database()->getList(
            $table = 'recovery_type',
            $where = $search_options
        );
    }

    public static function getCoResponseTypes()
    {
        return [
            "Objection",
            "Request For Payment Plan",
            "Other"
        ];
    }

    public static function getActivityAttachments($recovery_trail_id, $attachment_type = "attachment")
    {
        $SQL = "SELECT * FROM recovery_trail_attachments WHERE recovery_trail_id = :recovery_trail_id: AND attachment_type =:attachment_type:";
        $bindings_extra[':recovery_trail_id:'] = $recovery_trail_id;
        $bindings_extra[':attachment_type:'] = $attachment_type;

        $SQL .= " ORDER BY (id)";

        $results = null;
        $resultsarr = KetrouteApplication::db()->execute($SQL, $bindings_extra);

        if (isset($resultsarr->fields) && $resultsarr->fields) {

            while (!$resultsarr->EOF) {
                $results[] = (object)$resultsarr->fields;
                $resultsarr->MoveNext();
            }
        }
        return $results;
    }

    public static function getRefTypes()
    {
        return KetrouteApplication::instance()->database()->getList(
            $table = 'recovery_trail_reference',
            $where = array(
                'status_id' => KStatus::ACTIVE
            )
        );
    }

    public static function searchResults($page, $queryParams)
    {
        if (
            array_key_exists("ref_type", $queryParams) && $queryParams["ref_type"]
        ) {
            $sql = "";
            $coin = "";
            $ref_type = $queryParams["ref_type"];
            if ((array_key_exists("coin", $queryParams) && $queryParams["coin"])) {
                $coin = $queryParams["coin"];
            }

            $branch_code = "";
            if (array_key_exists("branch_code", $queryParams)  && $queryParams['branch_code']) {
                $branch_code = trim($queryParams["branch_code"]);
            }

            $current_user_role = KSecurity::getUserObject()->user_role_id;
            $active_status = KStatus::ACTIVE;
            $arrears_status = ArrearStatus::BUSINESS_MOVED_TO_ARREARS;
            $expired_status = KStatus::EXPIRED;

            if (in_array($current_user_role, [ArrearStatus::ARREARS_MANAGER_ROLE, ArrearStatus::ARREARS_OFFICER_ROLE])) {
                $status_filter = " WHERE ref.status_id in ($active_status, $arrears_status, $expired_status)";
            } else {
                $status_filter = " WHERE ref.status_id in ($active_status, $expired_status) ";
            }

            $select = "";
            $join = "";
            $where = "";

            switch ($ref_type) {
                case "vehicle":
                    $select = "SELECT ref.id, ref.number_plate AS branch_code,
                        CONCAT(cust.surname, ' ', cust.firstname) AS customer_name,
                        ref.number_plate As business_name,
                        ref.balance As balance,
                        ROW_NUMBER() OVER (ORDER BY ref.id) AS rowNum
                        FROM vehicle AS ref 
                        LEFT JOIN customer AS cust ON cust.id = ref.customer_id
                    ";
                    $where = " $status_filter ";
                    $where .= $branch_code ? " AND ref.number_plate = '$branch_code' " : "";
                    $where .= $coin ? " AND cust.coin='$coin' " : "";
                    break;

                case "property":
                    $select = " SELECT ref.id, ref.property_no AS branch_code,
                        ref.property_no AS business_name,
                        ref.balance As balance,
                        CONCAT(cust.surname, ' ', cust.firstname) AS customer_name,
                        ROW_NUMBER() OVER (ORDER BY ref.id) AS rowNum
                        FROM property AS ref LEFT JOIN customer AS cust ON cust.id = ref.customer_id
                    ";

                    $where = " $status_filter ";
                    $where .=  $branch_code ? " AND ref.property_no = '$branch_code'" : "";
                    $where .= $coin ? " AND cust.coin='$coin' " : "";

                    break;

                case "trading_license":
                    $select = "SELECT ref.id, ref.code AS branch_code,
                        ref.business_name AS business_name,
                        ref.balance As balance,
                        CONCAT(cust.surname, ' ', cust.firstname) AS customer_name,
                        ROW_NUMBER() OVER (ORDER BY ref.id) AS rowNum
                        FROM trading_license AS ref LEFT JOIN customer AS cust ON cust.id = ref.customer_id 
                    ";

                    $where = " $status_filter ";
                    $where .= $branch_code ? " AND ref.serial_number = '$branch_code'" : "";
                    $where .= $coin ? " AND cust.coin='$coin' " : "";
                    break;

                case "groundrent":
                    $select = "SELECT ref.id, ref.ground_rent_number AS branch_code,
                        CONCAT(cust.surname, ' ', cust.firstname) AS customer_name,
                        ref.main_debt As balance,
                        ROW_NUMBER() OVER (ORDER BY ref.id) AS rowNum
                        FROM groundrent AS ref LEFT JOIN customer AS cust ON cust.id = ref.customer_id
                    ";

                    $where = " $status_filter ";
                    $where .=  $branch_code ? " AND ref.ground_rent_number = '$branch_code'" : "";
                    $where .= $coin ? " AND cust.coin='$coin' " : "";
                    break;

                case "markets":
                    $select = "SELECT ref.id, ref.market_code AS branch_code,
                        ref.name AS business_name,
                        CONCAT(cust.surname, ' ', cust.firstname) AS customer_name,
                        ROW_NUMBER() OVER (ORDER BY ref.id) AS rowNum
                        FROM markets AS ref LEFT JOIN customer AS cust ON cust.id = ref.market_ownership_id 
                    ";
                    $where = " $status_filter ";
                    $where .=  $branch_code ? " AND ref.market_code = '$branch_code'" : "";
                    $where .= $coin ? " AND cust.coin='$coin' " : "";
                    break;

                case "outdoor":
                    $select = "SELECT ref.id, ref.branch_code AS branch_code,
                        ref.office_no AS business_name,ref.balance As balance,
                        CONCAT(cust.surname, ' ', cust.firstname) AS customer_name,
                        ROW_NUMBER() OVER (ORDER BY ref.id) AS rowNum
                        FROM outdoor AS ref LEFT JOIN customer AS cust ON cust.id = ref.market_ownership_id
                    ";

                    $where = " $status_filter ";
                    $where .=  $branch_code ? " AND ref.branch_code = '$branch_code'" : "";
                    $where .= $coin ? " AND cust.coin='$coin' " : "";
                    break;
            }

            $sql = "$select $join $where";
            list($start, $end) = ArrearsManager::getPagination($page);
            $SQL = "WITH results AS
                (
                    $sql
                )
                SELECT * FROM results  WHERE RowNum BETWEEN $start AND $end
            ";
            return KetrouteApplication::db()->execute($SQL);
        } else {
            return [];
        }
    }

    public static function searchCount($queryParams)
    {

        if (
            array_key_exists("ref_type", $queryParams) && $queryParams["ref_type"]
        ) {
            $sql = "";
            $coin = "";
            $ref_type = $queryParams["ref_type"];

            if ((array_key_exists("coin", $queryParams) && $queryParams["coin"])) {
                $coin = $queryParams["coin"];
            }

            $branch_code = "";
            if (array_key_exists("branch_code", $queryParams)  && $queryParams['branch_code']) {
                $branch_code = trim($queryParams["branch_code"]);
            }

            $current_user_role = KSecurity::getUserObject()->user_role_id;
            $active_status = KStatus::ACTIVE;
            $arrears_status = ArrearStatus::BUSINESS_MOVED_TO_ARREARS;
            $expired_status = KStatus::EXPIRED;

            if (in_array($current_user_role, [ArrearStatus::ARREARS_MANAGER_ROLE, ArrearStatus::ARREARS_OFFICER_ROLE])) {
                $status_filter = " WHERE ref.status_id in ($active_status, $arrears_status, $expired_status)";
            } else {
                $status_filter = " WHERE ref.status_id in ($active_status, $expired_status) ";
            }

            $select = "";
            $join = "";
            $where = "";

            switch ($ref_type) {
                case "vehicle":
                    $select = "SELECT count(ref.id) AS total FROM vehicle AS ref 
                    LEFT JOIN customer AS cust ON cust.id = ref.customer_id ";
                    $where = " $status_filter ";
                    $where .= $branch_code ? " AND ref.number_plate = '$branch_code'" : "";
                    $where .= $coin ? " AND cust.coin='$coin' " : "";
                    break;

                case "property":
                    $select = "SELECT count(ref.id) AS total FROM property AS ref LEFT JOIN customer AS cust ON cust.id = ref.customer_id ";
                    $where = " $status_filter ";
                    $where .=  $branch_code ? " AND ref.property_no = '$branch_code'" : "";
                    $where .= $coin ? " AND cust.coin='$coin' " : "";
                    break;

                case "trading_license":
                    $select = "SELECT count(ref.id) AS total FROM trading_license AS ref LEFT JOIN customer AS cust ON cust.id = ref.customer_id
                    ";
                    $where = " $status_filter ";
                    $where .= $branch_code ? " AND ref.serial_number = '$branch_code'" : "";
                    $where .= $coin ? " AND cust.coin='$coin' " : "";
                    break;

                case "groundrent":
                    $select = "SELECT count(ref.id) AS total FROM groundrent AS ref LEFT JOIN customer AS cust ON cust.id = ref.customer_id
                    ";
                    $where = " $status_filter ";
                    $where = " WHERE ref.status_id='$active_status' ";
                    $where .=  $branch_code ? " AND ref.ground_rent_number = '$branch_code'" : "";
                    $where .= $coin ? " AND cust.coin='$coin' " : "";

                    break;

                case "markets":
                    $select = "SELECT count(ref.id) AS total FROM markets AS ref LEFT JOIN customer AS cust ON cust.id = ref.market_ownership_id 
                    ";
                    $where = " $status_filter ";
                    $where .=  $branch_code ? " AND ref.market_code = '$branch_code'" : "";
                    $where .= $coin ? " AND cust.coin='$coin' " : "";
                    break;

                case "outdoor":
                    $select = "SELECT count(ref.id) AS total FROM outdoor AS ref LEFT JOIN customer AS cust ON cust.id = ref.market_ownership_id";
                    $where = " $status_filter ";
                    $where .=  $branch_code ? " AND ref.branch_code = '$branch_code'" : "";
                    $where .= $coin ? " AND cust.coin='$coin' " : "";
                    break;
            }

            $sql = "$select $join $where";
            return KetrouteApplication::db()->execute($sql)->fields["total"];
        } else {
            return 0;
        }
    }

    public static function getRevenueByRef($ref_name)
    {
        return KetrouteApplication::db()->load($table = 'recovery_trail_reference', $where = array('reference_name' => $ref_name));
    }

    public static function getRecoveryType($id)
    {
        if ($id) {
            return KetrouteApplication::db()->load($table = 'recovery_type', $where = array('id' => $id));
        } else {
            return (object) array("name" => "");
        }
    }

    public static function getListByRef($ref_name, $ref_id)
    {
        return KetrouteApplication::instance()->database()->getList(
            $table = 'recovery_trail',
            $where = array(
                'ref_name'  => $ref_name,
                'ref_id'    => $ref_id,
                'status_id' => KStatus::ACTIVE
            )
        );
    }
}
