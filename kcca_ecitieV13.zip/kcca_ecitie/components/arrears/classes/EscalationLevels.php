<?php

class EscalationLevels
{

    const ESCALATE_FORWARD = "f";
    const ESCALATE_BACK = "b";

    // escalation reason mappings
    public static $ESCALATION_REASONS = [
        "Due For Litigation",
        "Other"
    ];

    public static function getStartLevel()
    {
        $SQL = "SELECT TOP 1 * FROM escalation_levels ORDER BY level";
        return KetrouteApplication::db()->execute($SQL)->fields;
    }

    public static function getNextLevel($level_num)
    {
        $SQL = "SELECT TOP 1 * FROM escalation_levels where level > '$level_num' ORDER BY level";
        return KetrouteApplication::db()->execute($SQL)->fields;
    }



    public static function getUserEscalationLevel($user_id)
    {
        $user_role = KetrouteApplication::db()->getStaticTableValue("user", "id", "user_role_id", $user_id);
        return KetrouteApplication::db()->getStaticTableValue("escalation_levels", "role_id", "level", $user_role);
    }
}
