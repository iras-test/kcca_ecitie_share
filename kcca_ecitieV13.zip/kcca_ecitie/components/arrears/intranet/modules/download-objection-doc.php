<?php
/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

$id = $this->getParam('id', null);
$document_id = KRequest::getQueryString("document_id", null);

if ($id) {
    
    $objection = $this->database()->load($table = 'arrears_case_objection', $where = array('id' => $id));

}elseif($document_id){
    $objection = $this->database()->load($table = 'objection_attachments', $where = array('id' => $document_id));

}

$docName = $objection->document . '.' . KFile::getExtension($objection->document_name);
$docPath = KFW_STORAGE_PATH . $this->getComponentRealname() . DIRECTORY_SEPARATOR . $objection->document_sysname;
print_r($docPath);
exit;
KFile::downloadFile($docName, $docPath, $delete_file_when_done = false);