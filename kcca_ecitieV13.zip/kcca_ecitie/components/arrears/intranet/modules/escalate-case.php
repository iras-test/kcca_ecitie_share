<?php

if (KRequest::isPosted()) {

    $selected_escalation_action = KRequest::getPost('escalation_action');
    $case_id = KRequest::getPost('arrear_case_id');
    $comment = KRequest::getPost('comment');
    $reason = KRequest::getPost("reason");

    $current_assignment_id = KRequest::getPost('current_assignment');

    if ($current_assignment_id) {
        if ($reason == EscalationLevels::$ESCALATION_REASONS[0]) {
            ArrearCase::updateStatus($case_id, ArrearStatus::DUE_FOR_LITIGATION, null, null, null);
        }
        ArrearCase::addAssignmentComment($current_assignment_id, $comment, $reason);
        if (KRequest::isUploaded('attachments')) {

            $uploaded_attachments = KRequest::getUploadFile('attachments');
            $upload_errors = KRequest::getUploadError('attachments');
            $uploaded_file_mimes = KRequest::getUploadMime("attachments");
            $uploaded_file_names = KRequest::getUploadName("attachments");
            foreach ((array)$uploaded_attachments as $key => $attachment_path) {
                if ($upload_errors[$key] == UPLOAD_ERR_OK) {
                    $file_name = $uploaded_file_names[$key];
                    $file_name = KGenerator::licenseKey($file_name) . '.' . KFile::getExtension($file_name);
                    // try to save the attachment
                    $document_saved = KFile::uploadTemporaryFile($attachment_path, KFW_STORAGE_PATH . $this->getComponentRealname() . DIRECTORY_SEPARATOR . $file_name, null, KetrouteApplication::reg()->get('CREATE_STORAGE_IF_NOT_EXISTS', false));
                    if ($document_saved) {
                        $attachment_saved = $this->database()->createRecord(
                            'assignment_attachments',
                            array(
                                "assignment_id" => $current_assignment_id,
                                'document'             => 'escalation attachment',
                                'document_name'     => $uploaded_file_names[$key],
                                'document_mime'     => $uploaded_file_mimes[$key],
                                'document_sysname'     => $file_name,
                                "created_by" => KSecurity::getUserID()
                            ),
                            array('created_date' => KetrouteApplication::db()->getNowExpression())
                        );
                        // // capture audit log
                        $this->logAuditTrail("Attachemt uploaded for assignment #$current_assignment_id", 'assignment_attachments', $attachment_saved);
                    }
                }
            }
        }
    }

    ArrearCase::deactivatePreviousAssignments($case_id);

    if ($selected_escalation_action == EscalationLevels::ESCALATE_FORWARD) {

        $next_assignee =  KRequest::getPost('assignee');
        ArrearCase::create_assignment($next_assignee, $case_id);
    } else {
        $previous_assignment = (object)ArrearCase::getPreviousAssignment($case_id, $current_assignment_id);
        $next_assignee = $previous_assignment->user_id;
        ArrearCase::create_assignment($next_assignee, $case_id);
    }

    KSecurity::setActionSuccess("Escalated Case Successfully");
    $this->stopRedirector("{$this->urlPath(0)}cases");
}
KSecurity::setActionWarning("Illegal Access Method");
$this->stopRedirector(KSecurity::getSession('BACK_URL'));
