
use ecitie;

CREATE TABLE [dbo].[arrears_case_objection](
	[id] [INT] IDENTITY(1,1) NOT NULL,
    [arrear_case_id] INT NULL,
    [ref_name] [VARCHAR](255) NULL,
    [ref_id] INT NULL,
    [comment] [VARCHAR](255) NULL,
    [status_id] [SMALLINT] DEFAULT 1,
    [created_by] [INT] NULL,
    [created_date] [DATETIME2](0) NULL,
    [modified_by] [INT] NULL,
    [modified_date] [DATETIME2](0) NULL,
)
GO