use ecitie;

ALTER TABLE [dbo].[report_modules] ADD [display_name] [nvarchar](1000) NULL
