use ecitie;

update [dbo].[component]  set permissions = 'adhoc-reports,current-user', module_permission_map = 'list:list' where title = 'report'
update [dbo].[component]  set blocked_dptm = 'current-user' where title = 'report'
