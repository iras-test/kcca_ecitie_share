<?php
$case_id = $this->getParam('case', 1);
$redirect = $this->getParam('redirect', 1);
$queryParams = KRequest::getQueryStrings();
$role = $queryParams["role"];


if (KRequest::isPosted()) {
    $case = $this->database()->load('arrear_case', array('id' => $case_id));
    $assignee = $role == (ArrearStatus::ORC || ArrearStatus::MAI)? KRequest::getPost("assignee"): $case->created_by;
    ArrearCase::updateStatus($case_id,  ArrearStatus::DEFFERED, KRequest::getPost('comment'), $assignee);

    // Send back
    $this->database()->createRecord(
        'arrear_case_send_back', 
        array(
            "arrear_case_id"    =>  $case_id,
            "comment"           =>  KRequest::getPost('comment'),
            "created_by"        =>  KSecurity::getUserID()
        ),
        array('created_date' => KetrouteApplication::db()->getNowExpression())
    );

    // // // set success message
    KSecurity::setActionSuccess(KLanguage::getWord('You have successfully sent back the case', array('arrears_case' => $case_id)));
}

KResponse::redirect("{$this->urlPath(0)}$redirect");
