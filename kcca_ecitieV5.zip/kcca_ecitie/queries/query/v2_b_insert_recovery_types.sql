
use ecitie;

DELETE FROM [dbo].[recovery_type]

INSERT INTO [dbo].[recovery_type]
(name)
VALUES
('Reminder')

INSERT INTO [dbo].[recovery_type]
(name)
VALUES
('Demand notice')