<?php

if (KRequest::isPosted()) {

    $selected_approval_action = KRequest::getPost('approval_action');
    
    $business_seal_to_act_upon = KRequest::getPost('pp_id');

    if ($selected_approval_action == BusinessSealManager::BUSINESS_SEAL_REVOKE) {
        BusinessSealManager::business_seal_approval_action($business_seal_to_act_upon,
                                                           BusinessSealManager::STATUS_REVOKED,ArrearStatus::ASSIGNED);
    }
    
    KSecurity::setActionSuccess("Acted on Business Seal Successfully");
    $this->stopRedirector("{$this->urlPath(0)}view-business-seal?id={$business_seal_to_act_upon}");

}
KSecurity::setActionWarning("Illegal Access Method");
$this->stopRedirector(KSecurity::getSession('BACK_URL'));