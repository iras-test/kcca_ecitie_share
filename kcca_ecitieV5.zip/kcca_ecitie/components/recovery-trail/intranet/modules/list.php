<?php

/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

$results_html_items = '';
// get max per page
$MAX_PER_PAGE     = $this->registry()->get(strtoupper($this->getComponentRealname()) . '_MAX_PER_PAGE', $this->registry()->get('MAX_PER_PAGE', 10));
$strComponentRealname	= $this->getComponentRealname();
$user_id		= KSecurity::getUserID();
$intIgnoreID 	= $this->runtime()->getIgnoredID();
$strParentUrl	= $this->urlPath(0);
$_page		 	= $this->getParam('page', 1);
$queryParams = KRequest::getQueryStrings();

$result_list['results'] = RecoveryTrail::getList($_page, $queryParams);
$result_list['count'] = RecoveryTrail::count($queryParams);
$list_counter = 0;

// show records
foreach ($result_list['results'] as $index => $arrData) {
	$strPrimaryKey = $this->runtime()->getPrimaryKey();

	$class = ($index % 2 == 0) ? ' odd' : ' even';

	if ($_page > 1) {
		$record_number = ($index + 1) + ($MAX_PER_PAGE * ($_page - 1));
	} else {
		$record_number = ($index + 1);
	}
	$list_counter++;

	// convert to object
	$obj = (object)$arrData;

	$customer = (object) CustomerManager::getCustomerByCoin($obj->coin);
	$revenue = RecoveryTrail::getRevenueByRef($obj->ref_name);
	$recovery_type = RecoveryTrail::getRecoveryType($obj->recovery_type_id);

	$results_html_items .= "\n\t\t<div class=\"clear list-item{$class}\">";
	$results_html_items .= "\n\t\t\t<div class=\"fl numbering-col\">&nbsp;{$record_number}</div>";
	$results_html_items .= "\n\t\t\t<div class=\"fl col15\">&nbsp;{$customer->surname} {$customer->firstname}</div>";
	$results_html_items .= "\n\t\t\t<div class=\"fl col15\">&nbsp;{$obj->coin}</div>";
	$results_html_items .= "\n\t\t\t<div class=\"fl col15\">&nbsp;{$obj->division}</div>";
	$results_html_items .= "\n\t\t\t<div class=\"fl col10\">&nbsp;{$obj->branch_code}</div>";
	$results_html_items .= "\n\t\t\t<div class=\"fl col10\">&nbsp;{$revenue->label}</div>";
	$results_html_items .= "\n\t\t\t<div class=\"fl col10\">&nbsp;{$recovery_type->name}</div>";

	$results_html_items .= "\n\t\t\t<div class=\"fl col10\">
		<a href=\"[link_in_use]recovery-trail/view/id/{$obj->id}\">View</a>
	</div>";
	$results_html_items .= "\n\t\t</div>";

	$attachment_string = "";
	$activity_attachment = RecoveryTrail::getActivityAttachments($obj->id);
	foreach ($activity_attachment as $key => $attachment) {
		$attachment_string .= "<a href=\"[link_in_use]recovery-trail/download-attachment/id/{$attachment->id}\">{$attachment->document_name}</a><br>";
	}

	$response_attachment_string = "";
	$response_attachment = RecoveryTrail::getActivityAttachments($obj->id,"co_response_attachment");
	foreach ($response_attachment as $key => $attachment) {
		$response_attachment_string .= "<a href=\"[link_in_use]recovery-trail/download-attachment/id/{$attachment->id}\">{$attachment->document_name}</a><br>";
	}

	$results_html_items .= "\n\t\t<div class=\"clear list-item{$class}\">";
	$results_html_items .= "\n\t\t\t<div class=\"fl numbering-col\">&nbsp;</div>";
	$results_html_items .= "\n\t\t\t<div class=\"fl col15\">&nbsp;<strong>Field Activity Attachments</strong></div>";
	$results_html_items .= "\n\t\t\t<div class=\"fl col15\">&nbsp;{$attachment_string}</div>";
	// $results_html_items .= "\n\t\t</div>";

	// $results_html_items .= "\n\t\t<div class=\"clear list-item{$class}\">";
	// $results_html_items .= "\n\t\t\t<div class=\"fl numbering-col\">&nbsp;</div>";
	$results_html_items .= "\n\t\t\t<div class=\"fl col15\">&nbsp;<strong>City Operator Response Attachments</strong></div>";
	$results_html_items .= "\n\t\t\t<div class=\"fl col15\">&nbsp;{$response_attachment_string}</div>";
	$results_html_items .= "\n\t\t</div>";

	// end of item
}

/** Revenue sources */
$revenue_types = ArrearsManager::getRevenueTypes();
$revenue_types_arr = [];
foreach ($revenue_types as $key => $value) {
	array_push($revenue_types_arr, array("id" => $value["id"], "name" => $value["name"]));
}

/** Divisions */
$divisions = ArrearsManager::getDivisions();
$divisions_arr = [];
foreach ($divisions as $key => $value) {
	array_push($divisions_arr, array("id" => $value["id"], "name" => $value["name"]));
}

$coin_filter = Util::filterInput("text", "COIN", "coin", $queryParams["coin"]);
$branch_code_filter = Util::filterInput("text", "Branch-Code", "branch_code", $queryParams["branch_code"]);
$revenue_filter = Util::filterInput(
	"select",
	"Revenue",
	"revenue_type",
	$queryParams["revenue_type"],
	$options = array(
		"data" => $revenue_types_arr,
		"id" => "id",
		"label" => "name",
		"placeholder" => " - Select revenue type"
	)
);

$division_filter = Util::filterInput(
	"select",
	"Division",
	"division",
	$queryParams["division"],
	$options = array(
		"data" => $divisions_arr,
		"id" => "id",
		"label" => "name",
		"placeholder" => " - Select division"
	)
);

$filters = "
	$coin_filter
	$branch_code_filter
	$division_filter
";
/** End section of filters */

$pager = new KPager();
$pager->setTotalRecords($result_list['count']);
$pager->setRecordsPerPage($MAX_PER_PAGE);
$pager->setCurrentPage($_page);
$pager->setURL($this->urlPath(true, true, true, false, array('page')) . 'page/');
$pager_html = $pager->getPager();
$pager_info = $pager->getPagerInfo("[lang-{$strComponentRealname}-items]");

$this->render(array(
	'records' => $results_html_items,
	'filters'        => Util::formContainer("arrears", $this->urlPath(1, 1, 1, 1), $filters),
	'pager_html'     => $pager_html,
	"options"       => $assignee_options,
	'pager_info'     => $pager_info,
	'list_counter'     => $list_counter,
	'tabs'             => KNavigationTab::getHTMLTabs(),
	'base_url'        => $this->urlPath(1, 1, 0, 0),
));
