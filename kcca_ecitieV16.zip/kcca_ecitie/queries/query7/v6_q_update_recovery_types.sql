use ecitie;

-- Insert rows into table 'TableName'
INSERT INTO [ecitie].[dbo].[recovery_type]
( -- columns to insert data into
 [name], [status_id], [field_supported]
)
VALUES
( -- first row: values for the columns in the list above
 'Unseal Business', 1, 1
),
( -- first row: values for the columns in the list above
 'Sensitize', 1, 1
)