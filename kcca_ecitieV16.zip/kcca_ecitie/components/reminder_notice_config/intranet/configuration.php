<?php
/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

    $arrReminderConfig                                                    = array();
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_TABLE_NAME]          = 'reminder_notice_config';
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_LIST_FIELDS]         = array('ref_id','before_expire','after_expire','config_status');
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_VIEW_FIELDS]         = array('ref_id','before_expire','after_expire','config_status');

    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_ADD_FIELDS] 			= array('ref_id','before_expire','after_expire','config_status');																								
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_EDIT_FIELDS] 		= array('ref_id','before_expire','after_expire','config_status');																										
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_SORT_FIELDS] 		= array('ref_id' => KSystemManager::SORT_ASCENDING);


    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_PRIMARY_KEY] 		= 'id';
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_TITLE_FIELD] 		=  'id';

    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS] 				                                                        = array(); 

    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['ref_id'] 				                                    = array();
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['ref_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE]        = KSystemManager::FIELD_TYPE_SELECT;
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['ref_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL]       = 'revenue-source';
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['ref_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH]   = 100;
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['ref_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH]   = null;
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['ref_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED]    = 1;
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['ref_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT]     = '';
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['ref_id'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 	    = array(KSystemManager::ITEM_FIELD_PROPERTY_CHILD_TABLE_NAME => 'recovery_trail_reference',
                                                                                                                                        KSystemManager::ITEM_FIELD_PROPERTY_CHILD_ID 		=> 'id' , 
                                                                                                                                        KSystemManager::ITEM_FIELD_PROPERTY_CHILD_VALUE 	=> 'label',
                                                                                                                                        KSystemManager::ITEM_FIELD_PROPERTY_CHILD_FORCED  	=> false,
                                                                                                                                        KSystemManager::WHERE_CLAUSE 						=> array(
                                                                                                                                                                                                    'status_id' => KStatus::ACTIVE
                                                                                                                                                                                                ),
                                                                                                                                        KSystemManager::ORDER_BY  							=> array('label' => KSystemManager::SORT_ASCENDING),
                                                                                                                                    );

    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['before_expire'] 				                                    = array();
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['before_expire'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 		    = KSystemManager::FIELD_TYPE_DIGIT;
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['before_expire'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 	    = 'days-before-expiry';
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['before_expire'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH]     = 10;
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['before_expire'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH]     = null;
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['before_expire'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 	    = 1;
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['before_expire'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 	    = '';
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['before_expire'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 	    = array();

    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['after_expire'] 				                                    = array();
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['after_expire'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 		= KSystemManager::FIELD_TYPE_DIGIT;
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['after_expire'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 	    = 'days-after-expiry';
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['after_expire'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH]    = 10;
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['after_expire'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH]    = null;
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['after_expire'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 	= 1;
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['after_expire'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 	    = '';
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['after_expire'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 	    = array();

    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['config_status'] 				                                    = array();
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['config_status'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 		= KSystemManager::FIELD_TYPE_YESNO;
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['config_status'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 	    = 'status';
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['config_status'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH]    = 50;
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['config_status'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH]    = null;
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['config_status'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] 	= 1;
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['config_status'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] 	    = '';
    $arrReminderConfig[KSystemManager::ITEM_PROPERTY_FIELDS]['config_status'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] 	    = array();

     return $arrReminderConfig;