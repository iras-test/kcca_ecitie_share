/** Global variables */
let pivot;

const TODAY = "today";
const YESTERDAY = "yesterday";
const THIS_WEEK = "this_week";
const LAST_WEEK = "last_week";
const THIS_MONTH = "this_month";
const LAST_MONTH = "last_month";
const THIS_YEAR = "this_year";
const LAST_YEAR = "last_year";
const THIS_FY = "this_fy";
const LAST_FY = "last_fy";
const CUSTOM = "custom";
const START_DATE_FILTER = "created_date_start";
const END_DATE_FILTER = "created_date_end";
const CREATED_ON_FILTER = "created_on";

// test
// const HOST = "/ecitie";

// live
const HOST = "";

const SEARCH_ICON = `
    <svg
        height="32px" 
        version="1.1" 
        viewBox="0 0 32 32" 
        width="32px" 
        xmlns="http://www.w3.org/2000/svg" 
        xmlns:sketch="http://www.bohemiancoding.com/sketch/ns" 
        xmlns:xlink="http://www.w3.org/1999/xlink"
    >
        <title/><desc/><defs/>
        <g fill="none" fill-rule="evenodd" id="Page-1" stroke="none" stroke-width="1">
            <g fill="#929292" id="icon-111-search">
            <path d="M19.4271164,20.4271164 C18.0372495,21.4174803 16.3366522,22 14.5,22 C9.80557939,22 6,18.1944206 6,13.5 C6,8.80557939 9.80557939,5 14.5,5 C19.1944206,5 23,8.80557939 23,13.5 C23,15.8472103 22.0486052,17.9722103 20.5104077,19.5104077 L26.5077736,25.5077736 C26.782828,25.782828 26.7761424,26.2238576 26.5,26.5 C26.2219324,26.7780676 25.7796227,26.7796227 25.5077736,26.5077736 L19.4271164,20.4271164 L19.4271164,20.4271164 Z M14.5,21 C18.6421358,21 22,17.6421358 22,13.5 C22,9.35786417 18.6421358,6 14.5,6 C10.3578642,6 7,9.35786417 7,13.5 C7,17.6421358 10.3578642,21 14.5,21 L14.5,21 Z" id="search"/>
            </g>
        </g>
    </svg>
`;

const dateFilterOptions = [];

const preFilters = [
  TODAY,
  YESTERDAY,
  THIS_WEEK,
  LAST_WEEK,
  THIS_MONTH,
  LAST_MONTH,
  THIS_YEAR,
  LAST_YEAR,
  THIS_FY,
  LAST_FY,
];

let modules = [];
let currModule = "payment"; // Current report module
let currModuleColumns = [];
let filter = {}; // Contains date filters
let currUser = {};

function getDataTypes() {
  let types = {};
  currModuleColumns.forEach((item) => {
    var item_type = null;
    if (
      item.name.includes("_date") ||
      item.name.includes("date_") ||(item.name.includes("update") && !item.name.includes("update_by"))
    ) {
      item_type = "date string";
    } else {
      item_type = item.data_type.includes("char") ? "string" : "number";
    }

    var _name = item.name.split("__");
    _name = _name.length == 3 ? _name[2] : item.name;

    types[_name] = {
      type: item_type,
    };
  });
  return types;
}

function generateColumnSelectOptions() {
  let options = [];
  currModuleColumns.forEach((item) => {
    if (item.name.includes("_date") || item.name.includes("date_")) {
    } else {
      var _name = item.name.split("__");
      _name = _name.length == 3 ? _name[2] : item.name;
      options.push({ id: item.name, name: _name.replaceAll("_", " ") });
    }
  });
  return options;
}

/** End of global filters */

function createChart() {
  pivot.highcharts.getData(
    {
      type: "areaspline",
    },
    function (data) {
      Highcharts.chart("highchartsContainer", data);
    },
    function (data) {
      Highcharts.chart("highchartsContainer", data);
    }
  );
}

/** Fetch report from the API server */
async function getData(extra_filter) {
  let query = "";

  if (extra_filter) {
    Object.keys(extra_filter).map((item) => {
      query += `&${item}=${extra_filter[item]}`;
    });
  } else {
    Object.keys(filter).map((item) => {
      query += `&${item}=${filter[item]}`;
    });
  }

  return await fetch(
    `${HOST}/intranet/reports-api/data/?r_table=${currModule}${query}`
  );
}

/** Fetch all supported modules */
async function getModules() {
  return await fetch(`${HOST}/intranet/reports-api/report_modules/`);
}

function constructSilce(data) {
  let slice = {};
  if (data.length) {
    slice.rows = [
      {
        uniqueName: "id",
      },
    ];
    slice.columns = [
      {
        uniqueName: "Measures",
      },
    ];
    slice.measures = Object.keys(getDataTypes()).map((item) => ({
      uniqueName: item,
      grandTotalCaption: item,
    }));
  }

  return slice;
}

/** Format date in YYYY-MM-DD */
function formatDate(d) {
  return (
    d.getFullYear() +
    "-" +
    ("0" + (d.getMonth() + 1)).slice(-2) +
    "-" +
    ("0" + d.getDate()).slice(-2)
  );
}

/** Today's filter */
function todayFilter() {
  const d = new Date();
  return [formatDate(d), formatDate(d)];
}

/** Yesterday's filter */
function yesterdayFilter() {
  const d = new Date();
  return [
    formatDate(new Date(d.getFullYear(), d.getMonth(), d.getDate() - 1)),
    formatDate(new Date(d.getFullYear(), d.getMonth(), d.getDate() - 1)),
  ];
}

/** Handle custom filters i.e filters that are not pre-defined */
function customFilter(duration) {
  return {
    start: formatDate(new Date(duration.start)),
    end: formatDate(new Date(duration.end)),
  };
}

/** Create start and end date of the current (this) month */
function thisMonthFilter() {
  const date = new Date();
  const firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
  const lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);
  return [formatDate(firstDay), formatDate(lastDay)];
}

/** Create stand and end dates for the last month */
const lastMonthFilter = () => {
  const date = new Date();
  const firstDay = new Date(date.getFullYear(), date.getMonth() - 1, 1);
  const lastDay = new Date(date.getFullYear(), date.getMonth(), 0);
  return [formatDate(firstDay), formatDate(lastDay)];
};

/** Stand and end for this year */
function thisYear() {
  const nowDate = new Date();
  const firstDay = new Date(nowDate.getFullYear(), 0, 1);
  const lastDay = new Date(nowDate.getFullYear(), 11, 31);
  return [formatDate(firstDay), formatDate(lastDay)];
}

/** Stand and end for last year */
function lastYear() {
  const nowDate = new Date();
  const firstDay = new Date(nowDate.getFullYear() - 1, 0, 1);
  const lastDay = new Date(nowDate.getFullYear() - 1, 11, 31);
  return [formatDate(firstDay), formatDate(lastDay)];
}

/** Start and end for this financial year */
function thisFinancialYear() {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const last_financial_year_date = new Date(now.getFullYear(), 5, 30);
  if (today.getTime() > last_financial_year_date.getTime()) {
    var startYear = now.getFullYear();
  } else {
    var startYear = now.getFullYear() - 1;
  }

  var endYear = startYear + 1;
  return [
    formatDate(new Date(startYear, 6, 1)),
    formatDate(new Date(endYear, 5, 30)),
  ];
}

/** Start and end for last financial year */
function lastFinancialYear() {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const last_financial_year_date = new Date(now.getFullYear(), 5, 30);
  if (today.getTime() > last_financial_year_date.getTime()) {
    var startYear = now.getFullYear() - 1;
  } else {
    var startYear = now.getFullYear() - 2;
  }

  var endYear = startYear + 1;
  return [
    formatDate(new Date(startYear, 6, 1)),
    formatDate(new Date(endYear, 5, 30)),
  ];
}

function getPredefinedFilters(value) {
  switch (value) {
    case TODAY:
      return todayFilter();

    case YESTERDAY:
      return yesterdayFilter();

    case THIS_MONTH:
      return thisMonthFilter();

    case LAST_MONTH:
      return lastMonthFilter();

    case THIS_YEAR:
      return thisYear();

    case LAST_YEAR:
      return lastYear();

    case THIS_FY:
      return thisFinancialYear();

    case LAST_FY:
      return lastFinancialYear();

    default:
      return [null, null];
  }
}

/** Function to return report title date */
function reportDate() {
  return !(filter[START_DATE_FILTER] || filter[END_DATE_FILTER])
    ? "Today"
    : `${filter[START_DATE_FILTER]} to ${filter[END_DATE_FILTER]}`;
}

/**
 * Function to render chart on requirement
 */
function renderReport(extra_filter) {
  getData(extra_filter)
    .then((resp) => resp.json())
    .then(({ data, table_columns }) => {
      currModuleColumns = table_columns;
      data.unshift(getDataTypes());

      pivot = new WebDataRocks({
        container: "#wdr-component",
        beforetoolbarcreated: customizeToolbar,
        toolbar: true,
        report: {
          dataSource: {
            data: data,
          },
          slice: constructSilce(data),
          options: {
            grid: {
              showGrandTotals: "columns",
              title: extra_filter
                ? currModule.toUpperCase()
                : `${currModule.toUpperCase()} (${reportDate()})`,
              type: "flat",
            },
          },
        },
      });

      pivot.on("reportchange", function () {
        // createChart();
      });
    })
    .catch((err) => err);
}

function customizeToolbar(toolbar) {
  // Get all tabs
  let tabs = toolbar.getTabs();
  toolbar.getTabs = function () {
    const customExportTab = {
      title: "Export",
      id: "wdr-tab-export",
      mobile: false,
      icon: this.icons.export,
      menu: [
        {
          title: this.Labels.export_print,
          id: "wdr-tab-export-print",
          handler: this.printHandler,
          icon: this.icons.export_print,
        },
        {
          title: this.Labels.export_html,
          id: "wdr-tab-export-html",
          handler: () => customExportHandler(this, "html"),
          args: "html",
          icon: this.icons.export_html,
        },
        {
          title: this.Labels.export_excel,
          id: "wdr-tab-export-excel",
          handler: () => customExportHandler(this, "excel"),
          args: "excel",
          icon: this.icons.export_excel,
        },
        {
          title: this.Labels.export_pdf,
          id: "wdr-tab-export-pdf",
          handler: () => customExportHandler(this, "pdf"),
          args: "pdf",
          icon: this.icons.export_pdf,
        },
      ],
    };

    tabs = swapTab(tabs, "wdr-tab-export", customExportTab);

    // There will be two new tabs at the beginning of the toolbar
    tabs.unshift(
      {
        id: "wdr-tab-lightblue",
        title: "Modules",
        handler: () => handleModule(this),
        icon: this.icons.fields,
      },
      {
        id: "wdr-tab-default",
        title: "Filter",
        handler: () => handleFilter(this),
        icon: this.icons.format,
      },
      {
        id: "wdr-tab-search",
        title: "Search",
        handler: () => handleSearch(this),
        icon: SEARCH_ICON,
      }
    );

    return tabs;
  };
}

/** Function to swap/override tabs */
function swapTab(tabs, id, newTab) {
  let index = null;
  tabs.map((item, i) => {
    if (item.id === id) {
      index = i;
    }
  });

  if (index !== null) {
    tabs[index] = newTab;
  }

  return tabs;
}

/** This function is used to override webdatarocks configurations */
function handleModule(context) {
  var self = context;
  var Labels = context.Labels;

  var applyHandler = function () {
    // Update global variable that holds the current module
    currModule = valuesDropDown.value;
    renderReport();
  };

  var dialog = context.popupManager.createPopup();
  dialog.content.id = "wdr-popup-format-cells";
  dialog.setTitle("Module");
  dialog.setToolbar(
    [
      {
        id: "wdr-btn-apply",
        label: Labels.apply,
        handler: applyHandler,
        isPositive: true,
      },
      { id: "wdr-btn-cancel", label: Labels.cancel },
    ],
    true
  );

  var content = document.createElement("div");
  var group = document.createElement("div");
  group.classList.add("wdr-inp-group");
  content.appendChild(group);

  var row = document.createElement("div");
  row.classList.add("wdr-inp-row");
  row.classList.add("wdr-ir-horizontal");
  group.appendChild(row);

  // measures
  var label = document.createElement("label");
  label.classList.add("wdr-uc");
  self.setText(label, Labels.choose_value);
  row.appendChild(label);
  var select = self.createSelect();
  var valuesDropDown = select.select;
  valuesDropDown.options[0] = new Option("Choose Module", "empty");
  valuesDropDown.options[0].disabled = true;
  // Update dropdowns with current supported modules
  modules.forEach((item, index) => {
    valuesDropDown.options[index + 1] = new Option(
      item.display_name,
      item.name
    );
  });

  row.appendChild(select);

  var row = document.createElement("div");
  row.classList.add("wdr-inp-row");
  row.classList.add("wdr-ir-horizontal");
  group.appendChild(row);

  var group = document.createElement("div");
  group.classList.add("wdr-inp-group");
  content.appendChild(group);

  dialog.setContent(content);
  context.popupManager.addPopup(dialog.content);
}

function handleFilter(context) {
  var self = context;
  var Labels = context.Labels;

  var valuesDropDownChangeHandler = function () {
    if (valuesDropDown.value == CUSTOM) {
      // Show custom filter
      document.getElementById("custom_date").style.display = "block";
    } else {
      // Hide custom filter
      document.getElementById("custom_date").style.display = "none";
    }
  };

  var applyHandler = function () {
    var formatVO = {};
    if (valuesDropDown.value == "") formatVO.name = "";

    // Update global filters
    if (preFilters.includes(valuesDropDown.value)) {
      const res = getPredefinedFilters(valuesDropDown.value);
      filter[START_DATE_FILTER] = res[0];
      filter[END_DATE_FILTER] = res[1];
    } else {
      if (startInput.value) {
        filter[START_DATE_FILTER] = formatDate(new Date(startInput.value));
      } else {
        filter[START_DATE_FILTER] = "";
      }

      if (endInput.value) {
        filter[END_DATE_FILTER] = formatDate(new Date(endInput.value));
      } else {
        filter[END_DATE_FILTER] = "";
      }
    }

    renderReport();
  };

  var dialog = context.popupManager.createPopup();
  dialog.content.id = "wdr-popup-format-cells";
  dialog.setTitle(context.osUtils.isMobile ? "Date" : "Date Filter");
  dialog.setToolbar(
    [
      {
        id: "wdr-btn-apply",
        label: Labels.apply,
        handler: applyHandler,
        isPositive: true,
      },
      { id: "wdr-btn-cancel", label: Labels.cancel },
    ],
    true
  );

  var content = document.createElement("div");
  var group = document.createElement("div");
  group.classList.add("wdr-inp-group");
  content.appendChild(group);

  var row = document.createElement("div");
  row.classList.add("wdr-inp-row");
  row.classList.add("wdr-ir-horizontal");
  group.appendChild(row);

  // measures
  var label = document.createElement("label");
  label.classList.add("wdr-uc");
  self.setText(label, Labels.choose_value);
  row.appendChild(label);
  var select = self.createSelect();
  var valuesDropDown = select.select;
  valuesDropDown.onchange = valuesDropDownChangeHandler;
  valuesDropDown.options[0] = new Option(Labels.choose_value, "empty");
  valuesDropDown.options[0].disabled = true;
  valuesDropDown.options[1] = new Option("Today", "today");
  valuesDropDown.options[2] = new Option("Yesterday", "yesterday");
  valuesDropDown.options[3] = new Option("This Month", "this_month");
  valuesDropDown.options[4] = new Option("Last Month", "last_month");
  valuesDropDown.options[5] = new Option("This Year", "this_year");
  valuesDropDown.options[6] = new Option("Last Year", "last_year");
  valuesDropDown.options[7] = new Option("This F/Y", "this_fy");
  valuesDropDown.options[8] = new Option("Last F/Y", "last_fy");
  valuesDropDown.options[9] = new Option("Custom", "custom");
  row.appendChild(select);

  // Custom dates
  var row = document.createElement("div");
  row.setAttribute("id", "custom_date");
  row.style.display = "none";
  row.classList.add("wdr-inp-row");
  row.classList.add("wdr-ir-horizontal");
  group.appendChild(row);
  // <-- Start date label
  var startLabel = document.createElement("label");
  self.setText(startLabel, "Start Date");
  row.appendChild(startLabel);
  var nullValueInput = document.createElement("p");
  nullValueInput.classList.add("wdr-inp");
  nullValueInput.innerText = "Start Date";
  row.appendChild(nullValueInput);
  // <-- Start date input
  var start = document.createElement("label");
  self.setText(start, "Start Date");
  start.innerHTML = "Start Date";
  row.appendChild(start);
  var startInput = document.createElement("input");
  startInput.classList.add("wdr-inp");
  startInput.classList.add("bs-date");
  startInput.type = "date";
  row.appendChild(startInput);
  // <-- End date filter
  var label = document.createElement("label");
  self.setText(label, "End Date");
  row.appendChild(label);
  var endLabel = document.createElement("p");
  endLabel.classList.add("wdr-inp");
  endLabel.style.paddingTop = "10px";
  endLabel.innerText = "End Date";
  row.appendChild(endLabel);
  // <-- End date input
  var end = document.createElement("label");
  self.setText(label, "End Date");
  end.innerHTML = "End Date";
  row.appendChild(end);
  var endInput = document.createElement("input");
  endInput.classList.add("wdr-inp");
  endInput.classList.add("bs-date");
  endInput.type = "date";
  row.appendChild(endInput);

  var row = document.createElement("div");
  row.classList.add("wdr-inp-row");
  row.classList.add("wdr-ir-horizontal");
  group.appendChild(row);

  var group = document.createElement("div");
  group.classList.add("wdr-inp-group");
  content.appendChild(group);

  dialog.setContent(content);
  context.popupManager.addPopup(dialog.content);

  valuesDropDownChangeHandler();
}

function customExportHandler(context, type) {
  type == "pdf" ? customPdfExport(context) : customExport(context, type);
}

function customExport(context, type) {
  /** Create popup to specify filename */
  var self = context;
  var Labels = context.Labels;
  var defaultTitle = `${currModule.toUpperCase()}-${reportDate()}`;

  var applyHandler = function () {
    self.pivot.exportTo(type, {
      filename: fileInput.value ? fileInput.value : defaultTitle,
    });
  };

  var dialog = context.popupManager.createPopup();
  dialog.setTitle("Specify File name");
  dialog.setToolbar([
    {
      id: "wdr-btn-apply",
      label: Labels.apply,
      handler: applyHandler,
      isPositive: true,
    },
    { id: "wdr-btn-cancel", label: Labels.cancel },
  ]);

  var content = document.createElement("div");

  // Filename
  var file = document.createElement("label");
  file.innerHTML = "Filename";
  content.appendChild(file);
  var fileInput = document.createElement("input");
  fileInput.classList.add("wdr-inp");
  fileInput.type = "text";
  fileInput.value = defaultTitle;
  content.appendChild(fileInput);

  dialog.setContent(content);
  context.popupManager.addPopup(dialog.content);
}

function customPdfExport(context) {
  var self = context;
  var Labels = context.Labels;
  var defaultTitle = `${currModule.toUpperCase()}-${reportDate()}`;

  var applyHandler = function () {
    var orientation = "portrait";
    if (landscapeRadio.checked) {
      orientation = "landscape";
    }

    var title = titleInput.value ? titleInput.value : defaultTitle;

    self.pivot.exportTo("pdf", {
      pageOrientation: orientation,
      filename: fileInput.value ? fileInput.value : defaultTitle,
      header: `<h1 style="text-align:center;">${title}</h1>`,
      footer: `<div>${currUser.surname} ${currUser.firstname} - ##CURRENT-DATE##</div>`,
    });
  };

  var dialog = context.popupManager.createPopup();
  dialog.setTitle(Labels.choose_page_orientation);
  dialog.setToolbar([
    {
      id: "wdr-btn-apply",
      label: Labels.apply,
      handler: applyHandler,
      isPositive: true,
    },
    { id: "wdr-btn-cancel", label: Labels.cancel },
  ]);

  var content = document.createElement("div");

  var list = document.createElement("ul");
  list.classList.add("wdr-radiobtn-list");
  content.appendChild(list);

  // portrait
  var item = document.createElement("li");
  list.appendChild(item);
  var wrap = document.createElement("div");
  wrap.classList.add("wdr-radio-wrap");
  item.appendChild(wrap);

  var portraitRadio = document.createElement("input");
  portraitRadio.id = "wdr-portrait-radio";
  portraitRadio.type = "radio";
  portraitRadio.name = "wdr-pdf-orientation";
  portraitRadio.checked = true;
  wrap.appendChild(portraitRadio);

  var label = document.createElement("label");
  label.setAttribute("for", "wdr-portrait-radio");
  self.setText(label, Labels.portrait);
  wrap.appendChild(label);

  // landscape
  var item = document.createElement("li");
  list.appendChild(item);
  var wrap = document.createElement("div");
  wrap.classList.add("wdr-radio-wrap");
  item.appendChild(wrap);

  var landscapeRadio = document.createElement("input");
  landscapeRadio.id = "wdr-landscape-radio";
  landscapeRadio.type = "radio";
  landscapeRadio.name = "wdr-pdf-orientation";
  wrap.appendChild(landscapeRadio);

  var label = document.createElement("label");
  label.setAttribute("for", "wdr-landscape-radio");
  self.setText(label, Labels.landscape);
  wrap.appendChild(label);

  // Report title
  var title = document.createElement("label");
  title.innerHTML = "Report Title";
  content.appendChild(title);
  var titleInput = document.createElement("input");
  titleInput.classList.add("wdr-inp");
  titleInput.type = "text";
  titleInput.value = defaultTitle;
  content.appendChild(titleInput);

  // Filename
  var file = document.createElement("label");
  file.innerHTML = "Filename";
  content.appendChild(file);
  var fileInput = document.createElement("input");
  fileInput.classList.add("wdr-inp");
  fileInput.type = "text";
  fileInput.value = defaultTitle;
  content.appendChild(fileInput);

  dialog.setContent(content);
  context.popupManager.addPopup(dialog.content);
}

function handleSearch(context) {
  var self = context;
  var Labels = context.Labels;

  var valuesDropDownChangeHandler = function () {
    if (valuesDropDown.value == "") {
      // Hide Input
      document.getElementById("column_value").style.display = "none";
    } else {
      // Show input
      document.getElementById("column_value").style.display = "block";
    }
  };

  var applyHandler = function () {
    if (valuesDropDown.value != "") {
      renderReport({
        [valuesDropDown.value]: document.getElementById("search_key").value,
      });
    }
  };

  var dialog = context.popupManager.createPopup();
  dialog.content.id = "wdr-popup-search";
  dialog.setTitle("Search");
  dialog.setToolbar(
    [
      {
        id: "wdr-btn-apply",
        label: Labels.apply,
        handler: applyHandler,
        isPositive: true,
      },
      { id: "wdr-btn-cancel", label: Labels.cancel },
    ],
    true
  );

  var content = document.createElement("div");
  var group = document.createElement("div");
  group.classList.add("wdr-inp-group");
  content.appendChild(group);

  var row = document.createElement("div");
  row.classList.add("wdr-inp-row");
  row.classList.add("wdr-ir-horizontal");
  group.appendChild(row);

  // Generate select options
  var fieldLabel = document.createElement("label");
  self.setText(fieldLabel, "Field");
  row.appendChild(fieldLabel);
  var fieldInput = document.createElement("p");
  fieldInput.classList.add("wdr-inp");
  fieldInput.innerText = "Field";
  row.appendChild(fieldInput);
  // Columns
  var label = document.createElement("label");
  label.classList.add("wdr-uc");
  self.setText(label, "Choose Field");
  row.appendChild(label);
  var select = self.createSelect();
  var valuesDropDown = select.select;
  valuesDropDown.onchange = valuesDropDownChangeHandler;
  valuesDropDown.options[0] = new Option("Choose Field", "");
  valuesDropDown.options[0].disabled = true;
  generateColumnSelectOptions().forEach((option, i) => {
    valuesDropDown.options[i + 1] = new Option(
      option.name.charAt(0).toUpperCase() + option.name.slice(1),
      option.id
    );
  });
  row.appendChild(select);

  // Input
  var row = document.createElement("div");
  row.setAttribute("id", "column_value");
  row.style.display = "none";
  row.classList.add("wdr-inp-row");
  row.classList.add("wdr-ir-horizontal");
  group.appendChild(row);
  // <--
  var startLabel = document.createElement("label");
  self.setText(startLabel, "Search Key");
  row.appendChild(startLabel);
  var nullValueInput = document.createElement("p");
  nullValueInput.classList.add("wdr-inp");
  nullValueInput.innerText = "Search Key";
  row.appendChild(nullValueInput);
  // <-- input
  var start = document.createElement("label");
  self.setText(start, "Search Key");
  start.innerHTML = "Search Key";
  row.appendChild(start);
  var valueInput = document.createElement("input");
  valueInput.classList.add("wdr-inp");
  valueInput.classList.add("bs-date");
  valueInput.type = "text";
  valueInput.setAttribute("placeholder", "Enter Search Key");
  valueInput.setAttribute("id", "search_key");
  row.appendChild(valueInput);

  var row = document.createElement("div");
  row.classList.add("wdr-inp-row");
  row.classList.add("wdr-ir-horizontal");
  group.appendChild(row);

  var group = document.createElement("div");
  group.classList.add("wdr-inp-group");
  content.appendChild(group);

  dialog.setContent(content);
  context.popupManager.addPopup(dialog.content);

  valuesDropDownChangeHandler();
}

function getCurrentUser() {
  fetch(`${HOST}/intranet/report/current-user`)
    .then((resp) => resp.json())
    .then((user) => {
      currUser = user;
    })
    .catch((err) => err);
}

$(document).ready(function () {
  if (!document.getElementById("wdr-component")) return;

  getModules()
    .then((resp) => resp.json())
    .then((data) => {
      modules = data;
      renderReport();
    });

  getCurrentUser();
});
