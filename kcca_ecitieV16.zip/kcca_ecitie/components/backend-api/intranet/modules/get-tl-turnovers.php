<?php
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

header("Content-type: application/json");
$instance = KetrouteApplication::instance();
$turnovers = $instance->db()->getList(
    "tl_turnover",
    $where = null,
    $fields = '*'
);

echo json_encode(["turnovers" => $turnovers,"status" => 200]);

exit;
