<?php
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

header("Content-type: application/json");

$business_id = KRequest::getQueryString("business_id", null);
$instance = KetrouteApplication::instance();
$trade_licence_business = null;
try {
    $trade_licence_business = $instance->database()->load('trading_license', array(
        'id' => $business_id
    ));
} catch (Exception $e) {
}

if ($trade_licence_business) {

    $liablity_types = array(
        'limited' => array('id' => 'limited', 'name' => 'Limited Liability'),
        'sole' => array('id' => 'sole', 'name' => 'Sole Proprietorship'),
        'others' => array('id' => 'others', 'name' => 'Others')
    );

    try {
        $trade_licence_business->customer = $this->runtime()->getFieldData('customer_id', (array)$trade_licence_business);
    } catch (\Exception $th) {
        $trade_licence_business->customer = "";
    }

    try {
        $trade_licence_business->nature_of_business = $instance->db()->load($table = 'nature_of_business', $where = array('id' => $trade_licence_business->business_type_id));
    } catch (\Exception $th) {
        $trade_licence_business->nature_of_business = "";
    }

    try {
        $trade_licence_business->division = $instance->db()->load($table = 'division', $where = array('id' => $trade_licence_business->division));
    } catch (\Exception $th) {
        $trade_licence_business->division = "";
    }

    try {
        $trade_licence_business->parish = $instance->db()->load($table = 'parish', $where = array('id' => $trade_licence_business->parish));
    } catch (\Exception $th) {
        $trade_licence_business->parish = "";
    }

    try {
        $trade_licence_business->village = $instance->db()->load($table = 'village', $where = array('id' => $trade_licence_business->village));
    } catch (\Exception $th) {
        $trade_licence_business->village = "";
    }

    try {
        $trade_licence_business->street = $instance->db()->load($table = 'street', $where = array('id' => $trade_licence_business->street));
    } catch (\Exception $th) {
        $trade_licence_business->street = "";
    }

    try {
        $trade_licence_business->business_records_kept = $instance->db()->load($table = 'business_records_kept', $where = array('id' => $trade_licence_business->business_records_kept));
    } catch (\Exception $th) {
        $trade_licence_business->business_records_kept = "";
    }

    try {
        $trade_licence_business->business_category_id = $instance->db()->load($table = 'tl_business_category', $where = array('id' => $trade_licence_business->business_category_id));
    } catch (\Exception $th) {
        $trade_licence_business->business_category_id = "";
    }

    try {
        $trade_licence_business->liability_type = $liablity_types[$trade_licence_business->liability_type];
    } catch (\Exception $th) {
        $trade_licence_business->liability_type = "";
    }

    try {
            
        $latest_application = $instance->db()->load(
                $table="trading_license_application",
                $where=array(
                    'trading_license_id'=>$business_id,
                    'status_id'=>1),
                $fields="*",
                $where_in = null,
                $likeforlike_binding = null, 
                $startwith_binding = null, 
                $endwith_binding = null, 
                $hasatleast_binding = null,
                $greaterthanequal_binding = null,
                $lessthanequal_binding = null, 
                $between_binding = null, 
                $year_binding = null,
                $order_ascending = null,
                $order_descending = array('financial_year')
        );

        if ($latest_application) {

            $application_license_expiry_date = strtotime($latest_application->license_expiry_date);
            $today = strtotime(date("Y-m-d h:m:s"));
            if ($today < $application_license_expiry_date) {
                $validity = (object)array('name'=>'Active');
            }else {
                $validity = (object)array('name'=>'Expired');
            }
            
            $trade_licence_business->validity_status = $validity;
            $trade_licence_business->expiry = date("d M Y", strtotime($latest_application->license_expiry_date));
        }

    } catch (\Exception $th) {
        $trade_licence_business->validity_status = "";
        $trade_licence_business->expiry = "";
    }

    try {
        $trade_licence_business->latest_payment_year = "";
    } catch (\Exception $th) {
        $trade_licence_business->latest_payment_year = "";
    }
}

echo json_encode(["details" => $trade_licence_business, "status" => 200]);

exit;
