<?php
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

header("Content-type: application/json");
$instance = KetrouteApplication::instance();
$where_clause = array('status_id'=>KStatus::ACTIVE);
$result = array(
    array('id'=>'limited','name'=>'Limited Liability'),
    array('id'=>'sole', 'name'=>'Sole Proprietorship'),
    array('id'=>'others','name'=>'Others')
);

echo json_encode(["result" => $result,"status" => 200]);

exit;
