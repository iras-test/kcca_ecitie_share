<?php
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

header("Content-type: application/json");
$instance = KetrouteApplication::instance();
$where_clause = array('status_id'=>KStatus::ACTIVE);
$result = array(
    array('id'=>DataServiceManager::URA_ISSUE_NONE,'name'=> KLanguage::getWord('registration-ura-issue-none')),
    array('id'=>DataServiceManager::URA_ISSUE_OWNER_DETAILS_INVALID, 'name'=>KLanguage::getWord('registration-ura-issue-owner-details-invalid')),
    array('id'=>DataServiceManager::URA_ISSUE_VEHICLE_DETAILS_INVALID,'name'=>KLanguage::getWord('registration-ura-issue-vehicle-details-invalid'))
);

echo json_encode(["result" => $result,"status" => 200]);

exit;
