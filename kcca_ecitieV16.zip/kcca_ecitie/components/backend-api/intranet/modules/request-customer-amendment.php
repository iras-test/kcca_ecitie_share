<?php
header("Content-type: application/json");
AuthWrapper::getAuthenticatedUser();

$status = 400;

if(KRequest::isPosted()){
		// user identifier
        $intUserID = KSecurity::getUserID();
        $posted_data = KRequest::getPost("data");
        $posted_data = json_decode($posted_data,true);
        $details_data = $posted_data["details"];
        $contacts_reference_data = $posted_data["contacts-reference-agent"];
        $customer_id = KRequest::getPost("customer_id");
		
		if(!$details_data){
			$message = KLanguage::getWord('customer-no-individual-details');
		}
		
		if(!$contacts_reference_data){
			$message = KLanguage::getWord('customer-no-contacts-reference-agent-details');
		}
				
		// we have an error
		if(!$message){
			

			// customer details: duplicate check
			try{
				$arrCustomerObject 	= array_merge($details_data['details_'],$details_data['identity_']);	
				$arrCustomerObject 	= array_merge($arrCustomerObject,$details_data['contacts_']);	
				$arrCustomerObject 	= array_merge($arrCustomerObject,$details_data['address_']);	
				$arrCustomerObject 	= array_merge($arrCustomerObject,$details_data['citizenship_']);
				$objCustomerObject	= (object)$arrCustomerObject;
				$objCustomerObject->id = $customer_id;
				$this->invoke('CustomerManager', 'duplicateCheckIndividual', array($objCustomerObject), $required = true);
			}
			catch(Exception $e){
				$message = $e->getMessage();
			}
			
			// check if we stil have errors
			if(!$message){
				// save forced action details
				if($details_data['question_']['is_forced_action'] == 1){					
					$arrForcedAction = array();
					$arrForcedAction['customer_id']				= $objCustomerObject->id;
					$arrForcedAction['recommender_surname']		= $details_data['forced_']['recommender_surname'];
					$arrForcedAction['recommender_firstname']	= $details_data['forced_']['recommender_firstname'];
					$arrForcedAction['recommender_mobile']		= $details_data['forced_']['recommender_mobile'];
					$arrForcedAction['recommender_email']		= $details_data['forced_']['recommender_email'];
					$arrForcedAction['information_source']		= $details_data['forced_']['information_source'];
					$arrForcedAction['remarks']					= $details_data['forced_']['remarks'];
					
					$arrForcedAction['status_id']				= KStatus::ACTIVE;
					$arrForcedAction['created_by']				= $intUserID;
					$intForcedAction = $this->database()->createRecord('forced_action', $arrForcedAction, array('created_date' => KetrouteApplication::db()->getNowExpression()));
				}
				// create acknowledgement
				$objAcknowledgement = new stdClass;
				$objAcknowledgement->form_code 		= AcknowledgementManager::COIN_REGISTRATION_FORM_AMENDMENT_FOR_INDIVIDUAL_CODE;
				$objAcknowledgement->reference_name = 'customer';
				$objAcknowledgement->reference_id	= $objCustomerObject->id;
				$objAcknowledgement->status_id 		= KStatus::PENDING;
                $objAcknowledgement->created_by 	= $intUserID;	
				$objAcknowledgement->data_set		= KRequest::getPost("data");	
				$strReferenceNumber 				= AcknowledgementManager::saveToAcknowledgement($objAcknowledgement);
				
				// capture audit log
				$this->logAuditTrail("Captured Amendment of Registration for Individual", 'registration', $objCustomerObject->id);
				
				
				if ($details_data['question_']['is_forced_action'] == 1) {
					// load acknowledgement object
					$objAcknowledgement = $this->database()->load('acknowledgement', array('acknowledgement_reference' => $strReferenceNumber));
					
					// update forced action table with acknowledgement id					
					$this->database()->updateRecord('forced_action', array('acknowledgement_id' => $objAcknowledgement->id), array('id' => $intForcedAction), $one_record = true);
					
				} else {
					// send a notification
					$objCustomer = $this->database()->load('customer', array('id' => $objCustomerObject->id));
					CustomerManager::sendCustomerAmendmendNotification($objCustomer,KLanguage::getWord('acknowledgement-form-'. strtolower(AcknowledgementManager::COIN_REGISTRATION_FORM_AMENDMENT_FOR_INDIVIDUAL_CODE)) ,  $strReferenceNumber);
					
                }
                
                $status = 200;
                $message = "Amendment Request Submitted Successfully";
							
			}
		}
}else{
    $message = "Method not Allowed";
}

echo json_encode([
    "message" => $message,
    "status" => $status,
]);
exit;