<?php

/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin	

$business_seal_id = KRequest::getQueryString("id", null);
$notfy =  KRequest::getQueryString("notify", 0);

$business_seal_obj = null;

if ($business_seal_id) {

    $business_seal_obj = BusinessSealManager::getBusinessSealActionByID($business_seal_id);
} else {

    KSecurity::setActionWarning("Business Seal details must be provided");
}

if ($business_seal_obj) {


    $payment_bill_details = (object)ArrearCase::getItem($business_seal_obj->arrears_case_id);
    $outstanding_balance = number_format(abs( $payment_bill_details->arrear_amount));
    $customer = $payment_bill_details->customer;
    $business_details = ArrearsManager::getBusinessDetails($payment_bill_details->ref_name, $payment_bill_details->ref_id);

    $objPDF = new KPDF();
    $objPDF->Open();
    $objPDF->SetTextColor(0, 0, 0);

    if (KFile::exists(KFW_IMAGE_PATH . 'document-coat-of-arms.jpeg')) {
        $objPDF->setHeaderImage(array('src'     => KFW_IMAGE_PATH . 'document-coat-of-arms.jpeg', 'width'     => 0, 'height'     => 25, 'ext'         => KFile::getMime('document-logo.jpg'), 'url' => KetrouteApplication::getUrl()));
    }
    // set header image properties with logo.jpg
    else if (KFile::exists(KFW_IMAGE_PATH . 'coat-of-arms.jpg')) {
        $objPDF->setHeaderImage(array('src'     => KFW_IMAGE_PATH . 'coat-of-arms.jpeg', 'width'     => 0, 'height'     => 25, 'ext'         => KFile::getMime('logo.jpg'), 'url' => KetrouteApplication::getUrl()));
    }

    $objPDF->AddPage();
    $objPDF->SetMargins(10, 15);
    $objPDF->SetAutoPageBreak(true, 25);
    $objPDF->SetFont('arial', '', 8);
    $objPDF->AliasNbPages();

    $objPDF->SetTitle('Business Seal');
    $objPDF->SetAuthor(KSystem::author());
    $objPDF->SetCreator('Ketroute Framework: FPDF Engine');
    $objPDF->setCopyright(str_replace('[system_year]', date('Y'), KetrouteApplication::reg()->get('COPYRIGHT', '')));
    $objPDF->SetSubject(KetrouteApplication::reg()->get('APPLICATION_NAME', KSystem::name()));

    $objPDF->DisplayPreferences('DisplayDocTitle');

    $objPDF->setY(25);
    $objPDF->setX(155);
    $objPDF->SetFont('arial', 'B', 10);
    $objPDF->SetTextColor(0, 0, 0);
    $objPDF->SetWidths(array(40));
    $objPDF->FancyRow(array("FORMRF14"), array(0), array('L'), array(''), null, null);
    $objPDF->SetX(155);
    $objPDF->SetFont('arial', 'I', 10);
    $objPDF->FancyRow(array("Section 31"), array(0), array('L'));

    $objPDF->SetFont('arial', '', 11);
    $objPDF->SetWidths(array(170));
    $objPDF->SetDrawColor(0, 0, 0);
    $objPDF->FancyRow(array('THE REPUBLIC OF UGANDA'), array(0), array('C'));

    $objPDF->ln(3);
    $objPDF->SetFont('arial', '', 12);
    $objPDF->SetDrawColor(0, 0, 0);
    $objPDF->FancyRow(array('THE LOCAL GOVERNMENTS (RATING) ACT'), array(0), array('C'));
    $objPDF->FancyRow(array('KAMPALA CAPITAL CITY AUTHORITY'), array(0), array('C'));

    $objPDF->Ln(6);
    $objPDF->SetFont('arial', '', 10);

    $objPDF->SetX(15);
    $objPDF->FancyRow(array('To'), array(0), array('L'));
    $objPDF->SetX(15);

    $objPDF->SetWidths(array(50, 100));
    $objPDF->FancyRow(array('City Operator:', $customer), array(0, 0), array('L', 'L'), array('', 'B'));

    $objPDF->SetX(15);
    $objPDF->SetFont('', '', 10);
    $objPDF->FancyRow(array('Revenue Type:', $payment_bill_details->revenue_name), array(0), array('L'), array('', 'BU'));

    $objPDF->SetX(15);
    $objPDF->SetFont('', '', 10);
    $objPDF->FancyRow(array('Branch Location:', $business_details->location), array(0), array('L'), array('', 'BU'));

    $objPDF->SetX(15);
    $objPDF->SetFont('', '', 10);
    $objPDF->SetWidths(array(50, 50));
    $objPDF->FancyRow(array('Branch Code:', $business_details->branch_code), array(0), array('L'), array('', 'BU'));

    $objPDF->SetWidths(array(170));

    $objPDF->Ln(10);
    $objPDF->SetFont('', '', 12);
    $objPDF->SetDrawColor(0, 0, 0);
    $objPDF->FancyRow(array('NOTICE OF BUSINESS SEAL'), array(0), array('C'));
    $objPDF->SetFont('arial', 'I', 10);
    $objPDF->FancyRow(array('Under Section 31 of the Act'), array(0), array('C'));

    $objPDF->Line(15, 105, 180, 105);
    $objPDF->Line(15, 105, 180, 105);


    $objPDF->SetWidths(array(161));
    $objPDF->Ln(8);
    $objPDF->SetFont('arial', '', 10);

    $objPDF->SetX(20);
    $objPDF->FancyRow(array("1.  Undersection 37 of the Act, the local government is empowered to seal a business branch on failure to comply with the tax policy."), array(0), array('L'));

    $objPDF->ln(2);

    $objPDF->SetX(20);
    $objPDF->FancyRow(array("2.  A rate of Ug.shs {$outstanding_balance} is owing in respect of the business branch described above."), array(0), array('L'));

    $objPDF->ln(2);

    $objPDF->SetX(20);
    $objPDF->FancyRow(array("Business Seal Details"), array(0), array('L'), array('BU'));

    $objPDF->ln(2);

    $objPDF->SetX(20);
    $objPDF->SetWidths(array(50, 50));
    $objPDF->FancyRow(array('Seal Number:', $business_seal_obj->seal_number), array(0, 0), array('L', 'L'), array('', 'B'));

    $objPDF->SetX(20);
    $objPDF->SetFont('', '', 10);
    $objPDF->FancyRow(array('Seal Date:', date('d-m-Y', strtotime($business_seal_obj->created_date))), array(0), array('L'), array('', 'BU'));


    $objPDF->ln(4);
    $objPDF->SetWidths(array(11, 30));
    $objPDF->SetX(15);
    $objPDF->SetFont('', '', 10);
    $objPDF->FancyRow(array('Sign: ', '                    '), array(0), array('L'), array('', 'U'));


    $objPDF->ln(2);
    $objPDF->SetFont('arial', '', 11);
    $objPDF->SetWidths(array(170));
    $objPDF->SetX(15);
    $objPDF->FancyRow(array('DIRECTOR REVENUE COLLECTION'), array(0), array('L'));
    $objPDF->SetX(15);
    $objPDF->FancyRow(array('KAMPALA CAPITICAL CITY AUTHORITY'), array(0), array('L'), array('B'));


    // $objPDF->Line(16,207,181,207);
    // $objPDF->Line(16,207,181,207);

    // $objPDF->ln(4);
    // $objPDF->SetX(15);
    // $objPDF->SetFont('arial','',10);
    // $objPDF->FancyRow(array('IMPORTANT: This notice is only effective if the payment obligation of the occupier or tenant to the owner is due.'),array(0),array('L'));

    $status_show = null;

    if ($business_seal_obj->seal_status == BusinessSealManager::BUSINESS_SEAL_REVOKE) {

        $status_show = 'R E V O K E D';
    }

    // if ($agency_notice_obj->agency_notice_status == 1) {

    //     $status_show = 'N O T A P P R O V E D';

    // }

    // if ($agency_notice_obj->agency_notice_status == AgencyNoticeManager::STATUS_CLOSE) {

    //     $status_show = 'C L O S E D';

    // }

    // if ($agency_notice_obj->agency_notice_status == AgencyNoticeManager::STATUS_REJECT) {

    //     $status_show = 'R E J E C T E D';

    // }

    if ($status_show) {

        $objPDF->SetDrawColor(255, 0, 0);
        $objPDF->Line(78, 128, 128, 75);
        $objPDF->Line(76, 128, 126, 75);
        $objPDF->SetFont('helvetica', 'B', 18);
        $objPDF->SetTextColor(255, 0, 0);
        $objPDF->Rotate(45, 100, 60);
        $objPDF->Text(45, 100, $status_show);
        $objPDF->Rotate(0);
        $objPDF->Line(90, 138, 140, 85);
        $objPDF->Line(88, 138, 138, 85);
    }



    $timestamp = date('Y-m-d h_m');
    $pdf_content = $objPDF->Output("BUSINESS-SEAL-{$timestamp}.pdf", 'S');

    if ($notfy) {
        NotificationManager::notifyBusinessSealPrint($business_seal_obj);
    }

    header("X-MT-Framework: KFramework");
    header("X-MT-SYSName: " . KSystem::name());
    header("Pragma: no-cache");
    header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
    header("Content-Description: File Transfer");
    header("Content-type: " . KFile::getMime('FILE.PDF'));
    header("Content-Length: " . strlen($pdf_content));
    header("Content-transfer-encoding: binary");
    header("Content-Disposition: inline; filename=BUSINESS-SEAL-{$agent_info['name']}.pdf");
    header('Expires: 0');

    echo $pdf_content;

    exit;
}
