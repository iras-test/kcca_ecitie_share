<?php

if (KRequest::isPosted()) {

    $selected_escalation_action = KRequest::getPost('escalation_action');
    $case_id = KRequest::getPost('arrear_case_id');
    $comment = KRequest::getPost('comment');
    $reason = KRequest::getPost("reason");

    $current_assignment_id = KRequest::getPost('current_assignment');

    if ($current_assignment_id) {
        if ($reason == EscalationLevels::$ESCALATION_REASONS[0]) {
            ArrearCase::updateStatus($case_id, ArrearStatus::DUE_FOR_LITIGATION, null, null, null);
        }
        ArrearCase::addAssignmentComment($current_assignment_id, $comment, $reason);
        if (KRequest::isUploaded('attachments')) {

            $uploaded_attachments = KRequest::getUploadFile('attachments');
            $upload_errors = KRequest::getUploadError('attachments');
            $uploaded_file_mimes = KRequest::getUploadMime("attachments");
            $uploaded_file_names = KRequest::getUploadName("attachments");
            foreach ((array)$uploaded_attachments as $key => $attachment_path) {
                if ($upload_errors[$key] == UPLOAD_ERR_OK) {
                    $file_name = $uploaded_file_names[$key];
                    $file_name = KGenerator::licenseKey($file_name) . '.' . KFile::getExtension($file_name);
                    // try to save the attachment
                    $document_saved = KFile::uploadTemporaryFile($attachment_path, KFW_STORAGE_PATH . $this->getComponentRealname() . DIRECTORY_SEPARATOR . $file_name, null, KetrouteApplication::reg()->get('CREATE_STORAGE_IF_NOT_EXISTS', false));
                    if ($document_saved) {
                        $attachment_saved = $this->database()->createRecord(
                            'assignment_attachments',
                            array(
                                "assignment_id" => $current_assignment_id,
                                'document'             => 'escalation attachment',
                                'document_name'     => $uploaded_file_names[$key],
                                'document_mime'     => $uploaded_file_mimes[$key],
                                'document_sysname'     => $file_name,
                                "created_by" => KSecurity::getUserID()
                            ),
                            array('created_date' => KetrouteApplication::db()->getNowExpression())
                        );
                        // // capture audit log
                        $this->logAuditTrail("Attachemt uploaded for assignment #$current_assignment_id", 'assignment_attachments', $attachment_saved);
                    }
                }
            }
        }
    }

    ArrearCase::deactivatePreviousAssignments($case_id);
    $next_assignee = null;

    if ($selected_escalation_action == EscalationLevels::ESCALATE_FORWARD) {

        $next_assignee =  KRequest::getPost('assignee');
        
    } else {
        $current_user = KSecurity::getUserID();
        $current_user_level = EscalationLevels::getUserEscalationLevel($current_user);
        $previous_level = EscalationLevels::getLevelBefore($current_user_level);

        // find user from lower who esclated the case
        $level_role_id = $previous_level->role_id;
        $assignee_query = "SELECT top 1 created_by from  arrear_case_assignment where user_id = '$current_user' and created_by in (Select id from [user] where user_role_id = '$level_role_id') order by id desc";
        $result = KetrouteApplication::db()->execute($SQL)->fields;
        if($result){
            $next_assignee = $result->created_by;
        }else{
            $instance = KetrouteApplication::instance();
            $current_assignment = $instance->db()->load($table="arrear_case_assignment",$where=array('id'=>$current_assignment_id));
            $next_assignee = $current_assignment->created_by;
        }
    }
    ArrearCase::create_assignment($next_assignee, $case_id);

    KSecurity::setActionSuccess("Escalated Case Successfully");
    $this->stopRedirector("{$this->urlPath(0)}cases");
}
KSecurity::setActionWarning("Illegal Access Method");
$this->stopRedirector(KSecurity::getSession('BACK_URL'));
