<?php

/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin	

$agency_notice_id_Provided = KRequest::getQueryString("id", null);
$agent_issued_to = KRequest::getQueryString("t", null);
print($agent_issued_to);

$agency_notice_obj = null;

if ($agency_notice_id_Provided && ($agent_issued_to != null)) {

    $agency_notice_obj = AgencyNoticeManager::getCaseAgencyNoticeActionByID($agency_notice_id_Provided);
} else {

    KSecurity::setActionWarning("Agency notice and Agents details must be provided");
}

if ($agency_notice_obj) {


    $agent_info = json_decode($agency_notice_obj->agents_info, true)[$agent_issued_to];

    $payment_bill_details = (object)ArrearCase::getItem($agency_notice_obj->arrears_case_id);
    $outstanding_balance = number_format(abs($payment_bill_details->arrear_amount));
    $business_details = ArrearsManager::getBusinessDetails($payment_bill_details->ref_name, $payment_bill_details->ref_id);

    $location = $business_details->location;
    $gis_location = $business_details->gis_location;
    $branch_code = $business_details->branch_code;
    $owner_name = $this->runtime()->getFieldData('customer_id', (array)$business_details);

    $objPDF = new KPDF();
    $objPDF->Open();
    $objPDF->SetTextColor(0, 0, 0);

    $objPDF->AddPage();
    $objPDF->SetMargins(10, 15);
    $objPDF->SetAutoPageBreak(true, 25);
    $objPDF->SetFont('arial', '', 8);
    $objPDF->AliasNbPages();

    $objPDF->SetTitle('Agency Notice');
    $objPDF->SetAuthor(KSystem::author());
    $objPDF->SetCreator('Ketroute Framework: FPDF Engine');
    $objPDF->setCopyright(str_replace('[system_year]', date('Y'), KetrouteApplication::reg()->get('COPYRIGHT', '')));
    $objPDF->SetSubject(KetrouteApplication::reg()->get('APPLICATION_NAME', KSystem::name()));

    $objPDF->DisplayPreferences('DisplayDocTitle');

    $objPDF->setY(25);
    $objPDF->setX(155);
    $objPDF->SetFont('arial', 'B', 10);
    $objPDF->SetTextColor(0, 0, 0);
    $objPDF->SetWidths(array(40));
    $objPDF->FancyRow(array("FORMRF14"), array(0), array('L'), array(''), null, null);
    $objPDF->SetX(155);
    $objPDF->SetFont('arial', 'I', 10);
    $objPDF->FancyRow(array("Section 31"), array(0), array('L'));

    $objPDF->SetFont('arial', '', 11);
    $objPDF->SetWidths(array(170));
    $objPDF->SetDrawColor(0, 0, 0);
    $objPDF->FancyRow(array('THE REPUBLIC OF UGANDA'), array(0), array('C'));

    $objPDF->ln(3);
    $objPDF->SetFont('arial', '', 12);
    $objPDF->SetDrawColor(0, 0, 0);
    $objPDF->FancyRow(array('THE LOCAL GOVERNMENTS (RATING) ACT'), array(0), array('C'));
    $objPDF->FancyRow(array('KAMPALA CAPITAL CITY AUTHORITY'), array(0), array('C'));

    $objPDF->Ln(6);
    $objPDF->SetFont('arial', '', 10);

    $objPDF->SetX(15);
    $objPDF->FancyRow(array('TO'), array(0), array('L'), array('B'));

    $objPDF->SetX(15);
    $objPDF->SetWidths(array(40, 100));
    $objPDF->FancyRow(array('Tenant Name:', $agent_info['name']), array(0, 0), array('L', 'L'), array('', 'B'));

    $objPDF->Ln(2);
    $objPDF->SetX(15);
    $objPDF->SetWidths(array(40, 100));
    $objPDF->FancyRow(array('Property Address:', $location), array(0, 0), array('L', 'L'), array('', 'B'));

    $objPDF->Ln(2);
    $objPDF->SetX(15);
    $objPDF->SetFont('', '', 10);
    $objPDF->SetWidths(array(40, 70));
    $objPDF->FancyRow(array('Tenant Phone Contact:', $agent_info['phone_no']), array(0), array('L'), array('', 'B'));

    $objPDF->Ln(2);
    $objPDF->SetX(15);
    $objPDF->SetFont('', '', 10);
    $objPDF->SetWidths(array(40, 70));
    $objPDF->FancyRow(array('Tenant Email:', $agent_info['email']), array(0), array('L'), array('', 'B'));

    $objPDF->Ln(2);
    $objPDF->SetX(15);
    $objPDF->SetFont('', '', 10);
    $objPDF->SetWidths(array(40, 70));
    $objPDF->FancyRow(array('GIS Location:', $gis_location), array(0), array('L'), array('', 'B'));

    $objPDF->Ln(2);
    $objPDF->SetX(15);
    $objPDF->SetFont('', '', 10);
    $objPDF->SetWidths(array(40, 100));
    $objPDF->FancyRow(array('Property Owner Name:', $owner_name), array(0), array('L'), array('', 'B'));

    $objPDF->Ln(2);
    $objPDF->SetX(15);
    $objPDF->SetFont('', '', 10);
    $objPDF->SetWidths(array(40, 70));
    $objPDF->FancyRow(array('Property Number:', $branch_code), array(0), array('L'), array('', 'B'));


    $objPDF->SetWidths(array(170));

    $objPDF->Ln(6);
    $objPDF->SetFont('', '', 12);
    $objPDF->FancyRow(array('NOTICE OF DEMAND OF RATES FROM OCCUPIERS OR TENANTS'), array(0), array('C'), array('U'));
    $objPDF->SetFont('arial', 'I', 10);
    $objPDF->FancyRow(array('Under Section 31 of the Act'), array(0), array('C'));


    $objPDF->SetWidths(array(161));
    $objPDF->Ln(8);
    $objPDF->SetFont('arial', '', 10);

    $objPDF->SetX(20);
    $objPDF->FancyRow(array("1.  Undersection 37 of the Act, KCCA is empowered to collect rates from occupiers and tenants of properties in respect of which a rate is due."), array(0), array('L'));

    $objPDF->ln(2);

    $objPDF->SetX(20);
    $objPDF->FancyRow(array("2.  A rate of Ug.shs {$outstanding_balance} is owing in respect of the rateable property described above in which you are a tenant/or in occupation."), array(0), array('L'));

    $objPDF->ln(2);

    $objPDF->SetX(20);
    $objPDF->FancyRow(array("3.  This is to DEMAND that rental or other payments due from you to the owner be paid directly to KCCA and a receipt for the payment be obtained."), array(0), array('L'));

    $objPDF->ln(2);

    $objPDF->SetX(20);
    $objPDF->FancyRow(array("4.  If you pay this sum to KCCA, you will not be liable to the owner for rent or other payment to the owner to the extent of the amount paid by yourself to KCCA. If you refuse to pay to KCCA as required of you by this demand notice you will be charged with an offence under the Act."), array(0), array('L'));


    $objPDF->ln(8);
    $objPDF->SetWidths(array(25, 30));
    $objPDF->SetX(15);
    $objPDF->SetFont('', '', 10);
    $objPDF->FancyRow(array('Date Of Issue:', date('d-m-Y', strtotime($agency_notice_obj->created_date))), array(0), array('L'), array('', 'BU'));

    $objPDF->ln(10);
    $objPDF->SetWidths(array(11, 70));
    $objPDF->SetX(15);
    $objPDF->SetFont('', '', 10);
    $objPDF->FancyRow(array('Sign: ', '                                                    '), array(0), array('L'), array('', 'U'));


    $objPDF->SetFont('arial', '', 11);
    $objPDF->SetWidths(array(170));
    $objPDF->SetX(15);
    $objPDF->FancyRow(array('DIRECTOR REVENUE COLLECTION'), array(0), array('L'));
    $objPDF->SetX(15);
    $objPDF->FancyRow(array('KAMPALA CAPITICAL CITY AUTHORITY'), array(0), array('L'), array('B'));


    // $objPDF->Line(16,210,181,210);
    // $objPDF->Line(16,210,181,210);

    $status_show = null;

    if ($agency_notice_obj->agency_notice_status == AgencyNoticeManager::STATUS_OBJECT) {

        $status_show = 'O B J E C T E D';
    }

    if ($agency_notice_obj->agency_notice_status == 1) {

        $status_show = 'N O T A P P R O V E D';
    }

    if ($agency_notice_obj->agency_notice_status == AgencyNoticeManager::STATUS_CLOSE) {

        $status_show = 'C L O S E D';
    }

    if ($agency_notice_obj->agency_notice_status == AgencyNoticeManager::STATUS_REJECT) {

        $status_show = 'R E J E C T E D';
    }

    if ($status_show) {

        $objPDF->SetDrawColor(255, 0, 0);
        $objPDF->Line(78, 128, 128, 75);
        $objPDF->Line(76, 128, 126, 75);
        $objPDF->SetFont('helvetica', 'B', 18);
        $objPDF->SetTextColor(255, 0, 0);
        $objPDF->Rotate(45, 100, 60);
        $objPDF->Text(45, 100, $status_show);
        $objPDF->Rotate(0);
        $objPDF->Line(90, 138, 140, 85);
        $objPDF->Line(88, 138, 138, 85);
    }



    $timestamp = date('Y-m-d h_m');
    $pdf_content = $objPDF->Output("AGENCY-NOTICE-{$timestamp}.pdf", 'S');

    header("X-MT-Framework: KFramework");
    header("X-MT-SYSName: " . KSystem::name());
    header("Pragma: no-cache");
    header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
    header("Content-Description: File Transfer");
    header("Content-type: " . KFile::getMime('FILE.PDF'));
    header("Content-Length: " . strlen($pdf_content));
    header("Content-transfer-encoding: binary");
    header("Content-Disposition: inline; filename=AGENCY-NOTICE-{$agent_info['name']}.pdf");
    header('Expires: 0');

    echo $pdf_content;
    exit;
}
