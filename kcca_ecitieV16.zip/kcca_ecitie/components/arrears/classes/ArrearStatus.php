<?php

class ArrearStatus
{

    const OPEN = "Open";
    const CLOSED = "Closed";
    const UNDER_PAYMENT_PLAN = "Under payment plan";
    const UNDER_OBJECTION = "Under objection";
    const UNDER_AGENCY_NOTICE = "Under Agency Notice";
    const UNDER_BUSINESS_SEAL = "Under Business Seal";
    const UNDER_LITIGATION = "Under Litigation";
    const DEFFERED = "Deffered";
    const ASSIGNED = "Assigned";
    const PENDING_OFRC_ACTION = "Pending ORC Action";
    const LEGAL_DEPT = "Approving Authority";
    const INTENTION_TO_SUE = "Intention to Sue";
    const DUE_FOR_LITIGATION = "Due for Litigation";
    const DOES_NOT_QUALIFY = "other";
    const SENT_BACK = "Sent Back";
    const ORC = "Officer Revenue Collection";
    const SAM = "Supervisor Arrears Management";
    const MAI = "Manager Audit and Inspection";


    const BUSINESS_MOVED_TO_ARREARS = 50;
    const BUSINESS_ACTIVE = 1;
    public static $DIVISIONS_TO_MOVE = [1];

    // roles
    //  live
    const ARREARS_MANAGER_ROLE = 30;
    const ARREARS_OFFICER_ROLE = 31;
    const MANAGER_AUDIT_AND_INSPECTION = 32;
    const SUPERVISOR_REVENUE_COLLECTION = 35;

    // // test
    // const ARREARS_MANAGER_ROLE = 26;
    // const ARREARS_OFFICER_ROLE = 28;
    // const MANAGER_AUDIT_AND_INSPECTION = 27;
    // const SUPERVISOR_REVENUE_COLLECTION = 31;

    // actions
    const SEAL_BUSINESSS = "seal_business";
    const ISSUE_AGENCY_NOTICE = "issue_agency_notice";
    const REQUEST_PAYMENT_PLAN = "request_payment_plan";
    const ENGAGE_CUSTOMER = "engage_customer";

    /** Status Filter */
    public static $status_arr = array(
        array("id" => ArrearStatus::OPEN, "name" => ArrearStatus::OPEN),
        array("id" => ArrearStatus::ASSIGNED, "name" => ArrearStatus::ASSIGNED),
        array("id" => ArrearStatus::UNDER_AGENCY_NOTICE, "name" => ArrearStatus::UNDER_AGENCY_NOTICE),
        array("id" => ArrearStatus::UNDER_BUSINESS_SEAL, "name" => ArrearStatus::UNDER_BUSINESS_SEAL),
        array("id" => ArrearStatus::UNDER_OBJECTION, "name" => ArrearStatus::UNDER_OBJECTION),
        array("id" => ArrearStatus::UNDER_PAYMENT_PLAN, "name" => ArrearStatus::UNDER_PAYMENT_PLAN),
        array("id" => ArrearStatus::UNDER_LITIGATION, "name" => ArrearStatus::UNDER_LITIGATION),
        array("id" => ArrearStatus::DUE_FOR_LITIGATION, "name" => ArrearStatus::DUE_FOR_LITIGATION),
        array("id" => ArrearStatus::DEFFERED, "name" => ArrearStatus::DEFFERED),
        array("id" => ArrearStatus::SENT_BACK, "name" => ArrearStatus::SENT_BACK),
        array("id" => ArrearStatus::CLOSED, "name" => ArrearStatus::CLOSED),
    );

    public static $avaliable_action = array(
        ArrearStatus::SEAL_BUSINESSS,
        ArrearStatus::ISSUE_AGENCY_NOTICE,
        ArrearStatus::REQUEST_PAYMENT_PLAN,
        ArrearStatus::ENGAGE_CUSTOMER
    );

    public static function MapActionName($name)
    {
        $action_description = "";
        switch ($name) {
            case ArrearStatus::SEAL_BUSINESSS:
                $action_description = "Assigned To Seal Business";
                break;

            case ArrearStatus::ISSUE_AGENCY_NOTICE:
                $action_description = "Assigned To Issue Agency Notice";
                break;

            case ArrearStatus::REQUEST_PAYMENT_PLAN:
                $action_description = "Assigned To Request Payment Plan";
                break;

            case ArrearStatus::ENGAGE_CUSTOMER:
                $action_description = "Assigned To Engage Customer";
                break;

            default:
                break;
        }
        return $action_description;
    }
}
