<?php

(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
set_time_limit(0);

// run daily
$cases_due_litigation = LegalManager::getNonPaginatedList([]);
$biz_count = 0;
foreach ($cases_due_litigation as $index => $arrear_case) {

    print("$biz_count : updating case... ");

    # Update status
    $comment = "Arrear case status change";
    ArrearCase::updateStatus($arrear_case->id,  ArrearStatus::DUE_FOR_LITIGATION, $comment, null);
    $biz_count++;
}
