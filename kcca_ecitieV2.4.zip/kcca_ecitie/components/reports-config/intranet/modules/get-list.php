<?php
/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
// (defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
// # begin

// $arrCustomers = ReportsApiManager::getAllReportModuleConfigs();

// $data[] = array();

// if(!empty($arrCustomers))
// {
// 	foreach($arrCustomers as $id => $name)
// 	{
// 		$json = array();
// 		$json['id'] 	= $id;
// 		$json['value'] 	= $name;
// 		$data[] 		= $json;
// 	}
// }
// else{
// 	// no customers
// 	$json = array();
// 	$json['value'] 	= KLanguage::getWord('customer-no-customer-maching-criteria');
// 	$data[] 		= $json;
// }

// header("Content-type: application/json");
// echo json_encode($data);

// exit;