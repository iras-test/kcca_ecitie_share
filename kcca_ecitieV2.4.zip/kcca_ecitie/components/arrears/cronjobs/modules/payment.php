
<?php

/** Send out expiry notices to city operators whose payment plan has expired */
NotificationManager::notifyOnPayment('2150000000002');