
use ecitie;

DROP TABLE [dbo].[recovery_trail]

CREATE TABLE [dbo].[recovery_trail](
	[id] [INT] IDENTITY(1,1) NOT NULL,
    [reference_name] [VARCHAR](255) NULL,
    [branch_code] [VARCHAR](255) NULL,
    [picture] [VARCHAR](255) NULL,
    [picture_name] [VARCHAR](255) NULL,
    [picture_mime] [VARCHAR](200) NULL,
    [picture_sysname] [VARCHAR](200) NULL,
    [recovery_type_id] [SMALLINT] NOT NULL,
    [status_id] [SMALLINT] DEFAULT 1,
    [created_by] [INT] NULL,
    [created_date] [DATETIME2](0) NULL,
    [modified_by] [INT] NULL,
    [modified_date] [DATETIME2](0) NULL,
)
GO
