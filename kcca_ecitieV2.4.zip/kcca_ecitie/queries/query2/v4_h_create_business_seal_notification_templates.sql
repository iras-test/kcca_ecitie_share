-- email template ---

use ecitie;

INSERT INTO [dbo].[cms_email] (
      [lang]
      ,[uri]
      ,[subject]
      ,[content]
      ,[plaintext]
      ,[email_priority_id]
      ,[from_email]
      ,[from_name]
      ,[status_id]
      ,[created_date]
      ,[created_by]
      ,[modified_date]
      ,[modified_by] ) 
SELECT [lang]
      ,'business_seal_print_out' AS [uri]
      ,'Buiness Seal Print Out' AS [subject]
      ,'<p>Dear [name],</p><p>A business seal ([seal_no]) has been issued and printed for your business.</p><p><br />[site_name] Team</p>' AS [content]
      ,[plaintext]
      ,[email_priority_id]
      ,[from_email]
      ,[from_name]
      ,[status_id]
      ,[created_date]
      ,[created_by]
      ,[modified_date]
      ,[modified_by]
  FROM [dbo].[cms_email] 
  WHERE [id]='1115'

-- sms template ----

INSERT INTO [dbo].[cms_sms] (
      [lang]
      ,[code]
      ,[title]
      ,[content]
      ,[status_id]
      ,[created_date]
      ,[created_by]
      ,[modified_date]
      ,[modified_by] ) 
SELECT [lang]
      ,'business_seal_print_out' AS [code]
      ,'Buiness Seal Print Out' AS [title]
      ,'Dear [name], A business seal ([seal_no]) has been issued and printed for your business.. [site_name] MGT' AS [content]
      ,[status_id]
      ,[created_date]
      ,[created_by]
      ,[modified_date]
      ,[modified_by]
FROM [dbo].[cms_sms] 
WHERE [id]='50'