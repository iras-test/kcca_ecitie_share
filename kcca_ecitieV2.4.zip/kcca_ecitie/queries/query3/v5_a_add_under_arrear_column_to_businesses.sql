use ecitie;

ALTER TABLE [dbo].[property] ADD [under_arrears] TINYINT NOT NULL DEFAULT 0

ALTER TABLE [dbo].[vehicle] ADD [under_arrears] TINYINT NOT NULL DEFAULT 0

ALTER TABLE [dbo].[trading_license] ADD [under_arrears] TINYINT NOT NULL DEFAULT 0

ALTER TABLE [dbo].[outdoor] ADD [under_arrears] TINYINT NOT NULL DEFAULT 0
