<?php

(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

header("Content-type: application/json");

echo json_encode(["payment_types"=>PaymentManager::getPaymentTypes()]);
exit;