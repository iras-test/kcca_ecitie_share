<?php

$report_data = ReportsApiManager::getReportModules();

header("Content-type: application/json");

echo json_encode($report_data);
exit;