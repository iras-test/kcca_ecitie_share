<?php

$case_id = KRequest::getQueryString("case", $this->getParam('case', null));
$case = (object) ArrearCase::getItem($case_id);
$util = new Util();
$format = KRequest::getQueryString("format", "html");

if ($format == "json") {
    header("Content-type: application/json");
    AuthWrapper::getAuthenticatedUser();
}

if ($case && $case->ref_name && $case->ref_id) {

    $currentUser = KSecurity::getUserID();

    /** Handle form data */
    if (KRequest::isPosted()) {
        ArrearCaseFeedback::create($case);
        if ($format == "json") {
            echo json_encode([
                "message" => "Feedback Sucessfully Recorded",
                "status" => 200,
            ]);
            exit;
        }
        KResponse::redirect("{$this->urlPath(0)}case-details?id=$case->id");
    }

    $bills = ArrearsManager::getAllPaymentBills($case->ref_name, $case->ref_id);

    $feedback_types = ArrearCaseFeedback::getTypes();
    $feedback_types_options = "";
    foreach ($feedback_types as $key => $value) {
        $feedback_types_options .= "<option value=\"$value->id\">{$value->name}</option>";
    }

    $info_display = null;
    $prn = $case->prn ? $case->prn : "N/A";
    $case_status = ($case->status == null) ? ArrearStatus::OPEN : $case->status;
    $bal = ArrearsManager::getOutstandingBal($case->ref_name, $case->ref_id);
    $info = $case;
    $business_details = ArrearsManager::getBusinessDetails($info->ref_name, $info->ref_id);

    $extra_details = "";

    if ($info->ref_name == "vehicle") {
        $extra_details .= "<div class=\"pt10\">
                            <strong><span class=\"bs-bold\">Park</span></strong>: {$business_details->park_name}
                        </div>
                        <div class=\"pt10\">
                            <strong><span class=\"bs-bold\">Stage</span></strong>: {$business_details->stage_name}
                        </div>
                        ";
    }

    $info_display = "
        <div class=\"clear customer-blocks pb10\">
            <h1 class=\"kfw-active-title\"><strong>[lang-arrears-case-details]<strong></h1>
            <div class=\"clear pt10\">
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Customer</span></strong>: {$info->customer}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">COIN</span></strong>: {$info->coin}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Revenue name</span></strong>: {$info->ref_name}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Branch Code</span></strong>: {$business_details->branch_code}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Location</span></strong>: {$business_details->location}
                </div>
                {$extra_details}
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Outstanding balance</span></strong>: {$bal}
                </div>
                <div class=\"pt10\">
                    <strong><span class=\"bs-bold\">Status</span></strong>: <span class=\"{$util::StatusClass($case_status)}\">{$case_status}</span>
                </div>
            </div>
        </div>
    ";

    /** Bill breakdowns */
    $bills_record = "";
    if (count($bills) > 0) {
        // show record	
        foreach ($bills as $index => $arrData) {
            $class = ($index % 2 == 0) ? ' odd' : ' even';
            $obj = (object) $arrData;
            $record_number = $index + 1;
            $prn = $obj->prn ? $obj->prn : "N/A";

            $bills_record .= "<div class=\"clear list-item{$class}\">";
            $bills_record .= "\n\t\t\t<div class=\"fl numbering-col\">{$record_number}</div>";
            $bills_record .= "\n\t\t\t<div class=\"fl col20\">{$obj->financial_year}</div>";
            $bills_record .= "\n\t\t\t<div class=\"fl col20\">{$prn}</div>";
            $bills_record .= "\n\t\t\t<div class=\"fl col20\">{$obj->due_date}</div>";
            $bills_record .= "\n\t\t\t<div class=\"fl col20\">{$obj->amount}</div>";
            $bills_record .= "\n\t\t</div>";
        }
    } else {
        $records  = "\n\t\t<div class=\"clear list-item\">" . KLanguage::getWord('arrears-case-items') . "</div>";
    }

    return $this->render(array(
        "bills" => $bills_record,
        "info_display" => $info_display,
        "feedback_types_options" => $feedback_types_options,
        "form_action" =>  KRequest::getUri(),
        "form_identifier" => "mykfwform-{$this->getComponent()}-{$this->getModule()}",
        "back_url" => KSecurity::getSession('BACK_URL'),
    ));

} else {

    KSecurity::setActionWarning(KLanguage::getWord('arrears-no-case-specified'));
}
