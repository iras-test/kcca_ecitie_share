use ecitie;

ALTER TABLE recovery_trail ADD x_coordinates VARCHAR(255) NULL
ALTER TABLE recovery_trail ADD y_coordinates VARCHAR(255) NULL