use ecitie;

CREATE TABLE [dbo].[assignment_attachments](
	[id] [INT] IDENTITY(1,1) NOT NULL,
    [assignment_id] INT NOT NULL,
    [document] [VARCHAR](255) NULL,
    [document_name] [VARCHAR](255) NULL,
    [document_mime] [VARCHAR](200) NULL,
    [document_sysname] [VARCHAR](200) NULL,
    [created_by] [INT] NULL,
    [created_date] [DATETIME2](0) NULL,
    [modified_by] [INT] NULL,
    [modified_date] [DATETIME2](0) NULL,
)