
USE ecitie;

drop table [dbo].[arrear_case]

create table [dbo].[arrear_case] (
    id int IDENTITY(1,1) NOT NULL,
    closed smallint DEFAULT 0,
    closed_reason varchar(256) null,
    assignee int NULL,
    created_by int NULL,
	created_date datetime2(0) NULL,
	modified_by int NULL,
	modified_date datetime2(0) NULL
)