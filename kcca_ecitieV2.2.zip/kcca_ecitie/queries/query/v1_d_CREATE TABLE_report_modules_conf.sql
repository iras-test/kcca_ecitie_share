USE ecitie;

CREATE TABLE [dbo].[report_modules_config](
	[id] [int] IDENTITY(1,1) NOT NULL,
    [report_module_id] [int] NOT NULL,
	[column] [nvarchar](1000) NOT NULL,
	[to_table_column] [nvarchar](1000) NULL,
    [display_columns] [nvarchar](1000) NULL,
    [expand_relation] [smallint] NULL,
	[created_by] [int] NULL,
	[created_date] [datetime2](0) NULL,
	[modified_by] [int] NULL,
	[modified_date] [datetime2](0) NULL
)
GO