use ecitie;

CREATE TABLE [dbo].[arrears_agency_notice](
	[id] [int] IDENTITY(1,1) NOT NULL,
    [arrears_case_id] [int] NOT NULL,
	[issue_reason] [nvarchar](1000) NULL,
	[agents_info] [nvarchar](1000) NULL,
	[agency_notice_status] [int] DEFAULT 1,
	[created_by] [int] NULL,
	[created_date] [datetime2](0) NULL,
	[modified_by] [int] NULL,
	[modified_date] [datetime2](0) NULL,
)
GO