
use ecitie;

CREATE TABLE [dbo].[recovery_trail_reference] (
    id INT IDENTITY(1,1) NOT NULL,
    reference_name VARCHAR(255) NOT NULL,
    label VARCHAR(255) NOT NULL,
    status_id SMALLINT DEFAULT 1,
    modified_by INT NULL,
    modified_date DATETIME2(0) NULL,
    created_by INT NULL,
    created_date DATETIME2(0) NULL,
)

INSERT INTO [dbo].[recovery_trail_reference]
(reference_name, label) VALUES ('vehicle', 'Transport')

INSERT INTO [dbo].[recovery_trail_reference]
(reference_name, label) VALUES ('markets', 'Market Rent')

INSERT INTO [dbo].[recovery_trail_reference]
(reference_name, label) VALUES ('trade_license', 'Trade License')

INSERT INTO [dbo].[recovery_trail_reference]
(reference_name, label) VALUES ('property', 'Property')

INSERT INTO [dbo].[recovery_trail_reference]
(reference_name, label) VALUES ('ground_rent', 'Ground Rent')

INSERT INTO [dbo].[recovery_trail_reference]
(reference_name, label) VALUES ('outdoor', 'Outdoor')