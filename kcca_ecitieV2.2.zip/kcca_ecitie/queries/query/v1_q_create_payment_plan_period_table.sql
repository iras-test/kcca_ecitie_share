
USE ecitie;

drop table [dbo].[payment_plan_period]

create table [dbo].[payment_plan_period] (
    id int IDENTITY(1,1) not null,
    payment_plan_id int not null,
    payment_id int null,
    amount_stated varchar(256) not null,
    payment_date_stated datetime2(0) not null ,
    created_by int NULL,
	created_date datetime2(0) NULL,
	modified_by int NULL,
	modified_date datetime2(0) NULL
)