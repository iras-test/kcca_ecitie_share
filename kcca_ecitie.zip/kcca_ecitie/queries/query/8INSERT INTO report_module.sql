INSERT INTO [dbo].[report_modules] 
([name],[ignore_columns]) 
VALUES 
('payment','modified_by')