update component set permissions = 'login,arrearscases,arrearscasesdetails,user-details,business-references,feedback-types,business-recovery-trail,recovery-trail-types,add-field-activity,statement-of-account', 
module_nopermission_list = 'login,arrearscases,arrearscasesdetails,user-details,business-references,feedback-types,business-recovery-trail,recovery-trail-types,add-field-activity,statement-of-account', 
module_frontend_restriction = null, 
blocked_dptm = 'login,arrearscases,arrearscasesdetails,user-details,business-references,feedback-types,business-recovery-trail,recovery-trail-types,add-field-activity,statement-of-account', 
modules_over_ssl = '*' where title = 'backend-api'