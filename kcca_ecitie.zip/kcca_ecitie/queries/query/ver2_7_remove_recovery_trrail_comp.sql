
DELETE FROM component WHERE title = 'recovery-trail'