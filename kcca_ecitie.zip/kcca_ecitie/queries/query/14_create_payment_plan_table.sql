DROP TABLE arrears_payment_plan

CREATE TABLE [dbo].[arrears_payment_plan](
	[id] [int] IDENTITY(1,1) NOT NULL,
    [arrears_case_id] [int] NOT NULL,
	[creation_reason] [nvarchar](1000) NULL,
	[created_by] [int] NULL,
	[created_date] [datetime2](0) NULL,
	[modified_by] [int] NULL,
	[modified_date] [datetime2](0) NULL,
	[approval_status] [int] DEFAULT 0,
	[approved_by] [int] NULL,
	[approved_on] [datetime2](0) NULL
)
GO