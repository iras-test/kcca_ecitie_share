CREATE TABLE [dbo].[report_modules](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[name] [nvarchar](100) NOT NULL UNIQUE,
	[ignore_columns] [nvarchar](1000) NULL,
	[created_by] [int] NULL,
	[created_date] [datetime2](0) NULL,
	[modified_by] [int] NULL,
	[modified_date] [datetime2](0) NULL
)
GO
