DROP TABLE [dbo].[ground_of_objection]

CREATE TABLE [dbo].[ground_of_objection] (
    id INT IDENTITY(1,1) NOT NULL,
    name VARCHAR(255) NOT NULL,
    status_id SMALLINT DEFAULT 1,
    modified_by INT NULL,
    modified_date DATETIME2(0) NULL,
    created_by INT NULL,
    created_date DATETIME2(0) NULL,
)

INSERT INTO ground_of_objection
(name) VALUES ('Objection not on value')

INSERT INTO ground_of_objection
(name) VALUES ('Type of property')

INSERT INTO ground_of_objection
(name) VALUES ('Disputed ownership')

INSERT INTO ground_of_objection
(name) VALUES ('Exempted by law')
