CREATE TABLE [dbo].[arrears_business_seal](
	[id] [int] IDENTITY(1,1) NOT NULL,
    [arrears_case_id] [int] NOT NULL,
	[seal_reason] [nvarchar](1000) NULL,
	[seal_number] [nvarchar](1000) NULL,
	[seal_date] [datetime2](0) NULL,
	[seal_status] [int] DEFAULT 1,
	[created_by] [int] NULL,
	[created_date] [datetime2](0) NULL,
	[modified_by] [int] NULL,
	[modified_date] [datetime2](0) NULL,
)
GO