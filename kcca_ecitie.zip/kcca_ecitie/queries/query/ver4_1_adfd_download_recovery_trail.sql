update component  set permissions = 'list,add,view,edit,delete,download-attachment,search-business', module_permission_map = '' where title = 'recovery-trail'
update component  set blocked_dptm = 'view,edit,delete,download-attachment,add' where title = 'recovery-trail'
