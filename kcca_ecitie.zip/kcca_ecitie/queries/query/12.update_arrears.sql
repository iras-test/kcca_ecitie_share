
update component  set permissions = 'list,action,create-payment-plan', module_permission_map = 'list:list' where title = 'arrears'
