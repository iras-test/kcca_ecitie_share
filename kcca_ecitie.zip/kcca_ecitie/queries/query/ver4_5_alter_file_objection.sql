
ALTER TABLE [dbo].[arrears_case_objection]
ADD [ground_of_objection] [INT] NULL

ALTER TABLE [dbo].[arrears_case_objection]
ADD [document] [VARCHAR](255) NULL

ALTER TABLE [dbo].[arrears_case_objection]
ADD [document_name] [VARCHAR](255) NULL

ALTER TABLE [dbo].[arrears_case_objection]
ADD [document_mime] [VARCHAR](200) NULL

ALTER TABLE [dbo].[arrears_case_objection]
ADD [document_sysname] [VARCHAR](200) NULL

ALTER TABLE [dbo].[arrears_case_objection]
ADD [arrear_case_id] [INT] NULL
