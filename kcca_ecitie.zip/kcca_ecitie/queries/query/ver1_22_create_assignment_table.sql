CREATE TABLE [dbo].[arrear_case_assignment](
	[id] [int] IDENTITY(1,1) NOT NULL,
    [user_id] [int] NOT NULL,
    [arrears_case_id] [int] NOT NULL,
	[active] [int] DEFAULT 1,
	[comment] [nvarchar](1000) NULL,
	[created_by] [int] NULL,
	[created_date] [datetime2](0) NULL,
	[modified_by] [int] NULL,
	[modified_date] [datetime2](0) NULL,
)
GO