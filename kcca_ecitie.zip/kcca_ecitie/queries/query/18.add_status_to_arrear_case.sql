
ALTER TABLE arrear_case
ADD status varchar(255);

ALTER TABLE arrear_case
ADD reason varchar(255);


ALTER TABLE arrear_case
ADD customer_id int;

ALTER TABLE arrear_case
ADD ref_id int;

ALTER TABLE arrear_case
ADD ref_name varchar(255);
