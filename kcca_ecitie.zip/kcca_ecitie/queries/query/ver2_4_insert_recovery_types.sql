
DELETE FROM recovery_type

INSERT INTO recovery_type
(name)
VALUES
('Reminder')

INSERT INTO recovery_type
(name)
VALUES
('Demand notice')