
ALTER TABLE recovery_trail
ADD created_by INT NULL

ALTER TABLE recovery_trail
ADD created_date DATETIME2(0) NULL