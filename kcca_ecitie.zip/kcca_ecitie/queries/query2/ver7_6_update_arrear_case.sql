ALTER TABLE [dbo].[arrear_case] ADD [branch_code] [nvarchar](1000) NULL
ALTER TABLE [dbo].[arrear_case] ADD [division_id] [int] NULL
ALTER TABLE [dbo].[arrear_case] ADD [parish_id] [int] NULL
ALTER TABLE [dbo].[arrear_case] ADD [village_id] [int] NULL
ALTER TABLE [dbo].[arrear_case] ADD [street_id] [int] NULL
