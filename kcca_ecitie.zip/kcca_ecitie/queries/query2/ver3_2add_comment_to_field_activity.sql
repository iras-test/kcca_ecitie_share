ALTER TABLE recovery_trail
ADD comment VARCHAR(255) NULL
