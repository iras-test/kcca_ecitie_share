ALTER TABLE [dbo].[recovery_trail] ADD [branch_code] [nvarchar](1000) NULL
ALTER TABLE [dbo].[recovery_trail] ADD [division_id] [int] NULL