ALTER TABLE [dbo].[report_modules_config] ADD [ref_table_column] [nvarchar](1000) NULL
ALTER TABLE [dbo].[report_modules_config] ADD [ref_table_value] [nvarchar](1000) NULL
