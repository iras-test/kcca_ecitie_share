CREATE TABLE [dbo].[arrear_case_send_back](
	[id] [INT] IDENTITY(1,1) NOT NULL,
    [arrear_case_id] INT NOT NULL,
    [comment] VARCHAR(255) NULL,
    [status_id] [SMALLINT] DEFAULT 1,
    [created_by] [INT] NULL,
    [created_date] [DATETIME2](0) NULL,
    [modified_by] [INT] NULL,
    [modified_date] [DATETIME2](0) NULL,
)