ALTER TABLE [dbo].[recovery_trail] ADD [co_response_type] [nvarchar](1000) NULL
ALTER TABLE [dbo].[recovery_trail] ADD [co_response_comment] [nvarchar](1000) NULL