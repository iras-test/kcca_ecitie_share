INSERT INTO [dbo].[cms_sms] (
      [lang]
      ,[code]
      ,[title]
      ,[content]
      ,[status_id]
      ,[created_date]
      ,[created_by]
      ,[modified_date]
      ,[modified_by] ) 
SELECT [lang]
      ,'expiry_notice' AS [code]
      ,'Payment Expiry Notice' AS [title]
      ,'Dear [name], KCCA is pleased to inform you that yourpayment period has been expired. KCCA MGT' AS [content]
      ,[status_id]
      ,[created_date]
      ,[created_by]
      ,[modified_date]
      ,[modified_by]
FROM [dbo].[cms_email] 
WHERE [id]='50'


INSERT INTO [dbo].[cms_sms] (
      [lang]
      ,[code]
      ,[title]
      ,[content]
      ,[status_id]
      ,[created_date]
      ,[created_by]
      ,[modified_date]
      ,[modified_by] ) 
SELECT [lang]
      ,'reminder_notice' AS [code]
      ,'Reminder Notice' AS [title]
      ,'Dear [name], your payment expired 30 days ago and you are reminded to pay for your arrears within the next 30 days. KCCA MGT' AS [content]
      ,[status_id]
      ,[created_date]
      ,[created_by]
      ,[modified_date]
      ,[modified_by]
FROM [dbo].[cms_email] 
WHERE [id]='50'


INSERT INTO [dbo].[cms_sms] (
      [lang]
      ,[code]
      ,[title]
      ,[content]
      ,[status_id]
      ,[created_date]
      ,[created_by]
      ,[modified_date]
      ,[modified_by] ) 
SELECT [lang]
      ,'arrear_payment' AS [code]
      ,'Arrears Payment' AS [title]
      ,'Dear [name], Please note your payment has been received.Thank you. KCCA MGT' AS [content]
      ,[status_id]
      ,[created_date]
      ,[created_by]
      ,[modified_date]
      ,[modified_by]
  FROM [dbo].[cms_email] 
  WHERE [id]='50'


INSERT INTO [dbo].[cms_sms] (
      [lang]
      ,[code]
      ,[title]
      ,[content]
      ,[status_id]
      ,[created_date]
      ,[created_by]
      ,[modified_date]
      ,[modified_by] ) 
SELECT [lang]
      ,'business_seal_payment' AS [code]
      ,'Buiness Seal Notice' AS [title]
      ,'Dear [name], Payment for [email_tag_customer_name] has been received and you are advised to unseal their business.. KCCA MGT' AS [content]
      ,[status_id]
      ,[created_date]
      ,[created_by]
      ,[modified_date]
      ,[modified_by]
FROM [dbo].[cms_email] 
WHERE [id]='50'


INSERT INTO [dbo].[cms_sms] (
      [lang]
      ,[code]
      ,[title]
      ,[content]
      ,[status_id]
      ,[created_date]
      ,[created_by]
      ,[modified_date]
      ,[modified_by] ) 
SELECT [lang]
      ,'business_seal_notice' AS [code]
      ,'Buiness Seal Notice' AS [title]
      ,'Dear [name], please note that your business seal has been generated.Thank you. KCCA MGT' AS [content]
      ,[status_id]
      ,[created_date]
      ,[created_by]
      ,[modified_date]
      ,[modified_by]
  FROM [dbo].[cms_email] 
  WHERE [id]='50'