ALTER TABLE arrears_agency_notice
ADD comment VARCHAR(255) NULL, 
reason VARCHAR(255) NULL

GO