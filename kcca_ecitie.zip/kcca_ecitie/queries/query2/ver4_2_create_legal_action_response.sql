CREATE TABLE [dbo].[legal_action_response](
	[id] [INT] IDENTITY(1,1) NOT NULL,
    [legal_action_id] INT NULL,
    [description] [VARCHAR](255) NULL,
    [document] [VARCHAR](255) NULL,
    [document_name] [VARCHAR](255) NULL,
    [document_mime] [VARCHAR](200) NULL,
    [document_sysname] [VARCHAR](200) NULL,
    [status_id] [SMALLINT] DEFAULT 1,
    [created_by] [INT] NULL,
    [created_date] [DATETIME2](0) NULL,
    [modified_by] [INT] NULL,
    [modified_date] [DATETIME2](0) NULL,
)