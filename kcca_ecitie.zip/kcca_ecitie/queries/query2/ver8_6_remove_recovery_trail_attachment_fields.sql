ALTER TABLE [dbo].[recovery_trail] DROP COLUMN picture
ALTER TABLE [dbo].[recovery_trail] DROP COLUMN picture_name
ALTER TABLE [dbo].[recovery_trail] DROP COLUMN picture_mime
ALTER TABLE [dbo].[recovery_trail] DROP COLUMN picture_sysname
GO