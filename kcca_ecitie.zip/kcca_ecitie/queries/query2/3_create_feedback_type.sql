CREATE TABLE [dbo].[arrears_case_feedback_type] (
    id INT IDENTITY(1,1) NOT NULL,
    name VARCHAR(255) NOT NULL,
    status_id SMALLINT DEFAULT 1,
    modified_by INT NULL,
    modified_date DATETIME2(0) NULL,
    created_by INT NULL,
    created_date DATETIME2(0) NULL,
)

INSERT INTO arrears_case_feedback_type
(name) VALUES ('Complement')

INSERT INTO arrears_case_feedback_type
(name) VALUES ('Complaint')

INSERT INTO arrears_case_feedback_type
(name) VALUES ('Suggestion')

INSERT INTO arrears_case_feedback_type
(name) VALUES ('Request')