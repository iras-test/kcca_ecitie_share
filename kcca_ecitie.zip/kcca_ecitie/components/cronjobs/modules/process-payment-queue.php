<?php
/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');


set_time_limit(0);

echo "\n--begin--: ".__FILE__;
try{
	// check for index 5 = sms queueing file
	if(isset ($GLOBALS['argv'][5])){
		// the file with queue items
		$strQueueFile = $GLOBALS['argv'][5];
		
		// application instance	
		$application = KetrouteApplication::instance();
		
		// check file exists
		if(KFile::exists($strQueueFile) && KFile::isExtension($strQueueFile, PaymentManager::PAYMENT_TRANSACTION_FILE_EXT) && KFile::size($strQueueFile)){
			
			// get items in file
			$strData = KFile::getContent($strQueueFile);
			
			// valid data found
			if(!empty($strData)){
				
				// get full details- payment_id:customer_id
				$strData = explode(':', $strData);
				
				// load payment
				$objPayment 	= $application->database()->load('payment',array('id' => $strData[0]),$fields = '*');
				
				// load customer
				$objCustomer 	= $application->database()->load('customer',array('id' => $strData[1]),$fields = '*');
				
				// credited transactions
				if($objPayment->transaction_status == PaymentManager::TRANSACTION_STATUS_CREDITED){					
					// update reveuneu source and customer balance
					PaymentManager::processPaymentTransactionBalanceUpdate($objPayment, $objCustomer);
					
					// send customer notificaion
					PaymentManager::sendPaymentNotification($objPayment, $objCustomer);		
				}
				// notice of dishonored Cheque
				else if($objPayment->transaction_status == PaymentManager::TRANSACTION_STATUS_DISHONORED){
					// send customer notificaion
					PaymentManager::sendDishonoredChequePaymentNotification($objPayment, $objCustomer);
				}
				// notice of received Cheque
				else if($objPayment->transaction_status == PaymentManager::TRANSACTION_STATUS_RECEIVED){
					// send customer notificaion
					PaymentManager::sendChequeReceivedPaymentNotification($objPayment, $objCustomer);
				}
				
				// delete the file
				KFile::deleteFile($strQueueFile);
			}
			else{
				// delete the file
				KFile::deleteFile($strQueueFile);
				
				// delete file
				throw new Exception('Empty Payment Transaction Queue: '.print_r($strQueueFile, true));	
			}
		}
		else{
			// ignore proocess
			throw new Exception('Invalid Payment Transaction Queue: '.print_r($strQueueFile, true));
		}
	}
}
catch(Exception $e){
	// do notiing with errors
	$this->captureErrorLog(null,ErrorLogManager::ERROR_TYPE_EXCEPTION,'Failed to run: Payment Transaction Queue',print_r($e->getMessage(), true));
}
echo "\n--end--";