<?php
/**
 * KETROUTE Framework
 *
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
define('KFW_ACCESS_CONTEXT', 6);
// (defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

set_time_limit(0);
ini_set("memory_limit","30M");

echo "\n--begin--: ".__FILE__;
 try{
 	// get all payment
	$arrPayments 	= KetrouteApplication::db()->getList($table = 'payment', $where = array('status_id' => array(KStatus::PAID, KStatus::CLOSED)), $fields = '*');
	
	$strXml = '<?xml version="1.0" encoding="iso-8859-1"?>';
	
	foreach($arrPayments as $objPayment){
		$strXml .= "<payment>
						<trackingID>{$objPayment->id}</trackingID>
						<transactionID>{$objPayment->transaction_id}</transactionID>
						<amountPaid>".KConverter::centsToMoney($objPayment->amount)."</amountPaid>
						<paymentDate>{$objPayment->created_date}</paymentDate>
					</payment>";
	}
	KFile::downloadContent('ifms-export-ptms.xml', $strXml);
 }
 catch (Exception $e){
 	$this->captureErrorLog(null,ErrorLogManager::ERROR_TYPE_EXCEPTION,'Failed to archive calls',$e->getMessage());
}
 echo "\n--end--";