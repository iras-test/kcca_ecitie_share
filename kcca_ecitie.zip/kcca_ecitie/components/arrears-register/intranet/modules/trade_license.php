<?php

/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

if (KRequest::isPosted()) {
	$cases_info = KRequest::getpost("ids");

	$assignee = KRequest::getPost("assignee");
	$data = json_decode($cases_info);

	foreach ($data as $key => $case_info) {
		$case_info = str_replace(
			"__",
			'"',
			$case_info
		);
		$case_assignement_data = json_decode($case_info);
		ArrearCase::create(
			$case_assignement_data->customer_id,
			$case_assignement_data->ref_id,
			$case_assignement_data->ref_name,
			$assignee
		);
	}
	$resp['success'] = true;
	$resp['ids'] = $data;
	$resp['assignee'] = KRequest::getPosts();

	header("Content-type: application/json");

	echo json_encode($resp);
	exit;
}

// get max per page
$MAX_PER_PAGE 	= $this->registry()->get(strtoupper($this->getComponentRealname()) . '_MAX_PER_PAGE', $this->registry()->get('MAX_PER_PAGE', 10));
// page number
$_page		 	= $this->getParam('page', KRequest::getQueryString("page", 1));
$queryParams = KRequest::getQueryStrings();
$records = '';
$strComponentRealname	= $this->getComponentRealname();
$user_id		= KSecurity::getUserID();
$intIgnoreID 	= $this->runtime()->getIgnoredID();
$strParentUrl	= $this->urlPath(0);
$strMessage = '';
$records = '';
$list_counter	= 0;

// set active item with its configurations	
$this->runtime()->setActivePage($_page);
$this->runtime()->setActiveMaxPerPage($MAX_PER_PAGE);

$result_list['count'] = ArrearsManager::tradeArrearsCount($queryParams);
$data = ArrearsManager::getTradeArrears($_page, $queryParams);

/** Divisions */
$divisions = ArrearsManager::getDivisions();
$divisions_arr = [];
foreach ($divisions_arr as $key => $value) {
	array_push($divisions_arr, array("id" => $value["id"], "name" => $value["name"]));
}

$officers = ArrearsManager::getOfficers();
$assignee_options = "";
$officers_filter_data = [];
foreach ($officers as $key => $value) {
	$assignee_options .= "<option value=\"$value->id\">{$value->surname} {$value->firstname}</option>";
	array_push($officers_filter_data, array("id" => $value->id, "name" => "$value->surname $value->firstname"));
}


if ($result_list['count'] > 0) {
	// show record	
	foreach ($data as $index => $arrData) {
		$strPrimaryKey = $this->runtime()->getPrimaryKey();

		$class = ($index % 2 == 0) ? ' odd' : ' even';

		if ($_page > 1) {
			$record_number = ($index + 1) + ($MAX_PER_PAGE * ($_page - 1));
		} else {
			$record_number = ($index + 1);
		}

		$list_counter++;
		$objmoduleConfig = (object)$arrData;
		$arrear_case_creation_data = ["ref_id" => $objmoduleConfig->ref_id, "ref_name" => $objmoduleConfig->ref_name, "customer_id" => $objmoduleConfig->customer_id];

		$allow_case = true;
		if ($objmoduleConfig->case_id) {
			$allow_case = false;
		}

		$arrear_case_creation_data = json_encode($arrear_case_creation_data);
		$arrear_case_creation_data = str_replace('"', "__", $arrear_case_creation_data);

		$date = $objmoduleConfig->date
			? $objmoduleConfig->date :
			"N/A";

		$division = ArrearsManager::getDivision($objmoduleConfig->division_id);
		$division = $division
			? $division
			: "N/A";

		$parish = ArrearsManager::getParish($objmoduleConfig->parish_id);
		$parish = $parish
			? $parish
			: "N/A";

		$street = ArrearsManager::getStreet($objmoduleConfig->street_id);
		$street = $street
			? $street
			: "N/A";

		$branch_code = $objmoduleConfig->branch_code
			? $branch_code
			: "N/A";

		$customer_name = $this->runtime()->getFieldData('customer_id', $arrData)
			? $this->runtime()->getFieldData('customer_id', $arrData)
			: "N/A";

		$amount = $objmoduleConfig->balance
			? abs($objmoduleConfig->balance)
			: "N/A";

		$interval = date_diff(new DateTime(), new DateTime($objmoduleConfig->due_date));
		$age = $interval->format('%a');

		$status = $objmoduleConfig->case_status
			? $objmoduleConfig->case_status
			: ArrearStatus::OPEN;

		$assignee = ArrearCase::getAssignee($objmoduleConfig->assignee);

		$records .= "<div class=\"clear list-item{$class}\">";
		$records .= "\n\t\t\t<div class=\"fl numbering-col\">{$record_number}</div>";
		$records .= "\n\t\t\t<div class=\"fl col8\">{$date}</div>";
		$records .= "\n\t\t\t<div class=\"fl col8\">{$division}</div>";
		$records .= "\n\t\t\t<div class=\"fl col8\">{$parish}</div>";
		$records .= "\n\t\t\t<div class=\"fl col8\">{$street}</div>";
		$records .= "\n\t\t\t<div class=\"fl col10\">{$customer_name}</div>";
		$records .= "\n\t\t\t<div class=\"fl col8\">{$branch_code}</div>";
		$records .= "\n\t\t\t<div class=\"fl col8\">{$amount}</div>";
		$records .= "\n\t\t\t<div class=\"fl col8\">&nbsp;{$age}</div>";
		if ($allow_case) {
			$records .= "\n\t\t\t<div class=\"fl col8\">
				<input type=\"checkbox\" onchange=\"handleArrearSelection(this,'{$arrear_case_creation_data}')\" />
			</div>";
		} else {
			$records .= "\n\t\t\t<div class=\"fl col8\">
				<a href=\"[link_in_use]arrears/case-details?id={$objmoduleConfig->case_id}\">View case</a>
			</div>";
		}
		$records .= "\n\t\t\t<div class=\"fl col8\">{$status}</div>";
		$records .= "\n\t\t\t<div class=\"fl col8\">{$assignee}</div>";

		if ($allow_case) {
			$records .= "\n\t\t\t<div class=\"fl col6\"><a href=\"[link_in_use]arrears/action?ref_name={$objmoduleConfig->ref_name}&ref_id={$objmoduleConfig->ref_id}\">Action</a></div>";
		}

		$records .= "\n\t\t</div>";
	}
} else {
	$records  = "\n\t\t<div class=\"clear list-item text-center\">" . KLanguage::getWord('arrears-no-items') . "</div>";
}

$pager = new KPager();
$pager->setTotalRecords($result_list['count']);
$pager->setRecordsPerPage($MAX_PER_PAGE);
$pager->setCurrentPage($_page);
$url = $this->urlPath(1, 1, 1, 1);
if (count($queryParams)>0) {
	$ex_url = explode("page=",$url);
	$url = $ex_url[0];
	if (count($ex_url)==1) {
		$url .= "&";
	}
}else {

	$url .= "?";

}
$pager->setURL($url."page=");
$pager_html = $pager->getPager();
$pager_info = $pager->getPagerInfo("Trade License Items");

$customer_filter = Util::filterInput("text", "Customer", "customer", $queryParams["customer"]);
$amount_start_filter = Util::filterInput("text", "Amount-Start", "amount_start", $queryParams["amount_start"]);
$amount_end_filter = Util::filterInput("text", "Amount-End", "amount_end", $queryParams["amount_end"]);
$age_start_filter = Util::filterInput("date", "Age-Start", "age_start", $queryParams["age_start"]);
$age_end_filter = Util::filterInput("date", "Age-End", "age_end", $queryParams["age_end"]);
$coin_filter = Util::filterInput("text", "COIN", "coin", $queryParams["coin"]);
$branch_code_filter = Util::filterInput("text", "BRANCH-CODE", "tl_branch_code", $queryParams["tl_branch_code"]);

$division_filter = Util::filterInput(
	"select",
	"Division",
	"division",
	$queryParams["division"],
	$options = array(
		"data" => $divisons_arr,
		"id" => "id",
		"label" => "name",
		"placeholder" => " - Select division"
	)
);

$officer_filter = Util::filterInput(
	"select",
	"Assigned-Officer",
	"assignee",
	$queryParams["assignee"],
	$options = array(
		"data" => $officers_filter_data,
		"id" => "id",
		"label" => "name",
		"placeholder" => " - Select Officer"
	)
);


$status_filter = Util::filterInput(
	"select",
	"Status",
	"case_status",
	$queryParams["case_status"],
	$options = array(
		"data" => ArrearStatus::$status_arr,
		"id" => "id",
		"label" => "name",
		"placeholder" => " - Select Status - "
	)
);

$filters = "
	$customer_filter
	$amount_start_filter
	$amount_end_filter
	$coin_filter
	$branch_code_filter
	$age_start_filter
	$age_end_filter
	$officer_filter
	$status_filter
";

$this->render(array(
	"records" => $records,
	"options" => $assignee_options,
	"next_url" => $this->urlPath(1, 1, 0, 0) . "cases",
	'pager_html' 	=> $pager_html,
	'pager_info' 	=> $pager_info,
	'message' 		=> $strMessage,
	'list_counter' 	=> $list_counter,
	'tabs' 			=> KNavigationTab::getHTMLTabs(),
	'base_url'		=> $this->urlPath(1, 1, 0, 0),
	'filters'		=> Util::formContainer("arrears", $this->urlPath(1, 1, 1, 1), $filters),
));
