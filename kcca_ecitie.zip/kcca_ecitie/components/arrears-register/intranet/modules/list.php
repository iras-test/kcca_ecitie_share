<?php

/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

if (KRequest::isPosted()) {

	$cases_info = KRequest::getpost("ids");

	$assignee = KRequest::getPost("assignee");
	$data = json_decode($cases_info);

	foreach ($data as $key => $case_info) {
		$case_info = str_replace(
			"__",
			'"',
			$case_info
		);
		$case_assignement_data = json_decode($case_info);
		ArrearCase::create(
			$case_assignement_data->customer_id,
			$case_assignement_data->ref_id,
			$case_assignement_data->ref_name,
			$assignee
		);
	}
	$resp['success'] = true;
	$resp['ids'] = $data;
	$resp['assignee'] = KRequest::getPosts();

	header("Content-type: application/json");

	echo json_encode($resp);
	exit;
}

// get max per page
$MAX_PER_PAGE 	= $this->registry()->get(strtoupper($this->getComponentRealname()) . '_MAX_PER_PAGE', $this->registry()->get('MAX_PER_PAGE', 10));
// page number
$_page		 	= $this->getParam('page', KRequest::getQueryString("page", 1));
$queryParams = KRequest::getQueryStrings();
$records = '';
$strComponentRealname	= $this->getComponentRealname();
$user_id		= KSecurity::getUserID();
$intIgnoreID 	= $this->runtime()->getIgnoredID();
$strParentUrl	= $this->urlPath(0);
$strMessage = '';
$records = '';
$list_counter	= 0;

// set active item with its configurations	
$this->runtime()->setActivePage($_page);
$this->runtime()->setActiveMaxPerPage($MAX_PER_PAGE);

$result_list['count'] = ArrearsManager::count($queryParams);
$data = ArrearsManager::getList($_page, $queryParams);

/** Revenue sources */
$revenue_types = ArrearsManager::getRevenueTypes();
$revenue_types_arr = [];
foreach ($revenue_types as $key => $value) {
	array_push($revenue_types_arr, array("id" => $value["id"], "name" => $value["name"]));
}

/** Divisions */
$divisions = ArrearsManager::getDivisions();
$divisions_arr = [];
foreach ($divisions_arr as $key => $value) {
	array_push($divisions_arr, array("id" => $value["id"], "name" => $value["name"]));
}

/** Case assignment officers */
$officers = ArrearsManager::getOfficers();
$officers_filter_data = [];
$assignee_options = "";
foreach ($officers as $key => $value) {
	$assignee_options .= "<option value=\"$value->id\">{$value->surname} {$value->firstname}</option>";
	array_push($officers_filter_data, array("id" => $value->id, "name" => "$value->surname $value->firstname"));
}

/** Handle CSV downloads */
if ($this->getParam('quickexport', 1) === "csv") {
	$pages = $this->getParam('pages', 1);
	$arrHeaders = array('Due Date', 'Customer', 'Coin', 'Revenue Type', 'Amount');

	$page = $pages == "current" ? $this->getParam('page', 1) : null;
	$arrResults = ArrearsManager::generalExport($page, $queryParams);

	KFile::createCSV(
		"{$this->getComponent()}-{$this->getModule()}.csv",
		$arrHeaders,
		$arrResults
	);

	$docName = "arrears general register.csv";
	$docPath = KFW_STORAGE_PATH . $this->getComponentRealname() . DIRECTORY_SEPARATOR . "{$this->getComponent()}-{$this->getModule()}.csv";
	KFile::downloadFile($docName, $docPath, $delete_file_when_done = false);
	exit;
}

/** Handle PDF downloads */
if ($this->getParam('quickexport', 1) === "pdf") {
	$pages = $this->getParam('pages', 1);
	$arrHeaders = array('Due Date', 'Customer', 'Coin', 'Revenue Type', 'Amount');

	$page = $pages == "current" ? $this->getParam('page', 1) : null;
	$arrResults = ArrearsManager::generalExport($page, $queryParams);

	KFile::createPDF(
		"{$this->getComponent()}-{$this->getModule()}.pdf",
		KLanguage::getWord("{$this->getComponent()}-report"),
		$arrHeaders,
		$arrResults,
		$mode = 1,
		$auto_print = true,
		$orientation = 'L',
		$show_numbering = false,
		null
	);

	$docName = "arrears general register.pdf";
	$docPath = KFW_STORAGE_PATH . $this->getComponentRealname() . DIRECTORY_SEPARATOR . "{$this->getComponent()}-{$this->getModule()}.pdf";
	KFile::downloadFile($docName, $docPath, $delete_file_when_done = false);
}

if ($result_list['count'] > 0) {
	// show record	
	foreach ($data as $index => $arrData) {

		$strPrimaryKey = $this->runtime()->getPrimaryKey();

		$class = ($index % 2 == 0) ? ' odd' : ' even';

		if ($_page > 1) {
			$record_number = ($index + 1) + ($MAX_PER_PAGE * ($_page - 1));
		} else {
			$record_number = ($index + 1);
		}

		$list_counter++;
		$objmoduleConfig = (object)$arrData;
		$arrear_case_creation_data = ["ref_id" => $objmoduleConfig->ref_id, "ref_name" => $objmoduleConfig->ref_name, "customer_id" => $objmoduleConfig->customer_id];

		$allow_case = true;
		if ($objmoduleConfig->case_id) {
			$allow_case = false;
		}

		$arrear_case_creation_data = json_encode($arrear_case_creation_data);
		$arrear_case_creation_data = str_replace('"', "__", $arrear_case_creation_data);

		$customer_name = $objmoduleConfig->customer_id
			? $this->runtime()->getFieldData('customer_id', $arrData)
			: "N/A";

		$customer_name = $customer_name != ""
			? $customer_name
			: "N/A";

		$revenue_name = $objmoduleConfig->revenue_name
			? $objmoduleConfig->revenue_name :
			"N/A";

		$due_date = $objmoduleConfig->due_date
			? $objmoduleConfig->due_date :
			"N/A";

		$branch_code = $objmoduleConfig->branch_code
			? $objmoduleConfig->branch_code :
			"N/A";

		$amount = $objmoduleConfig->balance
			? abs($objmoduleConfig->balance)
			: "N/A";

		$status = $objmoduleConfig->case_status
			? $objmoduleConfig->case_status
			: ArrearStatus::OPEN;

		$assignee = ArrearCase::getAssignee($objmoduleConfig->assignee);

		$interval = date_diff(new DateTime(), new DateTime($objmoduleConfig->due_date));
		$age = $interval->format('%a');

		$records .= "<div class=\"clear list-item{$class}\">";
		$records .= "\n\t\t\t<div class=\"fl numbering-col\">{$record_number}</div>";
		$records .= "\n\t\t\t<div class=\"fl col8\">{$due_date}</div>";
		$records .= "\n\t\t\t<div class=\"fl col10\">{$customer_name}</div>";
		$records .= "\n\t\t\t<div class=\"fl col10\">{$revenue_name}</div>";
		$records .= "\n\t\t\t<div class=\"fl col10\">{$branch_code}</div>";
		$records .= "\n\t\t\t<div class=\"fl col8\">{$amount}</div>";
		$records .= "\n\t\t\t<div class=\"fl col8\">&nbsp;{$age}</div>";
		if ($allow_case) {
			$records .= "\n\t\t\t<div class=\"fl col8\">
				<input type=\"checkbox\" onchange=\"handleArrearSelection(this,'{$arrear_case_creation_data}')\" />
			</div>";
		} else {
			$records .= "\n\t\t\t<div class=\"fl col8\">
				<a href=\"[link_in_use]arrears/case-details?id={$objmoduleConfig->case_id}\">View case</a>
			</div>";
		}
		$records .= "\n\t\t\t<div class=\"fl col8\">{$status}</div>";
		$records .= "\n\t\t\t<div class=\"fl col8\">{$assignee}</div>";
		if ($allow_case) {
			$records .= "\n\t\t\t<div class=\"fl col8\"><a href=\"[link_in_use]arrears/action?ref_name={$objmoduleConfig->ref_name}&ref_id={$objmoduleConfig->ref_id}\">Action</a></div>";
		}
		$records .= "\n\t\t</div>";
	}

	$pager = new KPager();
	$pager->setTotalRecords($result_list['count']);
	$pager->setRecordsPerPage($MAX_PER_PAGE);
	$pager->setCurrentPage($_page);
	
	$url = $this->urlPath(1, 1, 1, 1);
	if (count($queryParams)>0) {
		$ex_url = explode("page=",$url);
		$url = $ex_url[0];
		if (count($ex_url)==1) {
			$url .= "&";
		}
	}else {

		$url .= "?";
	
	}
	$pager->setURL($url."page=");
	$pager_html = $pager->getPager();
	$pager_info = $pager->getPagerInfo("[lang-{$strComponentRealname}-items]");
} else {
	$records  = "\n\t\t<div class=\"clear list-item text-center\">" . KLanguage::getWord('arrears-no-items') . "</div>";
}

$customer_filter = Util::filterInput("text", "Customer", "customer", $queryParams["customer"]);
$amount_start_filter = Util::filterInput("text", "Amount-Start", "amount_start", $queryParams["amount_start"]);
$amount_end_filter = Util::filterInput("text", "Amount-End", "amount_end", $queryParams["amount_end"]);
// $age_start_filter = Util::filterInput("number", "Age-Start", "age_start", $queryParams["age_start"]);
// $age_end_filter = Util::filterInput("number", "Age-End", "age_end", $queryParams["age_end"]);
$age_start_filter = Util::filterInput("date", "Age-Start", "age_start", $queryParams["age_start"]);
$age_end_filter = Util::filterInput("date", "Age-End", "age_end", $queryParams["age_end"]);
$coin_filter = Util::filterInput("text", "COIN", "coin", $queryParams["coin"]);
$branch_code_filter = Util::filterInput("text", "Branch-Code", "gen_branch_code", $queryParams["gen_branch_code"]);
$revenue_filter = Util::filterInput(
	"select",
	"Revenue",
	"revenue_type",
	$queryParams["revenue_type"],
	$options = array(
		"data" => $revenue_types_arr,
		"id" => "id",
		"label" => "name",
		"placeholder" => " - Select revenue type"
	)
);

$division_filter = Util::filterInput(
	"select",
	"Division",
	"division",
	$queryParams["division"],
	$options = array(
		"data" => $divisons_arr,
		"id" => "id",
		"label" => "name",
		"placeholder" => " - Select division"
	)
);

$officer_filter = Util::filterInput(
	"select",
	"Assigned-Officer",
	"assignee",
	$queryParams["assignee"],
	$options = array(
		"data" => $officers_filter_data,
		"id" => "id",
		"label" => "name",
		"placeholder" => " - Select Officer"
	)
);


$status_filter = Util::filterInput(
	"select",
	"Status",
	"case_status",
	$queryParams["case_status"],
	$options = array(
		"data" => ArrearStatus::$status_arr,
		"id" => "id",
		"label" => "name",
		"placeholder" => " - Select Status - "
	)
);


$filters = "
	$customer_filter
	$amount_start_filter
	$amount_end_filter
	$revenue_filter
	$branch_code_filter
	$coin_filter
	$age_start_filter
	$age_end_filter
	$officer_filter
	$status_filter
";

$this->render(array(
	"records" => $records,
	"options" => $assignee_options,
	"next_url" => $this->urlPath(1, 1, 0, 0) . "cases",
	'pager_html' 	=> $pager_html,
	'pager_info' 	=> $pager_info,
	'message' 		=> $strMessage,
	'list_counter' 	=> $list_counter,
	'tabs' 			=> KNavigationTab::getHTMLTabs(),
	'image_path'	=> KFW_IMAGES_URL,
	'base_url'		=> $this->urlPath(1, 1, 0, 0),
	'csv_all'		=> $this->urlPath(1, 1, 0, 0) . "quickexport/csv/pages/all/",
	'csv_current'	=> $this->urlPath(1, 1, 0, 0) . "quickexport/csv/pages/current/",
	'pdf_all'		=> $this->urlPath(1, 1, 0, 0) . "quickexport/pdf/pages/all/",
	'pdf_current'	=> $this->urlPath(1, 1, 0, 0) . "quickexport/pdf/pages/current/",
	'filters'		=> Util::formContainer("arrears", $this->urlPath(1, 1, 1, 1), $filters),
));
