<?php

header("Content-type: application/json");
AuthWrapper::getAuthenticatedUser();

$info = null;
$error = null;
$case = array();
$util = new Util();
$escalation_info = "";
$assignee_options = "";
$active_assignment = (object)[];
$current_user = KSecurity::getUserID();
$queryParams = KRequest::getQueryStrings();
$case_id = $queryParams["id"];

if (array_key_exists("id", $queryParams)) {
    $info  = (object) ArrearsManager::getArrearsCasePaymentBill($case_id);
}

$bills = ArrearsManager::getAllPaymentBills($info->ref_name, $info->ref_id);
$feedbacks = ArrearCaseFeedback::getAllFeedback($case_id);


if ($info) {

    $business_details = ArrearsManager::getBusinessDetails($info->ref_name, $info->ref_id);
    $prn = $info->prn ? $info->prn : "N/A";
    $case_status = ($info->status == null) ? ArrearStatus::OPEN : $info->status;
    $info->status = $case_status;
    $bal = $info->amount
        ? $info->amount
        : "N/A";
    $info->amount = $bal;
    $revenue_name = $info->ref_name
        ? $info->ref_name
        : "N/A";
    $branch_code = $business_details->branch_code != null ? $business_details->branch_code : "N/A";
    $info->branch_code = $branch_code;
    $info->location = $business_details->location;
    $info->revenue_name = $revenue_name;
    $assignee = ArrearCase::getAssignee($info->assignee);
    // case escalation and actions
    $assignments = ArrearCase::getCaseAssignmentsCount($info->id);
    $active_assignment = ArrearCase::getCaseAssignments($info->id);
    $case_actions = [
        'payment_plan' => null,
        'agency_notice' => null,
        'business_seal_info' => null
    ];

    if (
        (($assignments == 0) && ($info->assignee == $current_user))
        ||
        (($active_assignment != null) && ($active_assignment->user_id == $current_user))
        ||
        (UserManager::getProfile($current_user)->user_role_id == ArrearStatus::ARREARS_MANAGER_ROLE)
    ) {

        $has_active_payment_plan = PaymnentPlanManager::getCasePaymentPlan($info->id, true);

        $has_active_agency_notice_issued = ArrearCase::getCaseAgencyNoticeActions($info->id);

        $has_active_business_seal = ArrearCase::getCaseBusinessSealActions($info->id);


        if (!($has_active_agency_notice_issued || $has_active_business_seal)) {

            $payment_plan_info = $has_active_payment_plan
                ? ['action' => "view", "case_id" => $info->id, "plan_id" => $has_active_payment_plan]
                : ['action' => "create", "case_id" => $info->id, "plan_id" => null];

            $case_actions['payment_plan'] = $payment_plan_info;
        }

        if (!($has_active_business_seal || $has_active_payment_plan)) {

            $agency_notice_info = $has_active_agency_notice_issued
                ? ['action' => "view", "case_id" => $info->id, "notice_id" => $has_active_agency_notice_issued->id]
                : ['action' => "create", "case_id" => $info->id, "notice_id" => null];

            $case_actions['agency_notice'] = $agency_notice_info;
        }


        if (!($has_active_agency_notice_issued || $has_active_payment_plan)) {

            $business_seal_info = $has_active_business_seal
                ? ['action' => "view", "case_id" => $info->id, "seal_id" => $has_active_business_seal->id]
                : ['action' => "create", "case_id" => $info->id, "seal_id" => null];

            $case_actions['business_seal_info'] = $business_seal_info;
        }

        $escalation_actions_info = [];
        $escalation_actions_info['current_assignment'] = $active_assignment->id;
        $escalation_actions_info['escalate_back'] = false;
        $escalation_actions_info["escalate_forward"] = false;

        $escalation_info = "<h1 class=\"kfw-active-title pt10\"><strong>Escalation<strong></h1>";
        if ($assignments > 0) {
            $assignment_level = EscalationLevels::getUserEscalationLevel($active_assignment->user_id);
            $next_assignment_level = EscalationLevels::getNextLevel($assignment_level);
            if ($assignments > 1) {
                $previous_assignment = ArrearCase::getPreviousAssignment($info->id, $active_assignment->id);
                $previous_user_escalation_level = EscalationLevels::getUserEscalationLevel($previous_assignment->user_id);
                if ($previous_user_escalation_level < $assignment_level) {
                    $escalation_actions_info['escalate_back'] = true;
                }
            }
        } else {
            $next_assignment_level = EscalationLevels::getStartLevel();
        }

        if ($next_assignment_level) {
            $next_assignment_level = (object)$next_assignment_level;
            $officers = ArrearsManager::getOfficers($role = $next_assignment_level->role_id);
            $escalation_actions_info["escalate_forward"] = true;
            $escalation_actions_info["next_level_users"] = [];
            foreach ($officers as $key => $value) {
                $escalation_actions_info["next_level_users"][] = [
                    "id" => $value->id,
                    "surname" => $value->surname,
                    "lastname" => $value->firstname
                ];
            }
        }

        $info->escalation_actions = $escalation_actions_info;
    }

    $info->case_actions = $case_actions;

    // escalation history
    $asignments_history = [];
    $assigments = ArrearCase::getCaseAssignments($info->id, $active_only = false);
    foreach ($assigments as $index => $this_assignment) {

        $class = ($index % 2 == 0) ? ' odd' : ' even';
        // $assigment_obj = (object) $this_assignment;
        $record_number = $index + 1;

        $created_by = UserManager::getProfile($this_assignment->created_by);
        $created_by_names = "$created_by->firstname $created_by->surname";

        $assigned_to = UserManager::getProfile($this_assignment->user_id);
        $assigned_to_names = "$assigned_to->firstname $assigned_to->surname";

        $status = $this_assignment->active ? 'Active' : 'Done';

        $asignments_history[] = [
            "created_by" => $created_by_names,
            "assigned_to" => $assigned_to_names,
            "comment" => $this_assignment->comment,
            "assigned_on" => $this_assignment->created_date,
            "status" => $status
        ];
    }

    $info->escalation_history = $asignments_history;
}

/** Bill breakdowns */
$bills_history = [];
if (count($bills) > 0) {
    // show record	
    foreach ($bills as $index => $arrData) {
        $class = ($index % 2 == 0) ? ' odd' : ' even';
        $obj = (object) $arrData;
        $record_number = $index + 1;
        $prn = $obj->prn ? $obj->prn : "N/A";
        $bills_history[] = [
            "financial_year" => $obj->financial_year,
            "prn" => $prn,
            "due_date" => $obj->due_date,
            "amount" => $obj->amount
        ];
    }
}

$info->bills = $bills_history;

/** Feedback breakdowns */
$feedback_info = [];
if (count($feedbacks) > 0) {
    // show record	
    foreach ($feedbacks as $index => $arrData) {
        $class = ($index % 2 == 0) ? ' odd' : ' even';
        $obj = (object) $arrData;
        $record_number = $index + 1;

        $feedback_type = ArrearCaseFeedback::getFeedbackType($obj->feedback_type)
            ? ArrearCaseFeedback::getFeedbackType($obj->feedback_type)
            : "N/A";

        $feedback_info[] = [
            "created_on" => $obj->created_date,
            "location" => $obj->location,
            "type" => $feedback_type,
            "feedback" => $obj->feedback,
        ];
    }
}

$info->feedback = $feedback_info;
$info->assignee = $assignee;
$response = [
    "case_info" => $info,
    "status" => 200
];
echo json_encode($response);
exit;
