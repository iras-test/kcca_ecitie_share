<?php

$_page	= KRequest::getQueryString("page", 1);
$queryParams = KRequest::getQueryStrings();

header("Content-type: application/json");
AuthWrapper::getAuthenticatedUser();

$data = ArrearCase::getList($_page, $queryParams);
$cases_details = [];

foreach ($data as $index => $arrData){
    $arrData = ArrearsManager::getArrearsCasePaymentBill($arrData['id']);
    $obj = (object)$arrData;

    $business_details = ArrearsManager::getBusinessDetails($obj->ref_name, $obj->ref_id);
    $branch_code = $business_details->branch_code!=null?$business_details->branch_code:"N/A";
    $revenue_name = $obj->ref_name
    ? $obj->ref_name
    : "N/A";

    $amount = $obj->amount
    ? $obj->amount
    : "N/A";

    $assignee = ArrearCase::getAssignee($obj->assignee);
    $case_status = ($obj->status == null)?ArrearStatus::OPEN:$obj->status;

    $obj->status = $case_status;
    // $obj->customer = $customer_name;
    $obj->revenue_name = $revenue_name;
    $obj->amount = $amount;
    $obj->assignee = $assignee;
    $obj->branch_code = $branch_code;

    $cases_details[] = $obj;
}
$response = [
    "cases"=>$cases_details,
    "status"=>200
];
echo json_encode($response);
exit;