/**
* KPayment Namespace starts here
**/
var KPayment = {	
	// capture on load
	calculateGroupTotal : function(){
		// zero amount to pay
		var amount_to_pay = 0;
		
		// scan all payment-data-calc attributes
		$("[payment-data-calc]").each(function(i, el){
			
			if( $(el).is(':checked') ){				
				// add amount to payment figure
				amount_to_pay =  parseFloat(amount_to_pay) + parseFloat($('#amount-' + $(el).attr('id')).val());
			}
		});
		
		// show total to pay
		$('#payment-registration-total').html(KCommon.formatAsMoney(amount_to_pay));
	}	
}

var KPayments = {	
	// capture on load
	populateAmount : function(e1,e2,e3,amount){
		// zero amount to payamount
		var amount_to_pay = '#amount-frmvehicle-list_'+e3;		
		var amount_checkbox1 = '#frmvehicle-list_'+e1;
		var amount_checkbox2 = "#frmvehicle-list_"+e2;
		
		// textbox is checked
		if($(amount_checkbox1).is(':checked')){         
	       $(amount_to_pay).val(amount);
	       $(amount_checkbox2).prop("checked",false);
	      } 
	      else{
	      	 amount = '0.00';
	      	// alert(amount);
	      	 $(amount_to_pay).val(amount);
	      }   
	}	
}

$(document).ready(function(){
	
	$('*[payment-data-calc]').on("change", function( event ){
		// run calculations
		KPayment.calculateGroupTotal();
	});
})