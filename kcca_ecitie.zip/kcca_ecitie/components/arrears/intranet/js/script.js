
let selectCases = [];
let selectedAllCases = false;

function handleCasesSelection(select, id){
    if(select.checked) {
        selectCases.push(id);

    } else {
        selectCases = selectCases.filter(it => it != id)
    }

    document.getElementById("multiselect").style.display = selectCases.length? "inline-block": "none"
}

function selectAllCases(button) {
    selectedAllCases = !selectedAllCases;
    button.innerText = selectedAllCases? "Unselect All": "Select All";
    var inputs = document.getElementsByTagName("input");
    for(var i = 0; i < inputs.length; i++) {
        var input = inputs[i];
        if((input.type == "checkbox") && (input.checked != selectedAllCases)) {
            input.click();
        }
    }
}

function reAssignMultiple() {
    const formData = new FormData();
    formData.append("ids", JSON.stringify(selectCases));
    formData.append("assignee", document.getElementById("assignee").value);
    fetch(
        window.location.href,
        {
            method: "POST",
            body: formData
        }
    )
    .then(resp => resp.json())
    .then(() => {
        window.location.reload();
    })
    .catch(() => window.alert("Failed to create arrear cases"));
}


function duplicate_tenant_info() {
    let tenants_holder = $($(".agent-info-holder")[0])
    let clone = tenants_holder.clone()
    $("#agents-info").append(clone)

}


function show_escalate_form(){
    $("#escalate-case-forward").toggle()
}
function escalate_back(){
    $("#escalate-case-back").toggle()
}

function show_close_form(){
    $("#close-case-form").toggle()
}