<?php

$agency_notice_context = [];

$case_id = KRequest::getQueryString("case_id", null);
$format = KRequest::getQueryString("format", "html");
$util = new Util();

if ($format == "json") {
    header("Content-type: application/json");
    AuthWrapper::getAuthenticatedUser();
}

if ($case_id) {

    $currentUser = KSecurity::getUserID();
    $info  = (object) ArrearCase::getItem($case_id);

    if ($info) {

        

        if (KRequest::isPosted()) {

            $arrears_case_id = KRequest::getPost('arrears_case');
            $pp_reason = KRequest::getPost('issue_reason');
            $tenants_names = KRequest::getPost('tenant_name');
            $tenants_emails = KRequest::getPost('tenant_email');
            $tenants_phone_no = KRequest::getPost('tenant_phone_no');
            $tenants_names = ($format == "json")?json_decode($tenants_names):$tenants_names;
            $tenants_emails = ($format == "json")?json_decode($tenants_emails):$tenants_emails;
            $tenants_phone_no = ($format == "json")?json_decode($tenants_phone_no):$tenants_phone_no;

            $tenants_info = [];
            foreach ($tenants_names as $key => $name) {
                
                $tenant_info = [
                    "name"=>$name,
                    "email"=>$tenants_emails[$key],
                    "phone_no"=>$tenants_phone_no[$key]
                ];

                $tenants_info[] = $tenant_info;

            }

            $tenant_info_json = json_encode($tenants_info);

            $agency_notice_data = array();
            $agency_notice_data['arrears_case_id'] = $arrears_case_id;
            $agency_notice_data['issue_reason'] = $pp_reason;
            $agency_notice_data['agents_info'] = $tenant_info_json;
            $agency_notice_data['created_by'] = $currentUser;

            $agency_notice = $this->database()->createRecord('arrears_agency_notice', $agency_notice_data, array('created_date' => KetrouteApplication::db()->getNowExpression()));

            ArrearCase::updateStatus($arrears_case_id, ArrearStatus::UNDER_AGENCY_NOTICE);

            // // capture audit log
            $this->logAuditTrail("Agency Notice Action Recorded for Arrears Case #$arrears_case_id", 'arrears_agency_notice', $agency_notice);

            // // // set success message
            if ($format == "json") {
                echo json_encode([
                    "message" => "Agency Notice Sucessfully Issued",
                    "status" => 200,
                ]);
                exit;
            } else {

                KSecurity::setActionSuccess(KLanguage::getWord('arrears-recorded-agency-notice-action', array('arrears_case' => $arrears_case_id)));
                $this->stopRedirector("{$this->urlPath(0)}view-agency-notice?id={$agency_notice}");
           
            }

            
        }

        $case_status = ($info->status == null) ? ArrearStatus::OPEN : $info->status;
        $bal = ArrearsManager::getOutstandingBal($info->ref_name, $info->ref_id);
        $business_details = ArrearsManager::getBusinessDetails($info->ref_name, $info->ref_id);

        $extra_details = "";

        if ($info->ref_name == "vehicle") {
            $extra_details .= "<div class=\"pt10\">
                                <strong><span class=\"bs-bold\">Park</span></strong>: {$business_details->park_name}
                            </div>
                            <div class=\"pt10\">
                                <strong><span class=\"bs-bold\">Stage</span></strong>: {$business_details->stage_name}
                            </div>
                            ";
        }

        $info_display = "
            <div class=\"clear customer-blocks pb10\">
                <h1 class=\"kfw-active-title\"><strong>[lang-arrears-case-details]<strong></h1>
                <div class=\"clear pt10\">
                    <div class=\"pt10\">
                        <strong><span class=\"bs-bold\">Customer</span></strong>: {$info->customer}
                    </div>
                    <div class=\"pt10\">
                        <strong><span class=\"bs-bold\">COIN</span></strong>: {$info->coin}
                    </div>
                    <div class=\"pt10\">
                        <strong><span class=\"bs-bold\">Revenue name</span></strong>: {$info->ref_name}
                    </div>
                    <div class=\"pt10\">
                        <strong><span class=\"bs-bold\">Branch Code</span></strong>: {$business_details->branch_code}
                    </div>
                    <div class=\"pt10\">
                        <strong><span class=\"bs-bold\">Location</span></strong>: {$business_details->location}
                    </div>
                    {$extra_details}
                    <div class=\"pt10\">
                        <strong><span class=\"bs-bold\">Outstanding balance</span></strong>: {$bal}
                    </div>
                    <div class=\"pt10\">
                        <strong><span class=\"bs-bold\">Status</span></strong>: <span class=\"{$util::StatusClass($case_status)}\">{$case_status}</span>
                    </div>
                </div>
            </div>
        ";

        $agency_notice_context["case_id"] = $case_id;
        $agency_notice_context["info_display"] = $info_display;
        $agency_notice_context['form_action'] = KRequest::getUri();
        $agency_notice_context['form_identifier'] = "mykfwform-{$this->getComponent()}-{$this->getModule()}";
        $agency_notice_context['confirm_question'] = KLanguage::getWord('confirm-item-allocate', array('item' => KLanguage::getWord($this->runtime()->getActiveItem())));
        $agency_notice_context['back_url'] = KSecurity::getSession('BACK_URL');


        return $this->render($agency_notice_context);
    } else {
        if ($format == "json") {
            echo json_encode([
                "message" => "Failed to retrieve Case Details",
                "status" => 400,
            ]);
            exit;
        }else{

            KSecurity::setActionWarning(KLanguage::getWord('arrears-no-case-found'));
        }
    }
} else {

    KSecurity::setActionWarning(KLanguage::getWord('arrears-no-case-specified'));
}

$this->stopRedirector(KSecurity::getSession('BACK_URL'));
