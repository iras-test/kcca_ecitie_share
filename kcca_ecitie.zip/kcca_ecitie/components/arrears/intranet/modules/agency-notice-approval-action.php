<?php

if (KRequest::isPosted()) {

    $selected_approval_action = KRequest::getPost('approval_action');
    
    $agency_notice_to_act_upon = KRequest::getPost('pp_id');

    if ($selected_approval_action == AgencyNoticeManager::APPROVE) {
        AgencyNoticeManager::agency_notice_approval_action($agency_notice_to_act_upon,
                                                            AgencyNoticeManager::STATUS_APPROVE,null);
    }

    if ($selected_approval_action == AgencyNoticeManager::OBJECT_NOTICE) {
        AgencyNoticeManager::agency_notice_approval_action($agency_notice_to_act_upon,
                                                            AgencyNoticeManager::STATUS_OBJECT,ArrearStatus::UNDER_OBJECTION);
    }

    if ($selected_approval_action == AgencyNoticeManager::CLOSE) {

        AgencyNoticeManager::agency_notice_approval_action($agency_notice_to_act_upon,
                                                            AgencyNoticeManager::STATUS_CLOSE,ArrearStatus::OPEN);
    
    }
    
    if ($selected_approval_action == AgencyNoticeManager::REJECT) {

        AgencyNoticeManager::agency_notice_approval_action($agency_notice_to_act_upon,
                                                            AgencyNoticeManager::STATUS_REJECT,null,
                                                            $reason = KRequest::getPost('reason'),
                                                            $comment = KRequest::getPost('comment') );
    }
    
    KSecurity::setActionSuccess("Acted on Agency Notice Successfully");
    $this->stopRedirector("{$this->urlPath(0)}view-agency-notice?id={$agency_notice_to_act_upon}");

}
KSecurity::setActionWarning("Illegal Access Method");
$this->stopRedirector(KSecurity::getSession('BACK_URL'));