<?php

if(KRequest::isPosted()) {
    $queryParams = KRequest::getQueryStrings();
    $closed_reason = KRequest::getPost("close_reason");
    ArrearCase::updateStatus($queryParams["id"], $status = ArrearStatus::CLOSED, null, null, $closed_reason);
    KResponse::redirect("{$this->urlPath(0)}cases");

} else {
    KResponse::redirect("{$this->urlPath(0)}list");
}
