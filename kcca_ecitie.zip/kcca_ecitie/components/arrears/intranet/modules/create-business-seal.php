<?php

$business_seal_context = [];

$case_id = KRequest::getQueryString("case_id", null);
$format = KRequest::getQueryString("format", "html");
$util = new Util();

if ($format == "json") {
    header("Content-type: application/json");
    AuthWrapper::getAuthenticatedUser();
}

if ($case_id) {

    $currentUser = KSecurity::getUserID();
    $info  = (object) ArrearCase::getItem($case_id);

    if ($info) {

        if (KRequest::isPosted()) {

            $arrears_case_id = KRequest::getPost('arrears_case');
            $pp_reason = KRequest::getPost('seal_reason');
            $seal_number = KRequest::getPost('seal_number');
            $seal_date = KRequest::getPost('seal_date');

            $business_seal_data = array();
            $business_seal_data['arrears_case_id'] = $arrears_case_id;
            $business_seal_data['seal_reason'] = $pp_reason;
            $business_seal_data['seal_number'] = $seal_number;
            $business_seal_data['seal_date'] = $seal_date;
            $business_seal_data['created_by'] = $currentUser;

            $business_seal = $this->database()->createRecord('arrears_business_seal', $business_seal_data, array('created_date' => KetrouteApplication::db()->getNowExpression()));

            ArrearCase::updateStatus($arrears_case_id, ArrearStatus::UNDER_BUSINESS_SEAL);

            // capture audit log
            $this->logAuditTrail("Business Seal Action Recorded for Arrears Case #$arrears_case_id", 'arrears_business_seal', $business_seal);

            // // set success message

            if ($format == "json") {
                echo json_encode([
                    "message" => "Businsess Seal Sucessfully Recorded",
                    "status" => 200,
                ]);
                exit;
            }
            KSecurity::setActionSuccess(KLanguage::getWord('arrears-recorded-seal-action', array('arrears_case' => $arrears_case_id)));
            $this->stopRedirector("{$this->urlPath(0)}view-business-seal?id={$business_seal}");
        }

        if ($format == "json") {
                        echo json_encode([
                            "message" => "Unknown Method",
                            "status" => 400,
                        ]);
                        exit;
                    }


        $case_status = ($info->status == null) ? ArrearStatus::OPEN : $info->status;
        $bal = ArrearsManager::getOutstandingBal($info->ref_name, $info->ref_id);
        $business_details = ArrearsManager::getBusinessDetails($info->ref_name, $info->ref_id);

        $extra_details = "";

        if ($info->ref_name == "vehicle") {
            $extra_details .= "<div class=\"pt10\">
                                <strong><span class=\"bs-bold\">Park</span></strong>: {$business_details->park_name}
                            </div>
                            <div class=\"pt10\">
                                <strong><span class=\"bs-bold\">Stage</span></strong>: {$business_details->stage_name}
                            </div>
                            ";
        }

        $info_display = "
            <div class=\"clear customer-blocks pb10\">
                <h1 class=\"kfw-active-title\"><strong>[lang-arrears-case-details]<strong></h1>
                <div class=\"clear pt10\">
                    <div class=\"pt10\">
                        <strong><span class=\"bs-bold\">Customer</span></strong>: {$info->customer}
                    </div>
                    <div class=\"pt10\">
                        <strong><span class=\"bs-bold\">COIN</span></strong>: {$info->coin}
                    </div>
                    <div class=\"pt10\">
                        <strong><span class=\"bs-bold\">Revenue name</span></strong>: {$info->ref_name}
                    </div>
                    <div class=\"pt10\">
                        <strong><span class=\"bs-bold\">Branch Code</span></strong>: {$business_details->branch_code}
                    </div>
                    <div class=\"pt10\">
                        <strong><span class=\"bs-bold\">Location</span></strong>: {$business_details->location}
                    </div>
                    {$extra_details}
                    <div class=\"pt10\">
                        <strong><span class=\"bs-bold\">Outstanding balance</span></strong>: {$bal}
                    </div>
                    <div class=\"pt10\">
                        <strong><span class=\"bs-bold\">Status</span></strong>: <span class=\"{$util::StatusClass($case_status)}\">{$case_status}</span>
                    </div>
                </div>
            </div>
        ";

        $business_seal_context["case_id"] = $case_id;
        $business_seal_context["info_display"] = $info_display;

        $business_seal_context['form_action'] = KRequest::getUri();
        $business_seal_context['form_identifier'] = "mykfwform-{$this->getComponent()}-{$this->getModule()}";
        $business_seal_context['confirm_question'] = KLanguage::getWord('confirm-item-allocate', array('item' => KLanguage::getWord($this->runtime()->getActiveItem())));
        $business_seal_context['back_url'] = KSecurity::getSession('BACK_URL');


        return $this->render($business_seal_context);
    } else {
        if ($format == "json") {
            echo json_encode([
                "message" => "Failed to retrieve Case Details",
                "status" => 400,
            ]);
            exit;
        }else{

            KSecurity::setActionWarning(KLanguage::getWord('arrears-no-case-found'));
        }
    }
} else {

            if ($format == "html") {
                 KSecurity::setActionWarning(KLanguage::getWord('arrears-no-case-specified'));
            }


}

if ($format == "json") {
                echo json_encode([
                    "message" => "Case Required",
                    "status" => 400,
                ]);
                exit;
            }

$this->stopRedirector(KSecurity::getSession('BACK_URL'));
