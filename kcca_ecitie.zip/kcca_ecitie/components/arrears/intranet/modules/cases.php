<?php

/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

if (KRequest::isPosted()) {
    $cases_info = KRequest::getpost("ids");

    $assignee = KRequest::getPost("assignee");
    $data = json_decode($cases_info);

    foreach ($data as $key => $case_id) {
        ArrearCase::updateStatus($case_id, null, null, $assignee);
    }
    $resp['success'] = true;
    $resp['ids'] = $data;
    $resp['assignee'] = KRequest::getPosts();

    header("Content-type: application/json");

    echo json_encode($resp);
    exit;
}

// get max per page
$MAX_PER_PAGE     = $this->registry()->get(strtoupper($this->getComponentRealname()) . '_MAX_PER_PAGE', $this->registry()->get('MAX_PER_PAGE', 10));
// page number
$_page		 	= $this->getParam('page', KRequest::getQueryString("page", 1));
$strComponentRealname    = $this->getComponentRealname();
$user_id        = KSecurity::getUserID();
$intIgnoreID     = $this->runtime()->getIgnoredID();
$strParentUrl    = $this->urlPath(0);
$strMessage = '';
$records = '';
$list_counter    = 0;
$util = new Util();

$queryParams = KRequest::getQueryStrings();
$result_list['count'] = ArrearCase::count($queryParams);
$data = ArrearCase::getList($_page, $queryParams);

// set active item with its configurations	
$this->runtime()->setActivePage($_page);
$this->runtime()->setActiveMaxPerPage($MAX_PER_PAGE);

/** Case assignment officers */
$officers = ArrearsManager::getOfficers();
$assignee_options = "";
foreach ($officers as $key => $value) {
    $assignee_options .= "<option value=\"$value->id\">{$value->surname} {$value->firstname}</option>";
}

/** Section for filters */
/** Assignee filters */
$assignee_arr = array();
foreach (ArrearsManager::getOfficers() as $value) {
    # code...
    array_push($assignee_arr, array("id" => $value->id, "name" => $value->surname . " " . $value->firstname));
}

$assignee_filter = Util::filterInput(
    "select",
    "Assignee",
    "assignee",
    $queryParams["assignee"],
    $options = array(
        "data" => $assignee_arr,
        "id" => "id",
        "label" => "name",
        "placeholder" => " - Assignee - "
    )
);
/** End assignee */

/** Status Filter */
$status_arr = array(
    array("id" => ArrearStatus::OPEN, "name" => ArrearStatus::OPEN),
    array("id" => ArrearStatus::UNDER_AGENCY_NOTICE, "name" => ArrearStatus::UNDER_AGENCY_NOTICE),
    array("id" => ArrearStatus::UNDER_BUSINESS_SEAL, "name" => ArrearStatus::UNDER_BUSINESS_SEAL),
    array("id" => ArrearStatus::UNDER_OBJECTION, "name" => ArrearStatus::UNDER_OBJECTION),
    array("id" => ArrearStatus::UNDER_PAYMENT_PLAN, "name" => ArrearStatus::UNDER_PAYMENT_PLAN),
    array("id" => ArrearStatus::UNDER_LITIGATION, "name" => ArrearStatus::UNDER_LITIGATION),
    array("id" => ArrearStatus::ASSIGNED, "name" => ArrearStatus::ASSIGNED)
);
$status_filter = Util::filterInput(
    "select",
    "Status",
    "status",
    $queryParams["status"],
    $options = array(
        "data" => $status_arr,
        "id" => "id",
        "label" => "name",
        "placeholder" => " - Status - "
    )
);
/** End of Status Filter */

/** Revenue sources */
$revenue_types = ArrearsManager::getRevenueTypes();
$revenue_types_arr = [];
foreach ($revenue_types as $key => $value) {
    array_push($revenue_types_arr, array("id" => $value["id"], "name" => $value["name"]));
}

/** Divisions */
$divisions = ArrearsManager::getDivisions();
$divisions_arr = [];
foreach ($divisions as $key => $value) {
    array_push($divisions_arr, array("id" => $value["id"], "name" => $value["name"]));
}

$customer_filter = Util::filterInput("text", "Customer", "customer", $queryParams["customer"]);
$coin_filter = Util::filterInput("text", "COIN", "coin", $queryParams["coin"]);
$branch_code_filter = Util::filterInput("text", "Branch-Code", "branch_code", $queryParams["branch_code"]);
$age_start_filter = Util::filterInput("date", "Age-Start", "age_start", $queryParams["age_start"]);
$age_end_filter = Util::filterInput("date", "Age-End", "age_end", $queryParams["age_end"]);
$amount_start_filter = Util::filterInput("number", "Amount-Start", "amount_start", $queryParams["amount_start"]);
$amount_end_filter = Util::filterInput("number", "Amount-End", "amount_end", $queryParams["amount_end"]);
$revenue_filter = Util::filterInput(
    "select",
    "Revenue",
    "revenue_type",
    $queryParams["revenue_type"],
    $options = array(
        "data" => $revenue_types_arr,
        "id" => "id",
        "label" => "name",
        "placeholder" => " - Select revenue type"
    )
);

$division_filter = Util::filterInput(
    "select",
    "Division",
    "division",
    $queryParams["division"],
    $options = array(
        "data" => $divisions_arr,
        "id" => "id",
        "label" => "name",
        "placeholder" => " - Select division"
    )
);

$filters = "
    $customer_filter
    $amount_start_filter
    $amount_end_filter
    $revenue_filter
    $coin_filter
    $status_filter
    $branch_code_filter
	$assignee_filter
	$age_start_filter
	$age_end_filter
    $division_filter
";

/** End section of filters */

if ($result_list['count'] > 0) {
    // show record	
    foreach ($data as $index => $arrData) {
        $strPrimaryKey = $this->runtime()->getPrimaryKey();

        $case_obj = (object)$arrData;

        $class = ($index % 2 == 0) ? ' odd' : ' even';

        if ($_page > 1) {
            $record_number = ($index + 1) + ($MAX_PER_PAGE * ($_page - 1));
        } else {
            $record_number = ($index + 1);
        }

        $list_counter++;
        // $arrData = ArrearsManager::getArrearsCasePaymentBill($arrData['id']);
        // $obj = (object)$arrData;

        $revenue_name = $case_obj->revenue_name
            ? $case_obj->revenue_name
            : "N/A";

        $customer = CustomerManager::getProfile($arrData['customer_id']);

        $amount = $case_obj->arrear_amount
            ? number_format(abs($case_obj->arrear_amount))
            : "N/A";

        $interval = date_diff(new DateTime(), new DateTime($case_obj->due_date));
        $age = $interval->format('%y years %M months %d days');

        $assignee = ArrearCase::getAssignee($case_obj->assignee);
        $case_status = ($case_obj->status == null) ? ArrearStatus::ASSIGNED : $case_obj->status;
        $branch_code = $case_obj->branch_code!=null?$case_obj->branch_code:"N/A";

        $records .= "<div class=\"clear list-item{$class}\">";
        $records .= "\n\t\t\t<div class=\"fl numbering-col\">{$record_number}</div>";
        $records .= "\n\t\t\t<div class=\"fl col8\">&nbsp;{$case_obj->due_date}</div>";
        $records .= "\n\t\t\t<div class=\"fl col8\">&nbsp;{$case_obj->division}</div>";
        $records .= "\n\t\t\t<div class=\"fl col8\">&nbsp;{$customer->surname} {$customer->firstname} ($customer->coin)</div>";
        $records .= "\n\t\t\t<div class=\"fl col8\">&nbsp;{$revenue_name}</div>";
        $records .= "\n\t\t\t<div class=\"fl col10\">&nbsp;{$branch_code}</div>";
        $records .= "\n\t\t\t<div class=\"fl col8\">&nbsp;{$amount}</div>";
        $records .= "\n\t\t\t<div class=\"fl col10\">&nbsp;{$assignee}</div>";
        $records .= "\n\t\t\t<div class=\"fl col8\">&nbsp;{$age}</div>";
        $records .= "\n\t\t\t<div class=\"fl col8 {$util::StatusClass($case_status)}\">&nbsp;{$case_status}</div>";
        $records .= "\n\t\t\t<div class=\"fl col8\">
				<input type=\"checkbox\" onchange=\"handleCasesSelection(this,'{$case_obj->id}')\" />
		</div>";

        $extra_actions = "";
        if (!($case_obj->status == ArrearStatus::UNDER_OBJECTION)) {
            $extra_actions .= "<a href=\"[link_in_use]arrears/file-objection?case_id={$case_obj->id}\" style=\"display:block;\">File Objection</a>";
        }

        $records .= "\n\t\t\t<div class=\"fl col10\">
            <a href=\"[link_in_use]arrears/case-details?id={$case_obj->id}\">View Details</a>";

        if (!($case_obj->status == ArrearStatus::CLOSED)) {
            $records .= "<a href=\"[link_in_use]arrears/add-feedback/case/{$case_obj->id}\">Feedback</a>
                $extra_actions
            </div>
            ";
        }

        
        $records .= "\n\t\t</div>";
    }
} else {
    $records  = "\n\t\t<div class=\"clear list-item\">" . KLanguage::getWord('arrears-case-items') . "</div>";
}

/** Show notifications from here */
$notices = $this->database()->getList("arrear_notice", $where=array("user_id" => KSecurity::getUserID(), 'status_id' => KStatus::ACTIVE));
foreach ($notices as $notice) {
    KSecurity::setActionNotice($notice->body);
    // Mark as read if its a one time view
    if($notice->delete_on_view) {
        $this->database()->updateRecord('arrear_notice',array('status' => KStatus::CLOSED),array('id' => $notice->id));
    }
}

$pager = new KPager();
$pager->setTotalRecords($result_list['count']);
$pager->setRecordsPerPage($MAX_PER_PAGE);
$pager->setCurrentPage($_page);

$url = $this->urlPath(1, 1, 1, 1);
if (count($queryParams)>0) {
    $ex_url = explode("page=",$url);
    $url = $ex_url[0];
    if (count($ex_url)==1) {
        $url .= "&";
    }
}else {

    $url .= "?";

}
$pager->setURL($url."page=");

$pager_html = $pager->getPager();
$pager_info = $pager->getPagerInfo("[lang-{$strComponentRealname}-case-items]");

$this->render(array(
    'records' => $records,
    'pager_html'     => $pager_html,
    "options"       => $assignee_options,
    'pager_info'     => $pager_info,
    'message'         => $strMessage,
    'list_counter'     => $list_counter,
    'tabs'             => KNavigationTab::getHTMLTabs(),
    'base_url'        => $this->urlPath(1, 1, 0, 0),
    'filters'        => Util::formContainer("arrears", $this->urlPath(1, 1, 1, 1), $filters),
));
