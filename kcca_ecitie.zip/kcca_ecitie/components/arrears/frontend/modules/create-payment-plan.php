<?php

$payment_plan_context = [];

$case_id = KRequest::getQueryString("case_id", null);
$util = new Util();

if ($case_id) {

    $currentUser = KSecurity::getUserID();
    $info  = (object) ArrearCase::getItem($case_id);

    if ($info) {

        if (KRequest::isPosted()) {

            $arrears_case_id = KRequest::getPost('arrears_case');
            $pp_reason = KRequest::getPost('pp_reason');

            $payment_plan_data = array();
            $payment_plan_data['arrears_case_id'] = $arrears_case_id;
            $payment_plan_data['creation_reason'] = $pp_reason;
            $payment_plan_data['created_by'] = $currentUser;

            $payment_plan = $this->database()->createRecord('arrears_payment_plan', $payment_plan_data, array('created_date' => KetrouteApplication::db()->getNowExpression()));
            $created_payment_period_dates = KRequest::getPost('pp_installment_date');
            $created_payment_period_amounts = KRequest::getPost('pp_installment_amount');

            // create payment periods
            foreach ($created_payment_period_amounts as $key => $payment_amount) {

                $payment_date_stated = $created_payment_period_dates[$key];

                if (($payment_amount && strlen($payment_amount) != 0) && ($payment_date_stated && strlen($payment_date_stated) != 0)) {

                    $payment_period_data = array();
                    $payment_period_data['payment_plan_id'] = $payment_plan;
                    $payment_period_data['amount_stated'] = $payment_amount;
                    $payment_period_data['payment_date_stated'] = $payment_date_stated;
                    $payment_period_data['created_by'] = $currentUser;

                    $payment_period_record = $this->database()->createRecord('payment_plan_period', $payment_period_data, array('created_date' => KetrouteApplication::db()->getNowExpression()));
                }
            }

            // capture audit log
            $this->logAuditTrail("Created Payment Plan for Arrears Case", 'arrear_case', $arrears_case_id);

            // set success message
            KSecurity::setActionSuccess(KLanguage::getWord('arrears-created-payment-plan', array('arrears_case' => $arrears_case_id)));

            $this->stopRedirector("{$this->urlPath(0)}view-payment-plan?id={$payment_plan}");
        }

        $case_status = ($info->status == null) ? ArrearStatus::OPEN : $info->status;
        $bal = ArrearsManager::getOutstandingBal($info->ref_name, $info->ref_id);
        $business_details = ArrearsManager::getBusinessDetails($info->ref_name, $info->ref_id);

        $extra_details = "";

        if ($info->ref_name == "vehicle") {
            $extra_details .= "<div class=\"pt10\">
                                <strong><span class=\"bs-bold\">Park</span></strong>: {$business_details->park_name}
                            </div>
                            <div class=\"pt10\">
                                <strong><span class=\"bs-bold\">Stage</span></strong>: {$business_details->stage_name}
                            </div>
                            ";
        }

        $info_display = "
            <div class=\"clear customer-blocks pb10\">
                <h1 class=\"kfw-active-title\"><strong>[lang-arrears-case-details]<strong></h1>
                <div class=\"clear pt10\">
                    <div class=\"pt10\">
                        <strong><span class=\"bs-bold\">Customer</span></strong>: {$info->customer}
                    </div>
                    <div class=\"pt10\">
                        <strong><span class=\"bs-bold\">COIN</span></strong>: {$info->coin}
                    </div>
                    <div class=\"pt10\">
                        <strong><span class=\"bs-bold\">Revenue name</span></strong>: {$info->ref_name}
                    </div>
                    <div class=\"pt10\">
                        <strong><span class=\"bs-bold\">Branch Code</span></strong>: {$business_details->branch_code}
                    </div>
                    <div class=\"pt10\">
                        <strong><span class=\"bs-bold\">Location</span></strong>: {$business_details->location}
                    </div>
                    {$extra_details}
                    <div class=\"pt10\">
                        <strong><span class=\"bs-bold\">Outstanding balance</span></strong>: {$bal}
                    </div>
                    <div class=\"pt10\">
                        <strong><span class=\"bs-bold\">Status</span></strong>: <span class=\"{$util::StatusClass($case_status)}\">{$case_status}</span>
                    </div>
                </div>
            </div>
        ";

        $balance_amount = ($bal!=null) ? $bal : 0;
        $validate_amount_js = "<script type=\"text/javascript\">
                        
                        let total_amount = $balance_amount
                        let total_plan_amount = 0
                        let submit_payment_plan_btn = document.getElementById('submit_payment_plan');
                        let total_amount_display = document.getElementById('total_amount');
                        submit_payment_plan_btn.style.display='none';

                        function validate_amount(e){
                            total_plan_amount = total_amount_enterered();
                            if(total_plan_amount>total_amount){
                                submit_payment_plan_btn.style.display='none';
                                total_amount_display.style.color = 'red';
                                alert('Payment Plan amount should not exceed balance : UGX '+total_amount);
                            }else{
                                handle_submit();
                            }
                            total_amount_display.innerHTML = total_plan_amount;
                        }

                        function total_amount_enterered(){
                            var total_input = 0;
                            var amount_inputs = Array.from(document.getElementsByName('pp_installment_amount[]'));
                            amount_inputs.forEach(inp=>{
                                total_input = total_input + Number(inp.value)
                            })
                            return total_input;
                        }

                        function handle_submit(){

                            if(total_plan_amount==total_amount){
                                submit_payment_plan_btn.style.display='';
                                total_amount_display.style.color = 'green';
                            }else{
                                total_amount_display.style.color = 'red';
                                submit_payment_plan_btn.style.display='none';
                            }
                        }
                    </script>";

        $payment_plan_context["case_id"] = $case_id;
        $payment_plan_context["info_display"] = $info_display;

        $payment_plan_context['form_action'] = KRequest::getUri();
        $payment_plan_context['form_identifier'] = "mykfwform-{$this->getComponent()}-{$this->getModule()}";
        $payment_plan_context['confirm_question'] = KLanguage::getWord('confirm-item-allocate', array('item' => KLanguage::getWord($this->runtime()->getActiveItem())));
        $payment_plan_context['back_url'] = KSecurity::getSession('BACK_URL');
        $payment_plan_context['validate_amount_js'] = $validate_amount_js;


        return $this->render($payment_plan_context);
    } else {

        KSecurity::setActionWarning(KLanguage::getWord('arrears-no-case-found'));
    }
} else {

    KSecurity::setActionWarning(KLanguage::getWord('arrears-no-case-specified'));
}

$this->stopRedirector(KSecurity::getSession('BACK_URL'));
