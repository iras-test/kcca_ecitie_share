<?php

class ArrearStatus
{

    const OPEN = "Open";
    const CLOSED = "Closed";
    const UNDER_PAYMENT_PLAN = "Under payment plan";
    const UNDER_OBJECTION = "Under objection";
    const UNDER_AGENCY_NOTICE = "Under Agency Notice";
    const UNDER_BUSINESS_SEAL = "Under Business Seal";
    const UNDER_LITIGATION = "Under Litigation";
    const DEFFERED = "Deffered";
    const ASSIGNED = "Assigned";
    const PENDING_OFRC_ACTION = "Pending ORC Action";
    const ARREARS_MANAGER_ROLE = 2;
    const LEGAL_DEPT = "Approving Authority";
    const INTENTION_TO_SUE = "Intention to Sue";
    const ORC = "Officer Revenue Collection";
    const SAM = "Supervisor Arrears Management";
    const MAI = "Manager Audit and Inspection";
    const DUE_FOR_LITIGATION = "Due for Litigation";

    /** Status Filter */
    public static $status_arr = array(
        array("id" => ArrearStatus::OPEN, "name" => ArrearStatus::OPEN),
        array("id" => ArrearStatus::ASSIGNED, "name" => ArrearStatus::ASSIGNED),
        array("id" => ArrearStatus::UNDER_AGENCY_NOTICE, "name" => ArrearStatus::UNDER_AGENCY_NOTICE),
        array("id" => ArrearStatus::UNDER_BUSINESS_SEAL, "name" => ArrearStatus::UNDER_BUSINESS_SEAL),
        array("id" => ArrearStatus::UNDER_OBJECTION, "name" => ArrearStatus::UNDER_OBJECTION),
        array("id" => ArrearStatus::UNDER_PAYMENT_PLAN, "name" => ArrearStatus::UNDER_PAYMENT_PLAN),
        array("id" => ArrearStatus::UNDER_LITIGATION, "name" => ArrearStatus::UNDER_LITIGATION),
        array("id" => ArrearStatus::DUE_FOR_LITIGATION, "name" => ArrearStatus::DUE_FOR_LITIGATION),
        array("id" => ArrearStatus::DEFFERED, "name" => ArrearStatus::DEFFERED)
    );
}
