<?php

(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin

$queryParams = KRequest::getQueryStrings();

$format = KRequest::getQueryString("format", "html");

if ($format == "json") {
	header("Content-type: application/json");
}

/** Section for filters */
/** Ref type filters */
$ref_types_arr = array();
foreach (RecoveryTrail::getRefTypes() as $value) {
	# code...
	array_push($ref_types_arr, array("id" => $value->reference_name, "name" => $value->label));
}

$ref_type_filter = Util::filterInput(
	"select",
	"Revenue Type",
	"ref_type",
	$queryParams["ref_type"],
	$options = array(
		"data" => $ref_types_arr,
		"id" => "id",
		"label" => "name",
		"placeholder" => " - Revenue Type - "
	)
);
/** End ref type filter */

$coin_filter = Util::filterInput("text", "COIN", "coin", $queryParams["coin"]);
$branch_code_filter = Util::filterInput("text", "Branch-Code", "branch_code", $queryParams["branch_code"]);

$filters = "
	$ref_type_filter
	$coin_filter
	$branch_code_filter
";
/** End filters */

// get max per page
$MAX_PER_PAGE 	= $this->registry()->get(strtoupper($this->getComponentRealname()) . '_MAX_PER_PAGE', $this->registry()->get('MAX_PER_PAGE', 10));
// page number
$_page		 	= $this->getParam('page', 1);
$strComponentRealname	= $this->getComponentRealname();
$intIgnoreID 	= $this->runtime()->getIgnoredID();
$strParentUrl	= $this->urlPath(0);
$strMessage = '';
$records = '';
$list_counter	= 0;
$util = new Util();

$resultsCount = RecoveryTrail::searchCount($queryParams);    // Total results returned
$results = RecoveryTrail::searchResults($_page, $queryParams);  // Actual results

// set active item with its configurations
$this->runtime()->setActivePage($this->getParam('page', 1));
$this->runtime()->setActiveMaxPerPage($MAX_PER_PAGE);

$pager = new KPager();
$pager->setTotalRecords($resultsCount);
$pager->setRecordsPerPage($MAX_PER_PAGE);
$pager->setCurrentPage($_page);
$pager->setURL($this->urlPath(true, true, true, false, array('page')) . 'page/');
$pager_html = $pager->getPager();
$pager_info = $pager->getPagerInfo("[lang-{$strComponentRealname}-search-items]");

if ($resultsCount > 0) {

	if ($format == "json") {
		$businesses = [];
		foreach ($results as $index => $data) {
			$object = (object)$data;
			$customer_name = $object->customer_name
				? $object->customer_name :
				"N/A";
			$business_name = $object->business_name
				? $object->business_name :
				"N/A";
			$branch_code = $object->branch_code
				? $object->branch_code
				: "N/A";

			$businesses[] = [
				'customer_name' => $customer_name,
				'business_name' => $business_name,
				'branch_code' => $branch_code,
				'id' => $object->id
			];
		}

		echo json_encode([
			"businesses" => $businesses,
			"status" => 200,
		]);
		exit;
	}

	// show record
	foreach ($results as $index => $arrData) {
		$strPrimaryKey = $this->runtime()->getPrimaryKey();

		$class = ($index % 2 == 0) ? ' odd' : ' even';
		($_page > 1)
			? $record_number = ($index + 1) + ($MAX_PER_PAGE * ($_page - 1))
			: $record_number = ($index + 1);

		$list_counter++;
		$object = (object)$arrData;

		$customer_name = $object->customer_name
			? $object->customer_name :
			"N/A";

		$branch_code = $object->branch_code
			? $object->branch_code
			: "N/A";

		$ref_name = $queryParams["ref_type"];
		$coin = $queryParams["coin"];

		$records .= "<div class=\"clear list-item{$class}\">";
		$records .= "\n\t\t\t<div class=\"fl numbering-col\">{$record_number}</div>";
		$records .= "\n\t\t\t<div class=\"fl col20\">{$customer_name}</div>";
		$records .= "\n\t\t\t<div class=\"fl col20\">{$branch_code}</div>";

		$records .= "\n\t\t\t<div class=\"fl col10\"><a href=\"[link_in_use]recovery-trail/add/ref_name/{$ref_name}/ref_id/{$object->id}/coin/$coin\">Add recovery trail</a></div>";
		$records .= "\n\t\t</div>";
	}
} else {
	if ($format == "json") {
		echo json_encode([
			"message" => "No Record found for provided details",
			"status" => 400,
		]);
		exit;
	}
	$records  = "\n\t\t<div class=\"clear list-item text-center\">" . KLanguage::getWord('search-no-items') . "</div>";
}


$this->render(
	array(
		'records'       => $records,
		'pager_html' 	=> $pager_html,
		"options"       => $assignee_options,
		'pager_info' 	=> $pager_info,
		'message' 		=> $strMessage,
		'list_counter' 	=> $list_counter,
		'tabs' 			=> KNavigationTab::getHTMLTabs(),
		'base_url'		=> $this->urlPath(1, 1, 0, 0),
		'filters'		=> Util::formContainer("search-business", $this->urlPath(1, 1, 1, 1), $filters),
	)
);
