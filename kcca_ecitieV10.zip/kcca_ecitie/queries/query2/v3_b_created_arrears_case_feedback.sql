
use ecitie;

CREATE TABLE [dbo].[arrears_case_feedback](
	[id] [INT] IDENTITY(1,1) NOT NULL,
    [arrears_case_id] [INT] NULL,
    [customer_id] [INT] NULL,
    [location] [VARCHAR](255) NULL,
    [feedback_type] [INT] NULL,
    [feedback] [VARCHAR](255) NULL,
    [status_id] [SMALLINT] DEFAULT 1,
    [created_by] [INT] NULL,
    [created_date] [DATETIME2](0) NULL,
    [modified_by] [INT] NULL,
    [modified_date] [DATETIME2](0) NULL,
)
