use ecitie;

update component set permissions = 'login,arrearscases,arrearscasesdetails,user-details,business-references,feedback-types,business-recovery-trail,recovery-trail-types,add-field-activity,statement-of-account,get-payment-types,get-collection-agent-by-type,get-payment-modes', 
module_nopermission_list = 'login,arrearscases,arrearscasesdetails,user-details,business-references,feedback-types,business-recovery-trail,recovery-trail-types,add-field-activity,statement-of-account,get-payment-types,get-collection-agent-by-type,get-payment-modes', 
module_frontend_restriction = null, 
blocked_dptm = 'login,arrearscases,arrearscasesdetails,user-details,business-references,feedback-types,business-recovery-trail,recovery-trail-types,add-field-activity,statement-of-account,get-payment-types,get-collection-agent-by-type,get-payment-modes', 
modules_over_ssl = '*' where title = 'backend-api'