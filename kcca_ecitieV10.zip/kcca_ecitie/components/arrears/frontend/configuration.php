<?php
/**
 * KETROUTE Framework
 * 
 * @copyright  (C) KETROUTE Framework, All rights reserved.
 * @license    <license@ketroute.com>
 * @version    $Id$ $Revision$ $Author$
 */
(defined('KETROUTE'))  or die('Access Denied. You are attempting to access a restricted file directly.');
# begin
 	
$arrears = array();		
$arrears[KSystemManager::ITEM_PROPERTY_TABLE_NAME] = 'payment_bill';		
$arrears[KSystemManager::ITEM_PROPERTY_LIST_FIELDS] = array('payment_id', 'customer_id', 'revenue_type_id', 'due_date', 'financial_year', 'reason', 'amount');				
$arrears[KSystemManager::ITEM_PROPERTY_VIEW_FIELDS] = array('payment_id', 'customer_id', 'revenue_type_id', 'due_date', 'financial_year', 'reason', 'amount');

$arrears[KSystemManager::ITEM_PROPERTY_PRIMARY_KEY] = 'id';
$arrears[KSystemManager::ITEM_PROPERTY_TITLE_FIELD] =  'payment_id';

$arrears[KSystemManager::ITEM_PROPERTY_HIDE_COL_WIDTHS] 	= true;
$arrears[KSystemManager::ITEM_PROPERTY_HIDE_LIST_LABELS] 	= true;

$arrears[KSystemManager::ITEM_PROPERTY_FIELDS] = array(); 

$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['payment_id'] = array();
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['payment_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] = KSystemManager::FIELD_TYPE_TEXT;
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['payment_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL]       = 'arrears-prn';
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['payment_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH]   = 100;
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['payment_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH]   = null;
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['payment_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED]    = 1;
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['payment_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT]     = '';

$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_id'] = array();
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] = KSystemManager::FIELD_TYPE_SELECT;
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] = 'payment-customer';
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] = 10;
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH] = null;
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] = true;
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT] = '';
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['customer_id'][KSystemManager::ITEM_FIELD_PROPERTY_AUTO_COMPLETE] = array(
	KSystemManager::ITEM_FIELD_PROPERTY_AUTO_COMPLETE_URL 	=> KFW_URL_IN_USE.'customer/get-list/',
	KSystemManager::ITEM_FIELD_PROPERTY_AUTO_COMPLETE_GETDATA 	=> array('CustomerManager', 'getProfilesByIDs'),
);

$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['revenue_type_id'] = array();
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['revenue_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] = KSystemManager::FIELD_TYPE_TEXT;
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['revenue_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL]       = 'arrears-revenue-type';
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['revenue_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH]   = 100;
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['revenue_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH]   = null;
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['revenue_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED]    = 1;
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['revenue_type_id'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT]     = '';

$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['due_date'] = array();
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['due_date'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] = KSystemManager::FIELD_TYPE_TEXT;
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['due_date'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL]       = 'due-date';
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['due_date'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH]   = 100;
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['due_date'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH]   = null;
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['due_date'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED]    = 1;
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['due_date'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT]     = '';
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['due_date'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] = array();

$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['attachment'] = array();
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['attachment'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] = KSystemManager::FIELD_TYPE_FILE_UPLOAD;
//label to use on the form: mapped back to the translation file
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['attachment'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] = 'attachment';
// maximum file size allowed
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['attachment'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH] = (1024 * 1024)/10;
// flag to set if this is mandotary
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['attachment'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED] = false;
// file storage
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['attachment'][KSystemManager::ITEM_FIELD_PROPERTY_STORAGE_MEDIA] = KSystemManager::STORAGE_MEDIA_FILE_SYSTEM;
// specify the path to the system directory
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['attachment'][KSystemManager::ITEM_FIELD_PROPERTY_STORAGE_MEDIA_FILE_SYSTEM_PATH] = KFW_STORAGE_PATH . $this->getComponentRealname() .DIRECTORY_SEPARATOR;

$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['financial_year'] = array();
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['financial_year'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] = KSystemManager::FIELD_TYPE_TEXT;
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['financial_year'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL]       = 'arrears-financial-year';
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['financial_year'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH]   = 100;
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['financial_year'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH]   = null;
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['financial_year'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED]    = 1;
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['financial_year'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT]     = '';
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['financial_year'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] = array();

$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['reason'] = array();
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['reason'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] = KSystemManager::FIELD_TYPE_TEXT;
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['reason'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL]       = 'arrears-reason';
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['reason'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH]   = 100;
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['reason'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH]   = null;
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['reason'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED]    = 1;
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['reason'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT]     = '';
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['reason'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] = array();

$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['amount'] = array();
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['amount'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] = KSystemManager::FIELD_TYPE_TEXT;
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['amount'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL]       = 'arrears-amount';
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['amount'][KSystemManager::ITEM_FIELD_PROPERTY_MAXLENGTH]   = 100;
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['amount'][KSystemManager::ITEM_FIELD_PROPERTY_MINLENGTH]   = null;
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['amount'][KSystemManager::ITEM_FIELD_PROPERTY_REQUIRED]    = 1;
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['amount'][KSystemManager::ITEM_FIELD_PROPERTY_DEFAULT]     = '';
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['amount'][KSystemManager::WHERE_CLAUSE]     = array(
	KSystemManager::WHERE_GREATER_THAN_EQUAL => array(
		'amount' => 120000
	)
);
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['amount'][KSystemManager::ITEM_FIELD_PROPERTY_CHILD] = array();

// filtering stats here
$arrears[KSystemManager::ITEM_PROPERTY_GROUP_FILTER] = array();

$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['reason'] = array();
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['reason'][KSystemManager::ITEM_FIELD_PROPERTY_TYPE] 		= KSystemManager::FIELD_TYPE_TEXT;
$arrears[KSystemManager::ITEM_PROPERTY_FIELDS]['reason'][KSystemManager::ITEM_FIELD_PROPERTY_LABEL] 	= 'customer-other-title';
$arrears[KSystemManager::ITEM_PROPERTY_GROUP_FILTER]['reason'][KSystemManager::ITEM_PROPERTY_GROUP_FILTER_DATA] = array(
	KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_DATABASE_TABLE_NAME => 'payment_bill',
	KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_DATABASE_ID_FIELD => 'id',
	KSystemManager::ITEM_PROPERTY_GROUP_FILTER_TYPE_DATABASE_VALUE_FIELD => 'reason',
	KSystemManager::WHERE_CLAUSE => array(
		KSystemManager::WHERE_EXACT_MATCH => array('reason' => 'Test')),
		KSystemManager::ORDER_BY => array('reason' => KSystemManager::SORT_ASCENDING),
	);

// allow only sent, pending and failed sms on list and check for deviceship
// $arrears[KSystemManager::ITEM_PROPERTY_FORCED_WHERE] = array('due_date' => array("2020-01-02"));

return $arrears;